/**
 * JARVIS Advanced Access Control System
 * Фаза 2: Многоуровневая система контроля доступа
 * 
 * Implements graduated access control with fail-safe mechanisms
 */

import { Request, Response, NextFunction } from 'express';
import { jarvisEmergencyProtection } from './jarvis-emergency-protection';
import * as jwt from 'jsonwebtoken';
import * as crypto from 'crypto';

export interface AccessRequest {
  assetId: string;
  userId?: string;
  clientIP: string;
  userAgent: string;
  token?: string;
  requestedAction: string;
  timestamp: Date;
}

export interface AccessResponse {
  granted: boolean;
  reason: string;
  level: 'FULL' | 'LIMITED' | 'DENIED';
  token?: string;
  restrictions?: string[];
}

export class JarvisAccessControl {
  private accessAttempts: Map<string, number> = new Map();
  private blockedIPs: Set<string> = new Set();
  private trustedTokens: Set<string> = new Set();
  private readonly maxAttempts = 5;
  private readonly blockDuration = 15 * 60 * 1000; // 15 минут

  constructor() {
    // Очистка заблокированных IP каждые 15 минут
    setInterval(() => {
      this.accessAttempts.clear();
      this.blockedIPs.clear();
    }, this.blockDuration);
  }

  /**
   * Middleware для защиты критических endpoints
   */
  public protectCriticalEndpoint(assetId: string) {
    return async (req: Request, res: Response, next: NextFunction) => {
      const clientIP = this.getClientIP(req);
      const userAgent = req.get('User-Agent') || 'Unknown';
      const token = req.headers.authorization?.replace('Bearer ', '');

      const accessRequest: AccessRequest = {
        assetId,
        clientIP,
        userAgent,
        token,
        requestedAction: `${req.method} ${req.path}`,
        timestamp: new Date()
      };

      try {
        const response = await this.evaluateAccess(accessRequest);
        
        if (!response.granted) {
          console.log(`❌ Access DENIED for ${assetId}: ${response.reason}`);
          return res.status(403).json({
            success: false,
            error: 'Access denied',
            reason: response.reason,
            level: response.level
          });
        }

        console.log(`✅ Access GRANTED for ${assetId}`);
        
        // Добавляем информацию о доступе к request
        (req as any).accessInfo = {
          assetId,
          level: response.level,
          restrictions: response.restrictions || []
        };

        next();
      } catch (error) {
        console.error(`🚨 Access control error for ${assetId}:`, error);
        res.status(500).json({
          success: false,
          error: 'Access control system error'
        });
      }
    };
  }

  /**
   * Middleware для защиты Bio-Singularity endpoints
   */
  public protectBioSingularity() {
    return this.protectCriticalEndpoint('bio-singularity-core');
  }

  /**
   * Middleware для защиты Bio-Synthesis V3 endpoints
   */
  public protectBioSynthesisV3() {
    return this.protectCriticalEndpoint('bio-synthesis-v3');
  }

  /**
   * Middleware для защиты Tony Stark Intelligence endpoints
   */
  public protectTonyStarkIntelligence() {
    return this.protectCriticalEndpoint('tony-stark-intelligence');
  }

  /**
   * Middleware для защиты Holographic System endpoints
   */
  public protectHolographicSystem() {
    return this.protectCriticalEndpoint('holographic-v2');
  }

  private async evaluateAccess(request: AccessRequest): Promise<AccessResponse> {
    const { assetId, clientIP, userAgent, token, requestedAction } = request;

    // Проверка на заблокированные IP
    if (this.blockedIPs.has(clientIP)) {
      return {
        granted: false,
        reason: 'IP address is temporarily blocked due to suspicious activity',
        level: 'DENIED'
      };
    }

    // Проверка лимита попыток
    const attemptKey = `${clientIP}:${assetId}`;
    const attempts = this.accessAttempts.get(attemptKey) || 0;
    
    if (attempts >= this.maxAttempts) {
      this.blockedIPs.add(clientIP);
      return {
        granted: false,
        reason: `Too many access attempts (${attempts}/${this.maxAttempts})`,
        level: 'DENIED'
      };
    }

    // Проверка через систему экстренной защиты
    const emergencyCheck = await jarvisEmergencyProtection.verifyAccess(assetId, clientIP, token);
    
    if (!emergencyCheck) {
      this.accessAttempts.set(attemptKey, attempts + 1);
      return {
        granted: false,
        reason: 'Emergency protection system denied access',
        level: 'DENIED'
      };
    }

    // Дополнительные проверки для критических активов
    if (assetId === 'bio-singularity-core' || assetId === 'bio-synthesis-v3') {
      const advancedCheck = await this.performAdvancedSecurityCheck(request);
      if (!advancedCheck.passed) {
        this.accessAttempts.set(attemptKey, attempts + 1);
        return {
          granted: false,
          reason: advancedCheck.reason,
          level: 'DENIED'
        };
      }
    }

    // Определение уровня доступа
    const accessLevel = this.determineAccessLevel(assetId, token);
    
    // Генерация нового токена для последующих запросов
    const newToken = jarvisEmergencyProtection.generateAccessToken(assetId);
    this.trustedTokens.add(newToken);

    return {
      granted: true,
      reason: 'Access granted',
      level: accessLevel,
      token: newToken,
      restrictions: this.getAccessRestrictions(assetId, accessLevel)
    };
  }

  private async performAdvancedSecurityCheck(request: AccessRequest): Promise<{passed: boolean, reason: string}> {
    const { clientIP, userAgent, requestedAction } = request;

    // Проверка User-Agent на подозрительные паттерны
    if (this.isSuspiciousUserAgent(userAgent)) {
      return {
        passed: false,
        reason: 'Suspicious user agent detected'
      };
    }

    // Проверка на автоматические скрипты
    if (this.isAutomatedRequest(userAgent, requestedAction)) {
      return {
        passed: false,
        reason: 'Automated access attempts are not allowed'
      };
    }

    // Проверка частоты запросов
    if (this.isTooFrequent(clientIP)) {
      return {
        passed: false,
        reason: 'Request frequency too high'
      };
    }

    return { passed: true, reason: 'Advanced security check passed' };
  }

  private isSuspiciousUserAgent(userAgent: string): boolean {
    const suspiciousPatterns = [
      /curl/i,
      /wget/i,
      /python/i,
      /bot/i,
      /crawler/i,
      /scraper/i,
      /automated/i
    ];

    return suspiciousPatterns.some(pattern => pattern.test(userAgent));
  }

  private isAutomatedRequest(userAgent: string, requestedAction: string): boolean {
    // Проверка на признаки автоматических запросов
    const automatedSigns = [
      userAgent.includes('python'),
      userAgent.includes('curl'),
      userAgent.length < 20,
      !userAgent.includes('Mozilla')
    ];

    return automatedSigns.filter(Boolean).length >= 2;
  }

  private isTooFrequent(clientIP: string): boolean {
    // Простая проверка частоты (можно расширить)
    const requestKey = `freq:${clientIP}`;
    const now = Date.now();
    const lastRequest = this.accessAttempts.get(requestKey) || 0;
    
    if (now - lastRequest < 1000) { // менее 1 секунды между запросами
      return true;
    }
    
    this.accessAttempts.set(requestKey, now);
    return false;
  }

  private determineAccessLevel(assetId: string, token?: string): 'FULL' | 'LIMITED' | 'DENIED' {
    if (!token) {
      return 'LIMITED';
    }

    // Проверка токена на доверенность
    if (this.trustedTokens.has(token)) {
      return 'FULL';
    }

    // Для критических активов требуется полная аутентификация
    if (assetId === 'bio-singularity-core' || assetId === 'bio-synthesis-v3') {
      return 'LIMITED';
    }

    return 'FULL';
  }

  private getAccessRestrictions(assetId: string, level: 'FULL' | 'LIMITED' | 'DENIED'): string[] {
    if (level === 'DENIED') {
      return ['All access denied'];
    }

    if (level === 'LIMITED') {
      return [
        'Read-only access',
        'Limited API calls per hour',
        'Monitoring enabled',
        'No sensitive data access'
      ];
    }

    // FULL access
    return ['Monitoring enabled'];
  }

  private getClientIP(req: Request): string {
    return req.ip || 
           req.connection.remoteAddress || 
           req.socket.remoteAddress || 
           '127.0.0.1';
  }

  /**
   * Утилитарные методы для управления доступом
   */
  public blockIP(ip: string): void {
    this.blockedIPs.add(ip);
    console.log(`🚫 IP ${ip} blocked`);
  }

  public unblockIP(ip: string): void {
    this.blockedIPs.delete(ip);
    this.accessAttempts.delete(`${ip}:*`);
    console.log(`✅ IP ${ip} unblocked`);
  }

  public getBlockedIPs(): string[] {
    return Array.from(this.blockedIPs);
  }

  public getAccessAttempts(): { [key: string]: number } {
    const result: { [key: string]: number } = {};
    for (const [key, value] of this.accessAttempts) {
      result[key] = value;
    }
    return result;
  }

  public generateEmergencyToken(assetId: string): string {
    const token = jarvisEmergencyProtection.generateAccessToken(assetId);
    this.trustedTokens.add(token);
    return token;
  }

  public revokeToken(token: string): void {
    this.trustedTokens.delete(token);
  }

  public clearAllTokens(): void {
    this.trustedTokens.clear();
  }

  public getSecurityStatus(): {
    blockedIPs: number;
    accessAttempts: number;
    trustedTokens: number;
    emergencyMode: boolean;
  } {
    return {
      blockedIPs: this.blockedIPs.size,
      accessAttempts: this.accessAttempts.size,
      trustedTokens: this.trustedTokens.size,
      emergencyMode: jarvisEmergencyProtection.isEmergencyMode()
    };
  }
}

// Глобальный экземпляр системы контроля доступа
export const jarvisAccessControl = new JarvisAccessControl();