import OpenAI from 'openai';
import { emotionalVoiceAnalyzer } from './emotional-voice-analyzer';
import { smartRecommendationsEngine } from './smart-recommendations-engine';
import { Request } from 'express';
import fs from 'fs';
import path from 'path';

// the newest OpenAI model is "gpt-4o" which was released May 13, 2024. do not change this unless explicitly requested by the user
const openai = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });

interface VoiceAnalysis {
  volume: number;
  duration: number;
  pace: 'fast' | 'normal' | 'slow';
  emotion: 'excited' | 'calm' | 'urgent' | 'neutral';
}

interface CommandContext {
  userId: string;
  currentSystems: any[];
  todayTasks: any[];
  userMood: string;
  timeOfDay: string;
  language: 'en' | 'es' | 'de' | 'ko';
}

interface ProcessedCommand {
  intent: string;
  action: string;
  parameters: Record<string, any>;
  requiresConfirmation: boolean;
  response: string;
  emotion: VoiceAnalysis['emotion'];
}

export class AdvancedVoiceEngine {
  private supportedLanguages = {
    'en': 'English',
    'es': 'Spanish', 
    'de': 'German',
    'ko': 'Korean'
  };

  async transcribeWithWhisper(audioBuffer: Buffer, language?: string): Promise<string> {
    try {
      // Create temporary file for Whisper
      const tempFilePath = path.join('/tmp', `voice_${Date.now()}.wav`);
      fs.writeFileSync(tempFilePath, audioBuffer);

      const transcription = await openai.audio.transcriptions.create({
        file: fs.createReadStream(tempFilePath),
        model: "whisper-1",
        language: language || 'en',
        response_format: "text"
      });

      // Cleanup temporary file
      fs.unlinkSync(tempFilePath);

      return transcription;
    } catch (error) {
      console.error('Whisper transcription failed:', error);
      throw new Error('Voice transcription failed');
    }
  }

  analyzeVoiceCharacteristics(audioBuffer: Buffer, duration: number): VoiceAnalysis {
    // Analyze audio characteristics
    const volume = this.calculateVolume(audioBuffer);
    const pace = this.determinePace(duration, audioBuffer.length);
    const emotion = this.determineEmotion(volume, pace, duration);

    return { volume, duration, pace, emotion };
  }

  private calculateVolume(audioBuffer: Buffer): number {
    // Simple volume calculation - in production would use proper audio analysis
    const samples = new Int16Array(audioBuffer.buffer);
    let sum = 0;
    for (let i = 0; i < samples.length; i++) {
      sum += Math.abs(samples[i]);
    }
    return sum / samples.length / 32768; // Normalize to 0-1
  }

  private determinePace(duration: number, bufferSize: number): 'fast' | 'normal' | 'slow' {
    const wordsPerSecond = (bufferSize / duration) / 1000; // Rough estimation
    if (wordsPerSecond > 3) return 'fast';
    if (wordsPerSecond < 1.5) return 'slow';
    return 'normal';
  }

  private determineEmotion(volume: number, pace: 'fast' | 'normal' | 'slow', duration: number): VoiceAnalysis['emotion'] {
    if (volume > 0.7 && pace === 'fast') return 'excited';
    if (volume > 0.8) return 'urgent';
    if (pace === 'slow' && duration > 10) return 'calm';
    return 'neutral';
  }

  async processAdvancedCommand(
    transcription: string,
    voiceAnalysis: VoiceAnalysis,
    context: CommandContext
  ): Promise<ProcessedCommand> {
    const systemPrompt = this.buildSystemPrompt(context, voiceAnalysis);
    
    try {
      const response = await openai.chat.completions.create({
        model: "gpt-4o",
        messages: [
          { role: "system", content: systemPrompt },
          { role: "user", content: transcription }
        ],
        response_format: { type: "json_object" },
        temperature: voiceAnalysis.emotion === 'calm' ? 0.7 : 0.3
      });

      const result = JSON.parse(response.choices[0].message.content || '{}');
      
      return {
        intent: result.intent || 'unknown',
        action: result.action || 'none',
        parameters: result.parameters || {},
        requiresConfirmation: result.requiresConfirmation || false,
        response: result.response || 'I did not understand that command.',
        emotion: voiceAnalysis.emotion
      };
    } catch (error) {
      console.error('Command processing failed:', error);
      return {
        intent: 'error',
        action: 'none',
        parameters: {},
        requiresConfirmation: false,
        response: 'I encountered an error processing your command.',
        emotion: voiceAnalysis.emotion
      };
    }
  }

  private buildSystemPrompt(context: CommandContext, voiceAnalysis: VoiceAnalysis): string {
    const emotionalContext = this.getEmotionalResponseStyle(voiceAnalysis);
    
    return `You are JARVIS, an advanced AI assistant for a productivity system. Respond in JSON format with these fields:
    - intent: The user's intent (navigation, system_control, deep_focus, calendar, metrics, settings)
    - action: Specific action to take
    - parameters: Action parameters
    - requiresConfirmation: true only for deep_focus activation
    - response: Your response text

    EMOTIONAL RESPONSE RULES:
    ${emotionalContext}

    CURRENT CONTEXT:
    - User ID: ${context.userId}
    - Active Systems: ${context.currentSystems.map(s => s.title).join(', ')}
    - Today's Tasks: ${context.todayTasks.length} tasks scheduled
    - Time: ${context.timeOfDay}
    - Language: ${this.supportedLanguages[context.language]}

    AVAILABLE COMMANDS:
    Navigation: "show dashboard", "open systems", "go to profile"
    System Control: "start [system]", "pause system", "show progress"
    Deep Focus: "activate deep focus", "focus for [duration]" (REQUIRES CONFIRMATION)
    Calendar: "what's on my calendar", "today's tasks", "upcoming meetings"
    Metrics: "revenue today", "tasks completed", "show stats"

    SECURITY: Deep focus activation ALWAYS requires confirmation. Ask "Are you sure?" first.

    If long recording (10+ seconds) and calm emotion, add subtle humor like Tony Stark's JARVIS.`;
  }

  private getEmotionalResponseStyle(voiceAnalysis: VoiceAnalysis): string {
    switch (voiceAnalysis.emotion) {
      case 'excited':
      case 'urgent':
        return `User is speaking ${voiceAnalysis.emotion}. Keep responses SHORT and ACTION-FOCUSED. No lengthy explanations.`;
      case 'calm':
        if (voiceAnalysis.duration > 10) {
          return `User is calm and took time to speak (${voiceAnalysis.duration}s). Provide DETAILED analytics and add subtle Tony Stark-style humor.`;
        }
        return `User is calm. Provide thorough, analytical responses with helpful details.`;
      default:
        return `User emotion is neutral. Provide balanced, professional responses.`;
    }
  }

  async getCalendarTasks(userId: string, date: Date): Promise<any[]> {
    // In production, this would connect to actual calendar API
    // For now, return mock calendar data
    return [
      {
        id: '1',
        title: 'Revenue Analysis Meeting',
        time: '10:00 AM',
        duration: 60,
        priority: 'high',
        type: 'meeting'
      },
      {
        id: '2', 
        title: 'Complete System Integration',
        time: '2:00 PM',
        duration: 120,
        priority: 'critical',
        type: 'task'
      },
      {
        id: '3',
        title: 'Client Follow-up Calls',
        time: '4:00 PM', 
        duration: 90,
        priority: 'medium',
        type: 'calls'
      }
    ];
  }

  generateActionResponse(command: ProcessedCommand): any {
    const actions: Record<string, any> = {
      'open_dashboard': { type: 'navigate', route: '/business' },
      'open_systems': { type: 'navigate', route: '/systems' },
      'open_profile': { type: 'navigate', route: '/profile' },
      'start_system': { 
        type: 'system_action', 
        action: 'start',
        systemId: command.parameters.systemId 
      },
      'show_calendar': { 
        type: 'display', 
        content: 'calendar',
        data: command.parameters.tasks 
      },
      'deep_focus_request': { 
        type: 'confirmation_required',
        action: 'deep_focus',
        message: 'Are you sure you want to activate Deep Focus mode?'
      }
    };

    return actions[command.action] || { type: 'none' };
  }
}

export const advancedVoiceEngine = new AdvancedVoiceEngine();