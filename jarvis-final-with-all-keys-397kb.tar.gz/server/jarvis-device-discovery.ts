// JARVIS Device Discovery - ЭТАП 4
// Автоматическое обнаружение и подключение устройств

import { EventEmitter } from 'events';
import { WebSocket } from 'ws';
import { networkInterfaces } from 'os';
import { exec } from 'child_process';
import { promisify } from 'util';
import * as net from 'net';
import * as dns from 'dns';

// Типы устройств
export enum DeviceType {
  IPHONE = 'iphone',
  IPAD = 'ipad',
  MACBOOK = 'macbook',
  IMAC = 'imac',
  APPLE_WATCH = 'apple_watch',
  AIRPODS = 'airpods',
  HOMEPOD = 'homepod',
  ANDROID_PHONE = 'android_phone',
  ANDROID_TABLET = 'android_tablet',
  WINDOWS_PC = 'windows_pc',
  LINUX_PC = 'linux_pc',
  UNKNOWN = 'unknown'
}

// Уровни разрешений
export enum PermissionLevel {
  BASIC = 'basic',           // Базовые функции
  STANDARD = 'standard',     // Стандартные возможности
  ADVANCED = 'advanced',     // Расширенные функции
  ADMIN = 'admin',           // Администраторские права
  FULL = 'full'              // Полный доступ
}

// Информация об устройстве
export interface DeviceInfo {
  id: string;
  name: string;
  type: DeviceType;
  ipAddress: string;
  macAddress?: string;
  userAgent?: string;
  capabilities: string[];
  permissionLevel: PermissionLevel;
  isOnline: boolean;
  lastSeen: number;
  batteryLevel?: number;
  connectionType: 'wifi' | 'cellular' | 'bluetooth' | 'usb' | 'unknown';
  jarvisVersion?: string;
  userId?: string;
  fingerprint: string;
}

// Результат сканирования сети
export interface NetworkScanResult {
  deviceId: string;
  ipAddress: string;
  hostname?: string;
  macAddress?: string;
  manufacturer?: string;
  openPorts: number[];
  responseTime: number;
  deviceType: DeviceType;
  confidence: number; // 0-1, насколько уверены в типе устройства
}

// Конфигурация сканирования
export interface ScanConfig {
  networkRange: string;      // e.g., "192.168.1.0/24"
  timeout: number;           // ms
  maxConcurrentScans: number;
  enablePortScan: boolean;
  enableMacDetection: boolean;
  enableDeviceFingerprinting: boolean;
}

class JarvisDeviceDiscovery extends EventEmitter {
  private discoveredDevices: Map<string, DeviceInfo> = new Map();
  private scanResults: Map<string, NetworkScanResult> = new Map();
  private scanConfig: ScanConfig;
  private isScanning: boolean = false;
  private scanInterval: NodeJS.Timeout | null = null;
  private connectedDevices: Map<string, WebSocket> = new Map();

  constructor() {
    super();
    
    // Настройка по умолчанию
    this.scanConfig = {
      networkRange: '192.168.1.0/24',
      timeout: 5000,
      maxConcurrentScans: 50,
      enablePortScan: true,
      enableMacDetection: true,
      enableDeviceFingerprinting: true
    };

    console.log('🔍 JARVIS Device Discovery initialized');
  }

  // ЭТАП 4.1: Network Scanner
  public async startNetworkScan(config?: Partial<ScanConfig>): Promise<void> {
    if (this.isScanning) {
      console.log('⚠️ Network scan already in progress');
      return;
    }

    // Автоматически определяем локальную сеть если не указана
    if (!config?.networkRange) {
      const detectedNetwork = await this.detectLocalNetwork();
      this.scanConfig.networkRange = detectedNetwork;
    }

    if (config) {
      this.scanConfig = { ...this.scanConfig, ...config };
    }

    this.isScanning = true;
    console.log(`🔍 Starting REAL network scan on ${this.scanConfig.networkRange}`);

    try {
      await this.performNetworkScan();
      await this.classifyDiscoveredDevices();
      await this.attemptAutoConnect();
    } catch (error) {
      console.error('❌ Network scan failed:', error);
    } finally {
      this.isScanning = false;
    }
  }

  private async detectLocalNetwork(): Promise<string> {
    try {
      const interfaces = networkInterfaces();
      
      for (const interfaceName in interfaces) {
        const interfaceInfo = interfaces[interfaceName];
        if (!interfaceInfo) continue;
        
        for (const addr of interfaceInfo) {
          // Ищем IPv4 адрес, который не является loopback
          if (addr.family === 'IPv4' && !addr.internal) {
            const ip = addr.address;
            const netmask = addr.netmask;
            
            // Определяем сетевой префикс
            const networkAddress = this.calculateNetworkAddress(ip, netmask);
            const cidr = this.netmaskToCIDR(netmask);
            
            console.log(`🌐 Detected local network: ${networkAddress}/${cidr} on interface ${interfaceName}`);
            return `${networkAddress}/${cidr}`;
          }
        }
      }
      
      // Fallback к стандартной сети
      return '192.168.1.0/24';
    } catch (error) {
      console.log('⚠️ Failed to detect local network, using default');
      return '192.168.1.0/24';
    }
  }

  private calculateNetworkAddress(ip: string, netmask: string): string {
    const ipParts = ip.split('.').map(Number);
    const maskParts = netmask.split('.').map(Number);
    
    const networkParts = ipParts.map((part, index) => part & maskParts[index]);
    return networkParts.join('.');
  }

  private netmaskToCIDR(netmask: string): number {
    const maskParts = netmask.split('.').map(Number);
    let cidr = 0;
    
    for (const part of maskParts) {
      const binary = part.toString(2);
      cidr += (binary.match(/1/g) || []).length;
    }
    
    return cidr;
  }

  private async performNetworkScan(): Promise<void> {
    const networkRange = this.parseNetworkRange(this.scanConfig.networkRange);
    const scanPromises: Promise<void>[] = [];
    
    console.log(`📡 Scanning ${networkRange.length} IP addresses...`);

    for (let i = 0; i < networkRange.length; i += this.scanConfig.maxConcurrentScans) {
      const batch = networkRange.slice(i, i + this.scanConfig.maxConcurrentScans);
      
      const batchPromises = batch.map(ip => this.scanSingleDevice(ip));
      scanPromises.push(...batchPromises);
      
      // Батчевое выполнение для предотвращения перегрузки сети
      await Promise.allSettled(batchPromises);
    }

    await Promise.allSettled(scanPromises);
    console.log(`✅ Network scan completed. Found ${this.scanResults.size} responsive devices`);
  }

  private async scanSingleDevice(ipAddress: string): Promise<void> {
    const startTime = Date.now();
    
    try {
      // Ping test
      const isReachable = await this.pingDevice(ipAddress);
      if (!isReachable) return;

      const responseTime = Date.now() - startTime;
      
      // Получение базовой информации
      const hostname = await this.getHostname(ipAddress);
      const macAddress = this.scanConfig.enableMacDetection ? 
        await this.getMacAddress(ipAddress) : undefined;
      
      // Сканирование портов
      const openPorts = this.scanConfig.enablePortScan ? 
        await this.scanPorts(ipAddress) : [];
      
      // Определение производителя по MAC
      const manufacturer = macAddress ? 
        this.getManufacturerFromMac(macAddress) : undefined;

      // Предварительная классификация устройства
      const deviceType = this.classifyDeviceByCharacteristics(
        hostname, manufacturer, openPorts, ipAddress
      );

      const scanResult: NetworkScanResult = {
        deviceId: `device_${ipAddress.replace(/\./g, '_')}`,
        ipAddress,
        hostname,
        macAddress,
        manufacturer,
        openPorts,
        responseTime,
        deviceType,
        confidence: this.calculateDeviceTypeConfidence(deviceType, manufacturer, openPorts)
      };

      this.scanResults.set(ipAddress, scanResult);
      
      console.log(`📱 Device found: ${ipAddress} (${deviceType}, confidence: ${scanResult.confidence})`);
      
      // Эмитим событие для немедленной обработки
      this.emit('deviceFound', scanResult);
      
    } catch (error) {
      console.error(`❌ Error scanning ${ipAddress}:`, error);
    }
  }

  // ЭТАП 4.2: Device Classifier
  private classifyDeviceByCharacteristics(
    hostname?: string, 
    manufacturer?: string, 
    openPorts: number[] = [], 
    ipAddress: string = ''
  ): DeviceType {
    
    // Классификация по производителю
    if (manufacturer) {
      if (manufacturer.toLowerCase().includes('apple')) {
        // Дополнительная классификация Apple устройств
        if (hostname?.toLowerCase().includes('iphone')) return DeviceType.IPHONE;
        if (hostname?.toLowerCase().includes('ipad')) return DeviceType.IPAD;
        if (hostname?.toLowerCase().includes('macbook')) return DeviceType.MACBOOK;
        if (hostname?.toLowerCase().includes('imac')) return DeviceType.IMAC;
        if (hostname?.toLowerCase().includes('watch')) return DeviceType.APPLE_WATCH;
        if (hostname?.toLowerCase().includes('airpods')) return DeviceType.AIRPODS;
        if (hostname?.toLowerCase().includes('homepod')) return DeviceType.HOMEPOD;
        
        // Общая классификация по портам для Apple устройств
        if (openPorts.includes(22) && openPorts.includes(80)) return DeviceType.MACBOOK;
        if (openPorts.includes(62078)) return DeviceType.IPHONE; // iPhone характерный порт
        
        return DeviceType.IPHONE; // Default для Apple
      }
      
      if (manufacturer.toLowerCase().includes('samsung') || 
          manufacturer.toLowerCase().includes('google') ||
          manufacturer.toLowerCase().includes('huawei') ||
          manufacturer.toLowerCase().includes('xiaomi')) {
        return DeviceType.ANDROID_PHONE;
      }
    }

    // Классификация по hostname
    if (hostname) {
      const hostLower = hostname.toLowerCase();
      
      if (hostLower.includes('iphone')) return DeviceType.IPHONE;
      if (hostLower.includes('ipad')) return DeviceType.IPAD;
      if (hostLower.includes('macbook') || hostLower.includes('mac')) return DeviceType.MACBOOK;
      if (hostLower.includes('imac')) return DeviceType.IMAC;
      if (hostLower.includes('android')) return DeviceType.ANDROID_PHONE;
      if (hostLower.includes('windows') || hostLower.includes('pc')) return DeviceType.WINDOWS_PC;
      if (hostLower.includes('linux')) return DeviceType.LINUX_PC;
    }

    // Классификация по открытым портам
    if (openPorts.includes(22) && openPorts.includes(80) && openPorts.includes(443)) {
      return DeviceType.MACBOOK; // SSH + HTTP/HTTPS обычно Mac
    }
    
    if (openPorts.includes(3389)) {
      return DeviceType.WINDOWS_PC; // RDP порт
    }
    
    if (openPorts.includes(62078)) {
      return DeviceType.IPHONE; // iPhone характерный порт
    }
    
    if (openPorts.includes(5555)) {
      return DeviceType.ANDROID_PHONE; // Android ADB порт
    }
    
    if (openPorts.includes(5555)) {
      return DeviceType.ANDROID_PHONE; // ADB порт
    }

    return DeviceType.UNKNOWN;
  }

  private calculateDeviceTypeConfidence(
    deviceType: DeviceType, 
    manufacturer?: string, 
    openPorts: number[] = []
  ): number {
    let confidence = 0.3; // Базовая уверенность

    // Увеличиваем уверенность если есть информация о производителе
    if (manufacturer) {
      confidence += 0.3;
      
      // Дополнительная уверенность для известных брендов
      if (manufacturer.toLowerCase().includes('apple') && 
          [DeviceType.IPHONE, DeviceType.IPAD, DeviceType.MACBOOK, DeviceType.IMAC].includes(deviceType)) {
        confidence += 0.2;
      }
    }

    // Увеличиваем уверенность на основе портов
    if (openPorts.length > 0) {
      confidence += 0.2;
    }

    // Специфические порты увеличивают уверенность
    if (deviceType === DeviceType.IPHONE && openPorts.includes(62078)) {
      confidence += 0.3;
    }
    
    if (deviceType === DeviceType.MACBOOK && openPorts.includes(22)) {
      confidence += 0.2;
    }

    return Math.min(confidence, 1.0);
  }

  // ЭТАП 4.3: Auto-Connect Logic
  private async attemptAutoConnect(): Promise<void> {
    console.log('🔌 Attempting auto-connect to discovered devices...');
    
    for (const [ipAddress, scanResult] of this.scanResults) {
      if (scanResult.confidence > 0.7) { // Подключаемся только к устройствам с высокой уверенностью
        await this.connectToDevice(scanResult);
      }
    }
  }

  private async connectToDevice(scanResult: NetworkScanResult): Promise<void> {
    try {
      console.log(`🔗 Attempting to connect to ${scanResult.ipAddress} (${scanResult.deviceType})`);
      
      // Создание устройства в системе
      const deviceInfo = await this.createDeviceInfo(scanResult);
      
      // Проверка разрешений
      const permissionLevel = await this.determinePermissionLevel(deviceInfo);
      deviceInfo.permissionLevel = permissionLevel;
      
      // Регистрация устройства
      this.discoveredDevices.set(deviceInfo.id, deviceInfo);
      
      // Установка WebSocket соединения (если поддерживается)
      await this.establishWebSocketConnection(deviceInfo);
      
      console.log(`✅ Successfully connected to ${deviceInfo.name} (${deviceInfo.type})`);
      
      // Эмитим событие успешного подключения
      this.emit('deviceConnected', deviceInfo);
      
    } catch (error) {
      console.error(`❌ Failed to connect to ${scanResult.ipAddress}:`, error);
      this.emit('deviceConnectionFailed', scanResult, error);
    }
  }

  private async createDeviceInfo(scanResult: NetworkScanResult): Promise<DeviceInfo> {
    const deviceInfo: DeviceInfo = {
      id: scanResult.deviceId,
      name: scanResult.hostname || `${scanResult.deviceType}_${scanResult.ipAddress}`,
      type: scanResult.deviceType,
      ipAddress: scanResult.ipAddress,
      macAddress: scanResult.macAddress,
      capabilities: this.getDeviceCapabilities(scanResult.deviceType),
      permissionLevel: PermissionLevel.BASIC, // Будет обновлено
      isOnline: true,
      lastSeen: Date.now(),
      connectionType: 'wifi',
      fingerprint: this.generateDeviceFingerprint(scanResult)
    };

    return deviceInfo;
  }

  // ЭТАП 4.4: Permission System
  private async determinePermissionLevel(deviceInfo: DeviceInfo): Promise<PermissionLevel> {
    // Базовая логика разрешений
    switch (deviceInfo.type) {
      case DeviceType.IPHONE:
      case DeviceType.IPAD:
        return PermissionLevel.ADVANCED; // iPhone/iPad получают расширенные права
      
      case DeviceType.MACBOOK:
      case DeviceType.IMAC:
        return PermissionLevel.FULL; // Mac получает полные права
      
      case DeviceType.APPLE_WATCH:
        return PermissionLevel.STANDARD; // Watch стандартные права
      
      case DeviceType.AIRPODS:
      case DeviceType.HOMEPOD:
        return PermissionLevel.BASIC; // Аудио устройства базовые права
      
      case DeviceType.ANDROID_PHONE:
      case DeviceType.ANDROID_TABLET:
        return PermissionLevel.STANDARD; // Android стандартные права
      
      default:
        return PermissionLevel.BASIC; // Неизвестные устройства базовые права
    }
  }

  private getDeviceCapabilities(deviceType: DeviceType): string[] {
    const baseCapabilities = ['basic_communication', 'status_monitoring'];
    
    switch (deviceType) {
      case DeviceType.IPHONE:
        return [...baseCapabilities, 'voice_recognition', 'camera_access', 'location_services', 'push_notifications', 'offline_mode'];
      
      case DeviceType.IPAD:
        return [...baseCapabilities, 'voice_recognition', 'camera_access', 'large_display', 'split_screen', 'offline_mode'];
      
      case DeviceType.MACBOOK:
      case DeviceType.IMAC:
        return [...baseCapabilities, 'full_keyboard', 'file_system_access', 'development_tools', 'multiple_displays', 'high_processing_power'];
      
      case DeviceType.APPLE_WATCH:
        return [...baseCapabilities, 'health_monitoring', 'fitness_tracking', 'quick_actions', 'haptic_feedback'];
      
      case DeviceType.AIRPODS:
        return [...baseCapabilities, 'audio_playback', 'noise_cancellation', 'spatial_audio'];
      
      case DeviceType.HOMEPOD:
        return [...baseCapabilities, 'smart_home_control', 'music_streaming', 'voice_commands', 'room_audio'];
      
      default:
        return baseCapabilities;
    }
  }

  // ЭТАП 4.5: Multi-Device Coordination
  private async establishWebSocketConnection(deviceInfo: DeviceInfo): Promise<void> {
    try {
      // Попытка установки WebSocket соединения
      const wsUrl = `ws://${deviceInfo.ipAddress}:8080/jarvis`;
      
      // Здесь будет логика подключения к устройству
      console.log(`🔌 Establishing WebSocket connection to ${wsUrl}`);
      
      // Для демонстрации просто эмулируем успешное подключение
      this.emit('webSocketConnected', deviceInfo);
      
    } catch (error) {
      console.log(`⚠️ WebSocket connection failed for ${deviceInfo.name}, continuing with HTTP polling`);
    }
  }

  // Вспомогательные методы
  private parseNetworkRange(range: string): string[] {
    const [network, cidr] = range.split('/');
    const [a, b, c, d] = network.split('.').map(Number);
    const subnet = parseInt(cidr);
    
    const addresses: string[] = [];
    const hostBits = 32 - subnet;
    const numHosts = Math.pow(2, hostBits) - 2; // Исключаем network и broadcast
    
    for (let i = 1; i <= numHosts; i++) {
      const host = d + i;
      if (host <= 255) {
        addresses.push(`${a}.${b}.${c}.${host}`);
      }
    }
    
    return addresses;
  }

  private async pingDevice(ipAddress: string): Promise<boolean> {
    try {
      // РЕАЛЬНЫЙ PING через системную команду
      const execAsync = promisify(exec);
      const command = process.platform === 'win32' 
        ? `ping -n 1 -w ${this.scanConfig.timeout} ${ipAddress}`
        : `ping -c 1 -W ${Math.ceil(this.scanConfig.timeout / 1000)} ${ipAddress}`;
      
      const { stdout } = await execAsync(command);
      
      // Проверяем успешность ping
      return process.platform === 'win32' 
        ? !stdout.includes('Request timed out') && !stdout.includes('Destination host unreachable')
        : stdout.includes('1 received') || stdout.includes('1 packets received');
        
    } catch {
      return false;
    }
  }

  private async getHostname(ipAddress: string): Promise<string | undefined> {
    try {
      // РЕАЛЬНЫЙ DNS reverse lookup
      const lookupAsync = promisify(dns.reverse);
      const hostnames = await lookupAsync(ipAddress);
      return hostnames.length > 0 ? hostnames[0] : undefined;
    } catch {
      // Если DNS lookup не удался, попробуем через системную команду
      try {
        const execAsync = promisify(exec);
        const command = process.platform === 'win32' 
          ? `nslookup ${ipAddress}`
          : `host ${ipAddress}`;
        
        const { stdout } = await execAsync(command);
        
        if (process.platform === 'win32') {
          const match = stdout.match(/Name:\s+(.+)/);
          return match ? match[1].trim() : undefined;
        } else {
          const match = stdout.match(/domain name pointer\s+(.+)\./);
          return match ? match[1].trim() : undefined;
        }
      } catch {
        return undefined;
      }
    }
  }

  private async getMacAddress(ipAddress: string): Promise<string | undefined> {
    try {
      // РЕАЛЬНОЕ получение MAC адреса через ARP таблицу
      const execAsync = promisify(exec);
      let command: string;
      
      if (process.platform === 'win32') {
        command = `arp -a ${ipAddress}`;
      } else if (process.platform === 'darwin') {
        command = `arp -n ${ipAddress}`;
      } else {
        command = `arp -n ${ipAddress}`;
      }
      
      const { stdout } = await execAsync(command);
      
      // Парсим MAC адрес из вывода ARP
      const macRegex = /([0-9a-fA-F]{2}[:-]){5}[0-9a-fA-F]{2}/;
      const match = stdout.match(macRegex);
      
      if (match) {
        // Нормализуем формат MAC адреса к стандартному виду
        return match[0].replace(/-/g, ':').toLowerCase();
      }
      
      return undefined;
    } catch {
      return undefined;
    }
  }

  private async scanPorts(ipAddress: string): Promise<number[]> {
    const commonPorts = [22, 23, 25, 53, 80, 110, 143, 443, 993, 995, 3389, 5555, 8080, 62078];
    const openPorts: number[] = [];
    
    // РЕАЛЬНОЕ сканирование портов через TCP соединения
    const portScanPromises = commonPorts.map(port => this.checkPortOpen(ipAddress, port));
    const results = await Promise.allSettled(portScanPromises);
    
    results.forEach((result, index) => {
      if (result.status === 'fulfilled' && result.value) {
        openPorts.push(commonPorts[index]);
      }
    });
    
    return openPorts;
  }

  private async checkPortOpen(ipAddress: string, port: number): Promise<boolean> {
    return new Promise((resolve) => {
      const socket = new net.Socket();
      const timeout = 1000; // 1 секунда на порт
      
      socket.setTimeout(timeout);
      
      socket.on('connect', () => {
        socket.destroy();
        resolve(true);
      });
      
      socket.on('timeout', () => {
        socket.destroy();
        resolve(false);
      });
      
      socket.on('error', () => {
        resolve(false);
      });
      
      try {
        socket.connect(port, ipAddress);
      } catch {
        resolve(false);
      }
    });
  }

  private getManufacturerFromMac(macAddress: string): string | undefined {
    const oui = macAddress.slice(0, 8).toUpperCase();
    
    // Упрощенная база OUI
    const ouiDatabase: { [key: string]: string } = {
      '00:03:93': 'Apple',
      '00:50:E4': 'Apple',
      '00:1F:F3': 'Apple',
      '28:F0:76': 'Apple',
      '40:6C:8F': 'Apple',
      '00:16:CB': 'Apple',
      '00:1C:B3': 'Apple',
      '00:03:93': 'Apple',
      '08:00:07': 'Apple',
      '00:50:F2': 'Microsoft',
      '00:15:5D': 'Microsoft',
      '00:1B:21': 'Samsung',
      '00:16:32': 'Samsung',
      '00:1A:11': 'Google',
      '00:1E:C2': 'Google'
    };
    
    return ouiDatabase[oui];
  }

  private generateDeviceFingerprint(scanResult: NetworkScanResult): string {
    const data = [
      scanResult.ipAddress,
      scanResult.macAddress || '',
      scanResult.manufacturer || '',
      scanResult.openPorts.join(','),
      scanResult.deviceType
    ].join('|');
    
    // Простая хэш-функция для fingerprint
    let hash = 0;
    for (let i = 0; i < data.length; i++) {
      const char = data.charCodeAt(i);
      hash = ((hash << 5) - hash) + char;
      hash = hash & hash; // Convert to 32-bit integer
    }
    
    return Math.abs(hash).toString(36);
  }

  // Публичные методы для управления
  public getDiscoveredDevices(): DeviceInfo[] {
    return Array.from(this.discoveredDevices.values());
  }

  public getDeviceById(deviceId: string): DeviceInfo | undefined {
    return this.discoveredDevices.get(deviceId);
  }

  public async updateDevicePermissions(deviceId: string, permissionLevel: PermissionLevel): Promise<boolean> {
    const device = this.discoveredDevices.get(deviceId);
    if (!device) return false;
    
    device.permissionLevel = permissionLevel;
    this.discoveredDevices.set(deviceId, device);
    
    console.log(`🔒 Updated permissions for ${device.name}: ${permissionLevel}`);
    this.emit('devicePermissionsUpdated', device);
    
    return true;
  }

  public async removeDevice(deviceId: string): Promise<boolean> {
    const device = this.discoveredDevices.get(deviceId);
    if (!device) return false;
    
    this.discoveredDevices.delete(deviceId);
    this.connectedDevices.delete(deviceId);
    
    console.log(`🚫 Removed device: ${device.name}`);
    this.emit('deviceRemoved', device);
    
    return true;
  }

  public startContinuousScanning(intervalMs: number = 300000): void { // 5 минут по умолчанию
    this.stopContinuousScanning();
    
    this.scanInterval = setInterval(() => {
      this.startNetworkScan();
    }, intervalMs);
    
    console.log(`🔄 Started continuous scanning every ${intervalMs}ms`);
  }

  public stopContinuousScanning(): void {
    if (this.scanInterval) {
      clearInterval(this.scanInterval);
      this.scanInterval = null;
      console.log('⏹️ Stopped continuous scanning');
    }
  }

  public getSystemStatus() {
    return {
      isScanning: this.isScanning,
      discoveredDevicesCount: this.discoveredDevices.size,
      connectedDevicesCount: this.connectedDevices.size,
      scanResultsCount: this.scanResults.size,
      continuousScanning: this.scanInterval !== null,
      config: this.scanConfig
    };
  }
}

// Экспорт singleton instance
export const jarvisDeviceDiscovery = new JarvisDeviceDiscovery();
export { JarvisDeviceDiscovery };