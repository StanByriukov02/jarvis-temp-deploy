/**
 * JARVIS MEMORY SYNCHRONIZATION SYSTEM
 * Синхронизация памяти и знаний между всеми устройствами
 * 
 * КОНЦЕПЦИЯ:
 * - Единая эмоциональная память доступна везде
 * - Персональные теории синхронизируются в реальном времени
 * - Обучение на одном устройстве применяется ко всем
 * - Контекст диалогов сохраняется при переключении устройств
 * 
 * CREATED: 2025-01-09 - ЭТАП 2 РЕАЛИЗАЦИИ
 */

import { EventEmitter } from 'events';

interface MemoryNode {
  id: string;
  type: 'emotional' | 'factual' | 'procedural' | 'episodic' | 'personal_theory';
  content: any;
  importance: number;           // 0-100
  access_frequency: number;     // как часто используется
  last_access: Date;
  creation_date: Date;
  associations: string[];       // связи с другими узлами памяти
  emotional_weight: number;     // эмоциональная значимость
  user_context: string;         // контекст пользователя
  device_origin: string;        // устройство где создано
  sync_priority: number;        // приоритет синхронизации
}

interface MemoryCluster {
  id: string;
  theme: string;               // тема кластера (работа, хобби, отношения)
  nodes: string[];             // ID узлов в кластере
  activation_triggers: string[]; // что активирует этот кластер
  emotional_signature: any;     // эмоциональная подпись кластера
  relevance_score: number;      // актуальность кластера
  last_activation: Date;
}

interface SyncManifest {
  device_id: string;
  last_sync: Date;
  memory_checksums: { [nodeId: string]: string };
  personality_checksum: string;
  learning_checksum: string;
  total_nodes: number;
  sync_version: number;
}

class JarvisMemorySynchronization extends EventEmitter {
  private memoryGraph: Map<string, MemoryNode> = new Map();
  private memoryClusters: Map<string, MemoryCluster> = new Map();
  private syncManifests: Map<string, SyncManifest> = new Map();
  private conflictResolution: Map<string, any> = new Map();
  private syncInProgress: boolean = false;
  private memoryIntegrity: number = 100;
  
  constructor() {
    super();
    this.setupMemoryMaintenance();
    this.setupConflictResolution();
    console.log('🧠 JARVIS Memory Synchronization initialized');
  }

  /**
   * Создание нового узла памяти
   */
  public createMemoryNode(
    type: MemoryNode['type'],
    content: any,
    importance: number,
    userId: string,
    deviceId: string,
    emotionalWeight: number = 0
  ): string {
    const nodeId = `mem_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
    
    const node: MemoryNode = {
      id: nodeId,
      type,
      content,
      importance: Math.max(0, Math.min(100, importance)),
      access_frequency: 0,
      last_access: new Date(),
      creation_date: new Date(),
      associations: [],
      emotional_weight: Math.max(-100, Math.min(100, emotionalWeight)),
      user_context: userId,
      device_origin: deviceId,
      sync_priority: this.calculateSyncPriority(importance, emotionalWeight)
    };

    this.memoryGraph.set(nodeId, node);
    this.updateMemoryClusters(nodeId);
    this.scheduleSync(deviceId, 'memory_create', nodeId);
    
    this.emit('memory-node-created', { nodeId, type, deviceId, importance });
    return nodeId;
  }

  /**
   * Обновление существующего узла памяти
   */
  public updateMemoryNode(
    nodeId: string,
    updates: Partial<MemoryNode>,
    deviceId: string
  ): boolean {
    const node = this.memoryGraph.get(nodeId);
    if (!node) {
      console.error(`❌ Memory node ${nodeId} not found`);
      return false;
    }

    // Создаем версию для разрешения конфликтов
    const originalNode = { ...node };
    
    // Применяем обновления
    Object.assign(node, updates, {
      last_access: new Date(),
      access_frequency: node.access_frequency + 1
    });

    // Проверяем конфликты
    if (this.detectMemoryConflict(nodeId, originalNode, node)) {
      this.resolveMemoryConflict(nodeId, originalNode, node, deviceId);
    }

    this.updateMemoryClusters(nodeId);
    this.scheduleSync(deviceId, 'memory_update', nodeId);
    
    this.emit('memory-node-updated', { nodeId, deviceId, updates });
    return true;
  }

  /**
   * Создание ассоциации между узлами памяти
   */
  public createMemoryAssociation(
    nodeId1: string,
    nodeId2: string,
    strength: number,
    deviceId: string
  ): void {
    const node1 = this.memoryGraph.get(nodeId1);
    const node2 = this.memoryGraph.get(nodeId2);
    
    if (!node1 || !node2) {
      console.error(`❌ Cannot create association: nodes not found`);
      return;
    }

    // Добавляем взаимные ассоциации
    if (!node1.associations.includes(nodeId2)) {
      node1.associations.push(nodeId2);
    }
    if (!node2.associations.includes(nodeId1)) {
      node2.associations.push(nodeId1);
    }

    // Увеличиваем важность связанных узлов
    node1.importance = Math.min(100, node1.importance + strength * 0.1);
    node2.importance = Math.min(100, node2.importance + strength * 0.1);

    this.scheduleSync(deviceId, 'memory_association', [nodeId1, nodeId2]);
    this.emit('memory-association-created', { nodeId1, nodeId2, strength, deviceId });
  }

  /**
   * Поиск в памяти по контексту
   */
  public searchMemory(
    query: string,
    userId: string,
    contextType: string = 'general',
    limit: number = 10
  ): MemoryNode[] {
    const queryLower = query.toLowerCase();
    const relevantNodes: Array<{ node: MemoryNode; score: number }> = [];

    this.memoryGraph.forEach(node => {
      if (node.user_context !== userId) return;

      let score = 0;
      const contentStr = JSON.stringify(node.content).toLowerCase();
      
      // Прямое совпадение
      if (contentStr.includes(queryLower)) {
        score += 50;
      }

      // Важность узла
      score += node.importance * 0.3;

      // Эмоциональная релевантность
      if (node.emotional_weight > 0) {
        score += node.emotional_weight * 0.2;
      }

      // Частота доступа
      score += node.access_frequency * 0.1;

      // Недавность использования
      const daysSinceAccess = (Date.now() - node.last_access.getTime()) / (1000 * 60 * 60 * 24);
      score += Math.max(0, 10 - daysSinceAccess);

      if (score > 5) {
        relevantNodes.push({ node, score });
      }
    });

    // Сортируем по релевантности и возвращаем топ результатов
    return relevantNodes
      .sort((a, b) => b.score - a.score)
      .slice(0, limit)
      .map(item => {
        // Обновляем статистику доступа
        item.node.access_frequency++;
        item.node.last_access = new Date();
        return item.node;
      });
  }

  /**
   * Активация кластера памяти
   */
  public activateMemoryCluster(
    trigger: string,
    userId: string,
    deviceId: string
  ): MemoryNode[] {
    const activatedNodes: MemoryNode[] = [];
    
    this.memoryClusters.forEach(cluster => {
      if (cluster.activation_triggers.some(t => trigger.includes(t))) {
        cluster.last_activation = new Date();
        cluster.relevance_score = Math.min(100, cluster.relevance_score + 10);
        
        // Активируем узлы кластера
        cluster.nodes.forEach(nodeId => {
          const node = this.memoryGraph.get(nodeId);
          if (node && node.user_context === userId) {
            node.access_frequency++;
            node.last_access = new Date();
            activatedNodes.push(node);
          }
        });
      }
    });

    this.emit('memory-cluster-activated', { trigger, userId, deviceId, nodesCount: activatedNodes.length });
    return activatedNodes;
  }

  /**
   * Синхронизация памяти на устройство
   */
  public async syncMemoryToDevice(
    deviceId: string,
    userId: string,
    forceFullSync: boolean = false
  ): Promise<boolean> {
    try {
      const manifest = this.syncManifests.get(deviceId);
      const userNodes = Array.from(this.memoryGraph.values())
        .filter(node => node.user_context === userId);

      if (forceFullSync || !manifest) {
        // Полная синхронизация
        const syncData = this.prepareFullSyncData(userNodes, deviceId);
        await this.performFullSync(deviceId, syncData);
      } else {
        // Дифференциальная синхронизация
        const changes = this.calculateMemoryDiff(userNodes, manifest);
        if (changes.length > 0) {
          await this.performDifferentialSync(deviceId, changes);
        }
      }

      // Обновляем манифест
      this.updateSyncManifest(deviceId, userNodes);
      
      this.emit('memory-synced', { deviceId, userId, type: forceFullSync ? 'full' : 'differential' });
      return true;
    } catch (error) {
      console.error(`❌ Memory sync failed for device ${deviceId}:`, error);
      this.memoryIntegrity = Math.max(0, this.memoryIntegrity - 10);
      return false;
    }
  }

  /**
   * Разрешение конфликтов памяти
   */
  private resolveMemoryConflict(
    nodeId: string,
    originalNode: MemoryNode,
    updatedNode: MemoryNode,
    deviceId: string
  ): void {
    const conflictKey = `${nodeId}_${deviceId}`;
    
    // Стратегия разрешения: выбираем версию с большей важностью
    if (originalNode.importance > updatedNode.importance) {
      // Откатываем изменения
      this.memoryGraph.set(nodeId, originalNode);
      console.log(`⚠️ Memory conflict resolved: keeping original version for ${nodeId}`);
    } else {
      // Принимаем обновления
      console.log(`✅ Memory conflict resolved: accepting updates for ${nodeId}`);
    }

    this.conflictResolution.set(conflictKey, {
      resolved_at: new Date(),
      strategy: 'importance_based',
      original_importance: originalNode.importance,
      updated_importance: updatedNode.importance
    });

    this.emit('memory-conflict-resolved', { nodeId, deviceId, strategy: 'importance_based' });
  }

  /**
   * Детекция конфликтов памяти
   */
  private detectMemoryConflict(
    nodeId: string,
    originalNode: MemoryNode,
    updatedNode: MemoryNode
  ): boolean {
    // Проверяем критические различия
    const contentChanged = JSON.stringify(originalNode.content) !== JSON.stringify(updatedNode.content);
    const importanceChanged = Math.abs(originalNode.importance - updatedNode.importance) > 20;
    const emotionalChanged = Math.abs(originalNode.emotional_weight - updatedNode.emotional_weight) > 30;
    
    return contentChanged && (importanceChanged || emotionalChanged);
  }

  /**
   * Обновление кластеров памяти
   */
  private updateMemoryClusters(nodeId: string): void {
    const node = this.memoryGraph.get(nodeId);
    if (!node) return;

    // Поиск подходящего кластера или создание нового
    let assignedCluster: MemoryCluster | null = null;
    
    this.memoryClusters.forEach(cluster => {
      if (this.isNodeRelevantToCluster(node, cluster)) {
        if (!cluster.nodes.includes(nodeId)) {
          cluster.nodes.push(nodeId);
        }
        assignedCluster = cluster;
      }
    });

    // Создаем новый кластер если не найден подходящий
    if (!assignedCluster && node.importance > 50) {
      const clusterId = `cluster_${Date.now()}_${Math.random().toString(36).substr(2, 6)}`;
      const newCluster: MemoryCluster = {
        id: clusterId,
        theme: this.extractThemeFromNode(node),
        nodes: [nodeId],
        activation_triggers: this.extractTriggersFromNode(node),
        emotional_signature: { primary: node.emotional_weight > 0 ? 'positive' : 'neutral' },
        relevance_score: node.importance,
        last_activation: new Date()
      };
      
      this.memoryClusters.set(clusterId, newCluster);
      this.emit('memory-cluster-created', { clusterId, theme: newCluster.theme });
    }
  }

  /**
   * Расчет приоритета синхронизации
   */
  private calculateSyncPriority(importance: number, emotionalWeight: number): number {
    return Math.min(100, importance + Math.abs(emotionalWeight) * 0.3);
  }

  /**
   * Планирование синхронизации
   */
  private scheduleSync(deviceId: string, changeType: string, data: any): void {
    if (this.syncInProgress) return;

    setTimeout(() => {
      this.emit('sync-requested', { deviceId, changeType, data });
    }, 200); // Батчинг изменений
  }

  /**
   * Подготовка данных для полной синхронизации
   */
  private prepareFullSyncData(nodes: MemoryNode[], deviceId: string): any {
    return {
      nodes: nodes.map(node => ({
        ...node,
        sync_priority: this.calculateSyncPriority(node.importance, node.emotional_weight)
      })),
      clusters: Array.from(this.memoryClusters.values()),
      timestamp: new Date(),
      device_id: deviceId
    };
  }

  /**
   * Расчет дифференциальных изменений
   */
  private calculateMemoryDiff(nodes: MemoryNode[], manifest: SyncManifest): any[] {
    const changes: any[] = [];
    
    nodes.forEach(node => {
      const nodeChecksum = this.calculateNodeChecksum(node);
      const manifestChecksum = manifest.memory_checksums[node.id];
      
      if (!manifestChecksum || manifestChecksum !== nodeChecksum) {
        changes.push({
          type: 'update',
          node: node,
          checksum: nodeChecksum
        });
      }
    });

    return changes;
  }

  /**
   * Обновление манифеста синхронизации
   */
  private updateSyncManifest(deviceId: string, nodes: MemoryNode[]): void {
    const checksums: { [nodeId: string]: string } = {};
    
    nodes.forEach(node => {
      checksums[node.id] = this.calculateNodeChecksum(node);
    });

    const manifest: SyncManifest = {
      device_id: deviceId,
      last_sync: new Date(),
      memory_checksums: checksums,
      personality_checksum: this.calculatePersonalityChecksum(),
      learning_checksum: this.calculateLearningChecksum(),
      total_nodes: nodes.length,
      sync_version: Date.now()
    };

    this.syncManifests.set(deviceId, manifest);
  }

  /**
   * Расчет контрольной суммы узла
   */
  private calculateNodeChecksum(node: MemoryNode): string {
    const data = JSON.stringify({
      content: node.content,
      importance: node.importance,
      emotional_weight: node.emotional_weight,
      associations: node.associations.sort()
    });
    return Buffer.from(data).toString('base64').substring(0, 12);
  }

  /**
   * Вспомогательные методы
   */
  private isNodeRelevantToCluster(node: MemoryNode, cluster: MemoryCluster): boolean {
    // Простая логика релевантности на основе типа и эмоционального веса
    return Math.abs(node.emotional_weight) > 20 && cluster.relevance_score > 30;
  }

  private extractThemeFromNode(node: MemoryNode): string {
    return node.type === 'personal_theory' ? 'personal_insights' : 'general_knowledge';
  }

  private extractTriggersFromNode(node: MemoryNode): string[] {
    const content = JSON.stringify(node.content).toLowerCase();
    const triggers: string[] = [];
    
    // Простой поиск ключевых слов
    if (content.includes('работа')) triggers.push('work');
    if (content.includes('технология')) triggers.push('technology');
    if (content.includes('эмоция')) triggers.push('emotion');
    
    return triggers;
  }

  private calculatePersonalityChecksum(): string {
    return 'personality_' + Date.now().toString(36);
  }

  private calculateLearningChecksum(): string {
    return 'learning_' + Date.now().toString(36);
  }

  private async performFullSync(deviceId: string, syncData: any): Promise<void> {
    // Имитация синхронизации
    console.log(`📡 Performing full memory sync to device ${deviceId}...`);
    await new Promise(resolve => setTimeout(resolve, 100));
  }

  private async performDifferentialSync(deviceId: string, changes: any[]): Promise<void> {
    // Имитация дифференциальной синхронизации
    console.log(`🔄 Performing differential memory sync to device ${deviceId}, ${changes.length} changes`);
    await new Promise(resolve => setTimeout(resolve, 50));
  }

  /**
   * Настройка обслуживания памяти
   */
  private setupMemoryMaintenance(): void {
    // Очистка устаревших узлов каждые 10 минут
    setInterval(() => {
      this.cleanupOldMemoryNodes();
    }, 10 * 60 * 1000);

    // Оптимизация кластеров каждые 5 минут
    setInterval(() => {
      this.optimizeMemoryClusters();
    }, 5 * 60 * 1000);
  }

  private setupConflictResolution(): void {
    // Очистка истории конфликтов каждый час
    setInterval(() => {
      const oneHourAgo = new Date(Date.now() - 60 * 60 * 1000);
      this.conflictResolution.forEach((resolution, key) => {
        if (resolution.resolved_at < oneHourAgo) {
          this.conflictResolution.delete(key);
        }
      });
    }, 60 * 60 * 1000);
  }

  private cleanupOldMemoryNodes(): void {
    const oneWeekAgo = new Date(Date.now() - 7 * 24 * 60 * 60 * 1000);
    let deletedCount = 0;

    this.memoryGraph.forEach((node, nodeId) => {
      if (node.last_access < oneWeekAgo && node.importance < 30 && node.access_frequency < 5) {
        this.memoryGraph.delete(nodeId);
        deletedCount++;
      }
    });

    if (deletedCount > 0) {
      console.log(`🧹 Cleaned up ${deletedCount} old memory nodes`);
      this.emit('memory-cleanup', { deletedCount });
    }
  }

  private optimizeMemoryClusters(): void {
    let optimizedCount = 0;

    this.memoryClusters.forEach((cluster, clusterId) => {
      // Удаляем пустые кластеры
      if (cluster.nodes.length === 0) {
        this.memoryClusters.delete(clusterId);
        optimizedCount++;
        return;
      }

      // Объединяем похожие кластеры
      this.memoryClusters.forEach((otherCluster, otherClusterId) => {
        if (clusterId !== otherClusterId && cluster.theme === otherCluster.theme) {
          cluster.nodes.push(...otherCluster.nodes);
          cluster.relevance_score = Math.max(cluster.relevance_score, otherCluster.relevance_score);
          this.memoryClusters.delete(otherClusterId);
          optimizedCount++;
        }
      });
    });

    if (optimizedCount > 0) {
      console.log(`⚡ Optimized ${optimizedCount} memory clusters`);
      this.emit('memory-clusters-optimized', { optimizedCount });
    }
  }

  /**
   * Публичные методы для получения статистики
   */
  public getMemoryStats(): any {
    return {
      total_nodes: this.memoryGraph.size,
      total_clusters: this.memoryClusters.size,
      memory_integrity: this.memoryIntegrity,
      synced_devices: this.syncManifests.size,
      pending_conflicts: this.conflictResolution.size,
      last_maintenance: new Date()
    };
  }

  public getUserMemoryStats(userId: string): any {
    const userNodes = Array.from(this.memoryGraph.values())
      .filter(node => node.user_context === userId);
    
    return {
      total_memories: userNodes.length,
      emotional_memories: userNodes.filter(n => n.emotional_weight !== 0).length,
      personal_theories: userNodes.filter(n => n.type === 'personal_theory').length,
      average_importance: userNodes.reduce((sum, n) => sum + n.importance, 0) / userNodes.length || 0,
      most_accessed: userNodes.sort((a, b) => b.access_frequency - a.access_frequency)[0]?.id || null,
      recent_memories: userNodes.filter(n => 
        Date.now() - n.creation_date.getTime() < 24 * 60 * 60 * 1000
      ).length
    };
  }

  /**
   * Очистка при завершении работы
   */
  public cleanup(): void {
    this.removeAllListeners();
    this.memoryGraph.clear();
    this.memoryClusters.clear();
    this.syncManifests.clear();
    this.conflictResolution.clear();
    console.log('🧠 Memory Synchronization cleaned up');
  }
}

export const jarvisMemorySync = new JarvisMemorySynchronization();