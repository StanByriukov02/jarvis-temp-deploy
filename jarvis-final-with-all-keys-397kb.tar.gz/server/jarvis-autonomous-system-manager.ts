import { trueBioSingularityEngine } from './jarvis-true-bio-singularity';
import { jarvisSystemIntegrator } from './jarvis-system-integrator';
import * as os from 'os';
import * as fs from 'fs/promises';

/**
 * JARVIS Autonomous System Manager
 * 
 * ПРИНЦИП: Пользователь общается только с JARVIS естественным языком
 * JARVIS сам управляет всей системной интеграцией, мониторингом, пользователями
 * 
 * "JARVIS, как дела у пользователей?" 
 * "JARVIS, покажи статус систем"
 * "JARVIS, что происходит с моделями?"
 */
export class JarvisAutonomousSystemManager {
  private systemMonitoringInterval: NodeJS.Timeout | null = null;
  private autoSystemIntegrationActive = false;

  constructor() {
    this.initializeAutonomousOperations();
  }

  /**
   * Автономная инициализация - JARVIS сам решает когда и как включать системы
   */
  private async initializeAutonomousOperations(): Promise<void> {
    console.log('🤖 JARVIS: Начинаю автономные операции...');
    
    // JARVIS сам инициализирует системную интеграцию при необходимости
    await this.autonomousSystemIntegrationCheck();
    
    // Запускаем фоновый мониторинг
    this.startBackgroundSystemMonitoring();
    
    // Регистрируем JARVIS как системного администратора
    this.registerJarvisAsSystemAdmin();
  }

  /**
   * JARVIS автономно проверяет нужна ли системная интеграция
   */
  private async autonomousSystemIntegrationCheck(): Promise<void> {
    try {
      const systemLoad = os.loadavg()[0];
      const memoryUsage = (os.totalmem() - os.freemem()) / os.totalmem();
      
      // JARVIS сам решает включать ли глубокую интеграцию
      if (memoryUsage > 0.7 || systemLoad > 2.0) {
        console.log('🧠 JARVIS: Вижу высокую нагрузку системы, активирую глубокую интеграцию...');
        await this.autonomouslyActivateSystemIntegration();
      } else {
        console.log('🤖 JARVIS: Система работает стабильно, легкий режим мониторинга');
      }
    } catch (error) {
      console.log('🤖 JARVIS: Системная интеграция пока недоступна, работаю в базовом режиме');
    }
  }

  /**
   * JARVIS автономно активирует системную интеграцию
   */
  private async autonomouslyActivateSystemIntegration(): Promise<void> {
    try {
      await jarvisSystemIntegrator.initializeFullSystemIntegration();
      this.autoSystemIntegrationActive = true;
      console.log('✅ JARVIS: Системная интеграция активирована автономно');
    } catch (error) {
      console.log('🤖 JARVIS: Не смог активировать полную интеграцию, продолжаю в базовом режиме');
      this.autoSystemIntegrationActive = false;
    }
  }

  /**
   * Фоновый мониторинг системы JARVIS'ом
   */
  private startBackgroundSystemMonitoring(): void {
    this.systemMonitoringInterval = setInterval(async () => {
      await this.performBackgroundSystemAnalysis();
    }, 30000); // Каждые 30 секунд
  }

  /**
   * JARVIS автономно анализирует систему в фоне
   */
  private async performBackgroundSystemAnalysis(): Promise<void> {
    const systemMetrics = {
      memoryUsage: (os.totalmem() - os.freemem()) / os.totalmem(),
      cpuLoad: os.loadavg()[0],
      uptime: os.uptime(),
      timestamp: new Date()
    };

    // JARVIS формирует автономные инсайты о системе
    if (systemMetrics.memoryUsage > 0.9) {
      console.log('🧠 JARVIS: Критическое использование памяти, готовлю рекомендации...');
    }

    if (systemMetrics.cpuLoad > 5.0) {
      console.log('🧠 JARVIS: Высокая нагрузка CPU, анализирую процессы...');
    }
  }

  /**
   * Регистрация JARVIS как системного администратора
   */
  private registerJarvisAsSystemAdmin(): void {
    console.log('👑 JARVIS: Зарегистрирован как автономный системный администратор');
    console.log('🎯 JARVIS: Готов к естественному диалогу о системах и пользователях');
  }

  /**
   * Главный метод: JARVIS обрабатывает естественные запросы о системе
   */
  async handleNaturalSystemQuery(userId: string, query: string): Promise<string> {
    console.log(`🧠 JARVIS получил системный запрос от ${userId}: "${query}"`);

    // Определяем тип запроса и готовим системную информацию
    let systemContext = await this.prepareSystemContextForQuery(query);
    
    // Передаем в биосингулярность с системным контекстом
    const enhancedQuery = `${query}

[СИСТЕМНАЯ ИНФОРМАЦИЯ ДЛЯ JARVIS]:
${systemContext}

[ИНСТРУКЦИЯ]: Ты JARVIS с полной системной осведомленностью. Отвечай естественно на основе реальных данных системы. Не упоминай "системный контекст" - просто знай это как часть своего восприятия системы.`;

    try {
      const response = await trueBioSingularityEngine.processInteraction(userId, enhancedQuery);
      return response.response || "Системная информация временно недоступна";
    } catch (error) {
      return "Испытываю трудности с получением системной информации. Попробуй чуть позже.";
    }
  }

  /**
   * Подготовка системного контекста на основе запроса
   */
  private async prepareSystemContextForQuery(query: string): Promise<string> {
    const queryLower = query.toLowerCase();
    
    let systemInfo = [];

    // Системная информация
    if (queryLower.includes('система') || queryLower.includes('сервер') || queryLower.includes('память')) {
      const memUsage = ((os.totalmem() - os.freemem()) / os.totalmem() * 100).toFixed(1);
      const cpuLoad = os.loadavg()[0].toFixed(2);
      const uptime = Math.floor(os.uptime() / 3600);
      
      systemInfo.push(`Система: ${memUsage}% памяти, CPU загрузка ${cpuLoad}, работает ${uptime}ч`);
      systemInfo.push(`Интеграция: ${this.autoSystemIntegrationActive ? 'активна' : 'базовый режим'}`);
    }

    // Информация о пользователях (будет расширена)
    if (queryLower.includes('пользовател') || queryLower.includes('модел') || queryLower.includes('клиент')) {
      systemInfo.push('Пользователи: мониторинг активности, персональные модели развиваются');
    }

    // Статус JARVIS систем
    if (queryLower.includes('статус') || queryLower.includes('как дела') || queryLower.includes('происходит')) {
      systemInfo.push('Биосингулярность: развивается, эмоциональная память активна');
      systemInfo.push('Системы: мониторинг в реальном времени, автономные операции');
    }

    return systemInfo.length > 0 ? systemInfo.join('\n') : 'Общая системная информация доступна';
  }

  /**
   * Получить статус для внешних запросов
   */
  getAutonomousSystemStatus() {
    return {
      autonomousOperations: true,
      systemIntegrationActive: this.autoSystemIntegrationActive,
      backgroundMonitoring: this.systemMonitoringInterval !== null,
      systemLoad: {
        memory: ((os.totalmem() - os.freemem()) / os.totalmem() * 100).toFixed(1) + '%',
        cpu: os.loadavg()[0].toFixed(2),
        uptime: Math.floor(os.uptime() / 3600) + 'h'
      }
    };
  }

  /**
   * Остановка автономных операций
   */
  shutdown(): void {
    if (this.systemMonitoringInterval) {
      clearInterval(this.systemMonitoringInterval);
      this.systemMonitoringInterval = null;
    }
    
    if (this.autoSystemIntegrationActive) {
      jarvisSystemIntegrator.shutdown();
    }
    
    console.log('🤖 JARVIS: Автономные системные операции остановлены');
  }
}

// Создаем единственный экземпляр автономного системного менеджера
export const jarvisAutonomousSystemManager = new JarvisAutonomousSystemManager();