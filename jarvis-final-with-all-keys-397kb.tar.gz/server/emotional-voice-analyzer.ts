import OpenAI from 'openai';

interface VoiceMetrics {
  volume: number;
  pitch: number;
  tempo: number;
  pauseFrequency: number;
  voiceStability: number;
}

interface EmotionalState {
  energy: 'high' | 'medium' | 'low';
  stress: 'high' | 'medium' | 'low';
  confidence: 'high' | 'medium' | 'low';
  engagement: 'high' | 'medium' | 'low';
  mood: 'positive' | 'neutral' | 'negative';
  fatigue: 'high' | 'medium' | 'low';
}

interface EmotionalAnalysis {
  emotionalState: EmotionalState;
  confidence: number; // 0-100
  recommendations: string[];
  responseStyle: 'energetic' | 'supportive' | 'calm' | 'motivational';
  timestamp: Date;
}

export class EmotionalVoiceAnalyzer {
  private openai: OpenAI;

  constructor() {
    if (!process.env.OPENAI_API_KEY) {
      throw new Error('OPENAI_API_KEY is required for emotional analysis');
    }
    this.openai = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });
  }

  /**
   * Analyze voice characteristics from audio buffer
   */
  analyzeVoiceMetrics(audioBuffer: Buffer, duration: number): VoiceMetrics {
    // Basic audio analysis - in production would use more sophisticated audio processing
    const dataLength = audioBuffer.length;
    const avgAmplitude = this.calculateAverageAmplitude(audioBuffer);
    
    return {
      volume: this.normalizeVolume(avgAmplitude),
      pitch: this.estimatePitch(audioBuffer),
      tempo: this.calculateTempo(dataLength, duration),
      pauseFrequency: this.calculatePauseFrequency(audioBuffer, duration),
      voiceStability: this.calculateStability(audioBuffer)
    };
  }

  /**
   * Advanced emotional analysis using AI
   */
  async analyzeEmotionalState(
    transcription: string, 
    voiceMetrics: VoiceMetrics,
    previousAnalyses: EmotionalAnalysis[] = []
  ): Promise<EmotionalAnalysis> {
    const contextualHistory = this.buildEmotionalContext(previousAnalyses);
    
    const prompt = this.buildAnalysisPrompt(transcription, voiceMetrics, contextualHistory);
    
    try {
      const response = await this.openai.chat.completions.create({
        model: "gpt-4o", // the newest OpenAI model is "gpt-4o" which was released May 13, 2024. do not change this unless explicitly requested by the user
        messages: [
          {
            role: "system",
            content: "You are an advanced emotional intelligence analyzer specializing in voice and speech patterns. Analyze the user's emotional state and provide actionable insights for a personal AI assistant. Respond in JSON format."
          },
          {
            role: "user",
            content: prompt
          }
        ],
        response_format: { type: "json_object" },
        temperature: 0.3
      });

      const analysis = JSON.parse(response.choices[0].message.content || '{}');
      
      return {
        emotionalState: this.validateEmotionalState(analysis.emotionalState),
        confidence: Math.min(100, Math.max(0, analysis.confidence || 50)),
        recommendations: analysis.recommendations || [],
        responseStyle: this.determineResponseStyle(analysis.emotionalState),
        timestamp: new Date()
      };
      
    } catch (error) {
      console.error('Emotional analysis failed:', error);
      return this.getFallbackAnalysis(voiceMetrics);
    }
  }

  /**
   * Generate contextual recommendations based on emotional state
   */
  generateContextualRecommendations(
    analysis: EmotionalAnalysis,
    timeOfDay: string,
    currentActivity: string
  ): string[] {
    const recommendations: string[] = [];
    const { emotionalState } = analysis;

    // Energy-based recommendations
    if (emotionalState.energy === 'low') {
      if (timeOfDay === 'morning') {
        recommendations.push("Consider starting with a light energizing routine");
      } else if (timeOfDay === 'afternoon') {
        recommendations.push("A short break or light movement might help restore energy");
      }
    }

    // Stress-based recommendations
    if (emotionalState.stress === 'high') {
      recommendations.push("I notice elevated stress - would you like to try a brief breathing exercise?");
      if (currentActivity === 'work') {
        recommendations.push("Consider breaking this task into smaller chunks");
      }
    }

    // Confidence-based recommendations
    if (emotionalState.confidence === 'low') {
      recommendations.push("Let's focus on one small win to build momentum");
    }

    // Engagement-based recommendations
    if (emotionalState.engagement === 'low') {
      recommendations.push("Perhaps we could switch to a different type of activity");
    }

    // Fatigue-based recommendations
    if (emotionalState.fatigue === 'high') {
      recommendations.push("Your voice suggests fatigue - consider a restorative break");
    }

    return recommendations;
  }

  /**
   * Determine optimal response style for JARVIS
   */
  private determineResponseStyle(emotionalState: EmotionalState): 'energetic' | 'supportive' | 'calm' | 'motivational' {
    if (emotionalState.stress === 'high' || emotionalState.fatigue === 'high') {
      return 'calm';
    }
    
    if (emotionalState.confidence === 'low' || emotionalState.mood === 'negative') {
      return 'supportive';
    }
    
    if (emotionalState.energy === 'high' && emotionalState.engagement === 'high') {
      return 'energetic';
    }
    
    return 'motivational';
  }

  private buildAnalysisPrompt(
    transcription: string, 
    voiceMetrics: VoiceMetrics, 
    context: string
  ): string {
    return `
Analyze the emotional state from this voice interaction:

TRANSCRIPTION: "${transcription}"

VOICE METRICS:
- Volume: ${voiceMetrics.volume}/100
- Pitch: ${voiceMetrics.pitch}/100  
- Tempo: ${voiceMetrics.tempo}/100
- Pause Frequency: ${voiceMetrics.pauseFrequency}/100
- Voice Stability: ${voiceMetrics.voiceStability}/100

${context}

Provide analysis in this JSON format:
{
  "emotionalState": {
    "energy": "high|medium|low",
    "stress": "high|medium|low", 
    "confidence": "high|medium|low",
    "engagement": "high|medium|low",
    "mood": "positive|neutral|negative",
    "fatigue": "high|medium|low"
  },
  "confidence": 85,
  "recommendations": ["specific actionable recommendations"]
}

Focus on patterns that indicate stress, fatigue, confidence levels, and engagement.
    `;
  }

  private buildEmotionalContext(previousAnalyses: EmotionalAnalysis[]): string {
    if (previousAnalyses.length === 0) return "";
    
    const recent = previousAnalyses.slice(-3);
    return `
RECENT EMOTIONAL PATTERNS:
${recent.map((analysis, i) => 
  `${i + 1}. Energy: ${analysis.emotionalState.energy}, Stress: ${analysis.emotionalState.stress}, Mood: ${analysis.emotionalState.mood}`
).join('\n')}
    `;
  }

  // Audio processing helpers
  private calculateAverageAmplitude(buffer: Buffer): number {
    let sum = 0;
    for (let i = 0; i < buffer.length; i += 2) {
      const sample = buffer.readInt16LE(i);
      sum += Math.abs(sample);
    }
    return sum / (buffer.length / 2);
  }

  private normalizeVolume(amplitude: number): number {
    return Math.min(100, (amplitude / 32768) * 100);
  }

  private estimatePitch(buffer: Buffer): number {
    // Simplified pitch estimation - in production would use autocorrelation
    const samples = [];
    for (let i = 0; i < Math.min(buffer.length, 1000); i += 2) {
      samples.push(buffer.readInt16LE(i));
    }
    
    const variance = this.calculateVariance(samples);
    return Math.min(100, Math.max(0, (variance / 1000000) * 100));
  }

  private calculateTempo(dataLength: number, duration: number): number {
    const estimatedSyllables = dataLength / 1000; // rough estimation
    const syllablesPerSecond = estimatedSyllables / duration;
    return Math.min(100, (syllablesPerSecond / 5) * 100); // normalize to 0-100
  }

  private calculatePauseFrequency(buffer: Buffer, duration: number): number {
    let silentPeriods = 0;
    let consecutiveSilent = 0;
    const threshold = 1000;
    
    for (let i = 0; i < buffer.length; i += 2) {
      const sample = Math.abs(buffer.readInt16LE(i));
      if (sample < threshold) {
        consecutiveSilent++;
      } else {
        if (consecutiveSilent > 100) { // roughly 0.1 seconds of silence
          silentPeriods++;
        }
        consecutiveSilent = 0;
      }
    }
    
    return Math.min(100, (silentPeriods / duration) * 10);
  }

  private calculateStability(buffer: Buffer): number {
    const samples = [];
    for (let i = 0; i < buffer.length; i += 2) {
      samples.push(Math.abs(buffer.readInt16LE(i)));
    }
    
    const variance = this.calculateVariance(samples);
    const stability = Math.max(0, 100 - (variance / 10000));
    return Math.min(100, stability);
  }

  private calculateVariance(samples: number[]): number {
    const mean = samples.reduce((a, b) => a + b, 0) / samples.length;
    const variance = samples.reduce((a, b) => a + Math.pow(b - mean, 2), 0) / samples.length;
    return variance;
  }

  private validateEmotionalState(state: any): EmotionalState {
    return {
      energy: ['high', 'medium', 'low'].includes(state?.energy) ? state.energy : 'medium',
      stress: ['high', 'medium', 'low'].includes(state?.stress) ? state.stress : 'medium',
      confidence: ['high', 'medium', 'low'].includes(state?.confidence) ? state.confidence : 'medium',
      engagement: ['high', 'medium', 'low'].includes(state?.engagement) ? state.engagement : 'medium',
      mood: ['positive', 'neutral', 'negative'].includes(state?.mood) ? state.mood : 'neutral',
      fatigue: ['high', 'medium', 'low'].includes(state?.fatigue) ? state.fatigue : 'medium'
    };
  }

  private getFallbackAnalysis(voiceMetrics: VoiceMetrics): EmotionalAnalysis {
    return {
      emotionalState: {
        energy: voiceMetrics.volume > 60 ? 'high' : voiceMetrics.volume > 30 ? 'medium' : 'low',
        stress: voiceMetrics.tempo > 70 ? 'high' : 'medium',
        confidence: voiceMetrics.voiceStability > 60 ? 'high' : 'medium',
        engagement: voiceMetrics.pitch > 50 ? 'high' : 'medium',
        mood: 'neutral',
        fatigue: voiceMetrics.tempo < 30 ? 'high' : 'medium'
      },
      confidence: 30,
      recommendations: ['Unable to perform detailed analysis - basic metrics used'],
      responseStyle: 'supportive',
      timestamp: new Date()
    };
  }
}

export const emotionalVoiceAnalyzer = new EmotionalVoiceAnalyzer();