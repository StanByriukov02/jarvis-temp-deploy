/**
 * JARVIS ArXiv + Google + YouTube Integration Engine
 * Интеграция всех научных и медиа источников для breakthrough анализа
 */

import { db } from './db';
import { jarvisBioStates } from '../shared/schema';
import { eq } from 'drizzle-orm';

interface ArxivPaper {
  id: string;
  title: string;
  abstract: string;
  authors: string[];
  categories: string[];
  published: Date;
  url: string;
  relevanceScore: number;
}

interface GoogleSearchResult {
  title: string;
  snippet: string;
  link: string;
  source: string;
  relevanceScore: number;
}

interface YouTubeVideo {
  id: string;
  title: string;
  description: string;
  channelTitle: string;
  publishedAt: Date;
  viewCount: number;
  likeCount: number;
  duration: string;
  url: string;
  relevanceScore: number;
}

export class JarvisArxivGoogleYouTubeIntegration {
  private arxivBaseUrl = 'http://export.arxiv.org/api/query';
  private googleApiKey?: string;
  private youtubeApiKey?: string;

  constructor() {
    this.googleApiKey = process.env.GOOGLE_API_KEY;
    this.youtubeApiKey = process.env.YOUTUBE_API_KEY;
  }

  /**
   * ARXIV НАУЧНЫЕ ПУБЛИКАЦИИ
   * Поиск по arXiv с фильтрацией по релевантности
   */
  async searchArxivPapers(query: string, maxResults: number = 20): Promise<ArxivPaper[]> {
    console.log(`📚 Поиск ArXiv публикаций: ${query}`);
    
    try {
      const searchQuery = encodeURIComponent(query);
      const url = `${this.arxivBaseUrl}?search_query=all:${searchQuery}&start=0&max_results=${maxResults}&sortBy=relevance&sortOrder=descending`;
      
      const response = await fetch(url);
      const xmlText = await response.text();
      
      // Парсинг XML ответа
      const papers = this.parseArxivResponse(xmlText);
      
      // Фильтрация по релевантности
      const relevantPapers = papers.filter(paper => paper.relevanceScore > 0.3);
      
      console.log(`📊 Найдено ${relevantPapers.length} релевантных ArXiv публикаций`);
      return relevantPapers;
      
    } catch (error) {
      console.error('❌ Ошибка поиска ArXiv:', error);
      return [];
    }
  }

  /**
   * GOOGLE SEARCH ENGINE
   * Поиск научных и технических материалов через Google
   */
  async searchGoogleScientific(query: string, maxResults: number = 10): Promise<GoogleSearchResult[]> {
    console.log(`🔍 Google поиск: ${query}`);
    
    if (!this.googleApiKey) {
      console.warn('⚠️ Google API key не найден - возвращаю mock данные');
      return this.getMockGoogleResults(query);
    }
    
    try {
      const searchQuery = encodeURIComponent(`${query} scientific research technology`);
      const url = `https://www.googleapis.com/customsearch/v1?key=${this.googleApiKey}&cx=YOUR_SEARCH_ENGINE_ID&q=${searchQuery}&num=${maxResults}`;
      
      const response = await fetch(url);
      const data = await response.json();
      
      if (data.items) {
        const results = data.items.map((item: any) => ({
          title: item.title,
          snippet: item.snippet,
          link: item.link,
          source: item.displayLink,
          relevanceScore: this.calculateRelevanceScore(item.title + ' ' + item.snippet, query)
        }));
        
        console.log(`📊 Найдено ${results.length} Google результатов`);
        return results;
      }
      
      return [];
      
    } catch (error) {
      console.error('❌ Ошибка Google поиска:', error);
      return this.getMockGoogleResults(query);
    }
  }

  /**
   * YOUTUBE VIDEO INTELLIGENCE
   * Поиск образовательных и научных видео
   */
  async searchYouTubeEducational(query: string, maxResults: number = 10): Promise<YouTubeVideo[]> {
    console.log(`🎥 YouTube поиск: ${query}`);
    
    if (!this.youtubeApiKey) {
      console.warn('⚠️ YouTube API key не найден - возвращаю mock данные');
      return this.getMockYouTubeResults(query);
    }
    
    try {
      const searchQuery = encodeURIComponent(`${query} educational tutorial science technology`);
      const url = `https://www.googleapis.com/youtube/v3/search?part=snippet&maxResults=${maxResults}&q=${searchQuery}&type=video&order=relevance&key=${this.youtubeApiKey}`;
      
      const response = await fetch(url);
      const data = await response.json();
      
      if (data.items) {
        const videos = await Promise.all(
          data.items.map(async (item: any) => {
            const videoDetails = await this.getVideoDetails(item.id.videoId);
            return {
              id: item.id.videoId,
              title: item.snippet.title,
              description: item.snippet.description,
              channelTitle: item.snippet.channelTitle,
              publishedAt: new Date(item.snippet.publishedAt),
              viewCount: videoDetails.viewCount,
              likeCount: videoDetails.likeCount,
              duration: videoDetails.duration,
              url: `https://www.youtube.com/watch?v=${item.id.videoId}`,
              relevanceScore: this.calculateRelevanceScore(item.snippet.title + ' ' + item.snippet.description, query)
            };
          })
        );
        
        console.log(`📊 Найдено ${videos.length} YouTube видео`);
        return videos;
      }
      
      return [];
      
    } catch (error) {
      console.error('❌ Ошибка YouTube поиска:', error);
      return this.getMockYouTubeResults(query);
    }
  }

  /**
   * COMPREHENSIVE SEARCH
   * Поиск по всем источникам с агрегацией результатов
   */
  async comprehensiveSearch(query: string) {
    console.log(`🚀 Comprehensive search: ${query}`);
    
    const [arxivPapers, googleResults, youtubeVideos] = await Promise.all([
      this.searchArxivPapers(query, 15),
      this.searchGoogleScientific(query, 10),
      this.searchYouTubeEducational(query, 8)
    ]);
    
    // Агрегация и ранжирование результатов
    const aggregatedResults = {
      arxiv: arxivPapers.slice(0, 10),
      google: googleResults.slice(0, 8),
      youtube: youtubeVideos.slice(0, 5),
      totalResults: arxivPapers.length + googleResults.length + youtubeVideos.length,
      topRecommendations: this.getTopRecommendations(arxivPapers, googleResults, youtubeVideos)
    };
    
    console.log(`📊 Comprehensive search завершен: ${aggregatedResults.totalResults} результатов`);
    return aggregatedResults;
  }

  /**
   * BREAKTHROUGH ANALYSIS
   * Анализ результатов для поиска breakthrough технологий
   */
  async breakthroughAnalysis(query: string) {
    console.log(`💡 Breakthrough analysis: ${query}`);
    
    const results = await this.comprehensiveSearch(query);
    
    const breakthroughIndicators = [
      'breakthrough', 'novel', 'innovative', 'revolutionary', 'quantum', 'nanotechnology',
      'artificial intelligence', 'machine learning', 'biotechnology', 'fusion', 'superconductor'
    ];
    
    // Анализ breakthrough потенциала
    const breakthroughScore = this.calculateBreakthroughScore(results, breakthroughIndicators);
    
    return {
      ...results,
      breakthroughScore,
      breakthroughIndicators: breakthroughIndicators.filter(indicator => 
        JSON.stringify(results).toLowerCase().includes(indicator)
      ),
      recommendation: breakthroughScore > 0.7 ? 'HIGH_BREAKTHROUGH_POTENTIAL' : 
                     breakthroughScore > 0.4 ? 'MODERATE_BREAKTHROUGH_POTENTIAL' : 'STANDARD_RESEARCH'
    };
  }

  // ==========================================
  // HELPER METHODS
  // ==========================================

  private parseArxivResponse(xmlText: string): ArxivPaper[] {
    const papers: ArxivPaper[] = [];
    
    // Простой парсинг XML (в production использовать xml2js)
    const entryMatches = xmlText.match(/<entry>(.*?)<\/entry>/gs) || [];
    
    entryMatches.forEach(entry => {
      const id = this.extractXmlValue(entry, 'id');
      const title = this.extractXmlValue(entry, 'title');
      const abstract = this.extractXmlValue(entry, 'summary');
      const published = this.extractXmlValue(entry, 'published');
      
      if (id && title && abstract) {
        papers.push({
          id,
          title: title.replace(/\s+/g, ' ').trim(),
          abstract: abstract.replace(/\s+/g, ' ').trim(),
          authors: this.extractAuthors(entry),
          categories: this.extractCategories(entry),
          published: new Date(published),
          url: id,
          relevanceScore: 0.8 // Базовый score, можно улучшить
        });
      }
    });
    
    return papers;
  }

  private extractXmlValue(xml: string, tag: string): string {
    const match = xml.match(new RegExp(`<${tag}[^>]*>(.*?)</${tag}>`, 's'));
    return match ? match[1] : '';
  }

  private extractAuthors(entry: string): string[] {
    const authorMatches = entry.match(/<author>.*?<name>(.*?)<\/name>/g) || [];
    return authorMatches.map(match => {
      const nameMatch = match.match(/<name>(.*?)<\/name>/);
      return nameMatch ? nameMatch[1] : '';
    }).filter(name => name);
  }

  private extractCategories(entry: string): string[] {
    const categoryMatches = entry.match(/<category\s+term="([^"]+)"/g) || [];
    return categoryMatches.map(match => {
      const termMatch = match.match(/term="([^"]+)"/);
      return termMatch ? termMatch[1] : '';
    }).filter(term => term);
  }

  private calculateRelevanceScore(text: string, query: string): number {
    const textLower = text.toLowerCase();
    const queryWords = query.toLowerCase().split(' ');
    
    let score = 0;
    queryWords.forEach(word => {
      if (textLower.includes(word)) {
        score += 0.2;
      }
    });
    
    return Math.min(score, 1.0);
  }

  private async getVideoDetails(videoId: string) {
    try {
      const url = `https://www.googleapis.com/youtube/v3/videos?part=statistics,contentDetails&id=${videoId}&key=${this.youtubeApiKey}`;
      const response = await fetch(url);
      const data = await response.json();
      
      if (data.items && data.items[0]) {
        const item = data.items[0];
        return {
          viewCount: parseInt(item.statistics.viewCount || '0'),
          likeCount: parseInt(item.statistics.likeCount || '0'),
          duration: item.contentDetails.duration || 'PT0S'
        };
      }
    } catch (error) {
      console.error('❌ Ошибка получения деталей видео:', error);
    }
    
    return { viewCount: 0, likeCount: 0, duration: 'PT0S' };
  }

  private getTopRecommendations(arxiv: ArxivPaper[], google: GoogleSearchResult[], youtube: YouTubeVideo[]) {
    const allResults = [
      ...arxiv.map(p => ({ type: 'arxiv', title: p.title, score: p.relevanceScore, data: p })),
      ...google.map(g => ({ type: 'google', title: g.title, score: g.relevanceScore, data: g })),
      ...youtube.map(y => ({ type: 'youtube', title: y.title, score: y.relevanceScore, data: y }))
    ];
    
    return allResults
      .sort((a, b) => b.score - a.score)
      .slice(0, 5);
  }

  private calculateBreakthroughScore(results: any, indicators: string[]): number {
    const allText = JSON.stringify(results).toLowerCase();
    let score = 0;
    
    indicators.forEach(indicator => {
      const occurrences = (allText.match(new RegExp(indicator, 'g')) || []).length;
      score += occurrences * 0.1;
    });
    
    return Math.min(score, 1.0);
  }

  // ==========================================
  // MOCK DATA для тестирования
  // ==========================================

  private getMockGoogleResults(query: string): GoogleSearchResult[] {
    return [
      {
        title: `Advanced ${query} Research - MIT Technology Review`,
        snippet: `Latest breakthrough in ${query} technology with quantum applications`,
        link: 'https://www.technologyreview.com/advanced-research',
        source: 'MIT Technology Review',
        relevanceScore: 0.9
      },
      {
        title: `${query} Applications in Nanotechnology - Nature`,
        snippet: `Revolutionary applications of ${query} in nanotechnology and materials science`,
        link: 'https://www.nature.com/articles/nano-applications',
        source: 'Nature',
        relevanceScore: 0.8
      }
    ];
  }

  private getMockYouTubeResults(query: string): YouTubeVideo[] {
    return [
      {
        id: 'mock1',
        title: `${query} Explained - MIT OpenCourseWare`,
        description: `Comprehensive explanation of ${query} technology and applications`,
        channelTitle: 'MIT OpenCourseWare',
        publishedAt: new Date('2024-01-01'),
        viewCount: 150000,
        likeCount: 8500,
        duration: 'PT45M32S',
        url: 'https://www.youtube.com/watch?v=mock1',
        relevanceScore: 0.9
      },
      {
        id: 'mock2',
        title: `Breakthrough in ${query} Technology - TED`,
        description: `Latest breakthrough developments in ${query} field`,
        channelTitle: 'TED',
        publishedAt: new Date('2024-02-01'),
        viewCount: 230000,
        likeCount: 12000,
        duration: 'PT18M45S',
        url: 'https://www.youtube.com/watch?v=mock2',
        relevanceScore: 0.8
      }
    ];
  }
}

// Экспорт для использования в API routes
export const arxivGoogleYouTubeEngine = new JarvisArxivGoogleYouTubeIntegration();