// JARVIS Offline Mode - ЭТАП 3
// Полноценная работа без интернета с защитой и голосовой активацией протоколов

import { EventEmitter } from 'events';

interface OfflineState {
  isOnline: boolean;
  lastOnlineTime: number;
  offlineCapabilities: {
    voiceRecognition: boolean;
    localStorage: boolean;
    emergencyProtocols: boolean;
    basicResponses: boolean;
  };
  queuedOperations: Array<{
    id: string;
    type: string;
    data: any;
    timestamp: number;
  }>;
}

interface LocalKnowledgeBase {
  basicResponses: Map<string, string>;
  emergencyCommands: Map<string, string>;
  userPersonality: any;
  criticalMemories: any[];
}

interface ThreatSync {
  serverId: string;
  deviceId: string;
  threatLevel: 'LOW' | 'MEDIUM' | 'HIGH' | 'CRITICAL';
  threatType: string;
  timestamp: number;
  requiresVoiceActivation: boolean;
  protocol?: string;
}

class JarvisOfflineMode extends EventEmitter {
  private state: OfflineState;
  private localKnowledge: LocalKnowledgeBase;
  private threatSyncQueue: ThreatSync[] = [];
  private deviceConnections: Map<string, any> = new Map();
  private voiceProtocolsActive: boolean = false;

  constructor() {
    super();
    this.state = {
      isOnline: true, // Server всегда считается online
      lastOnlineTime: Date.now(),
      offlineCapabilities: {
        voiceRecognition: true,
        localStorage: true,
        emergencyProtocols: true,
        basicResponses: true
      },
      queuedOperations: []
    };

    this.localKnowledge = {
      basicResponses: new Map(),
      emergencyCommands: new Map(),
      userPersonality: {},
      criticalMemories: []
    };

    this.setupOfflineCapabilities();
    this.setupThreatSynchronization();
    this.setupVoiceProtocolActivation();
  }

  // Настройка offline возможностей
  private setupOfflineCapabilities() {
    // Базовые ответы для offline режима
    this.localKnowledge.basicResponses.set('привет', 'Привет! Я в offline режиме, но основные функции работают.');
    this.localKnowledge.basicResponses.set('статус', 'Система активна в offline режиме. Защита включена.');
    this.localKnowledge.basicResponses.set('время', `Текущее время: ${new Date().toLocaleString()}`);
    this.localKnowledge.basicResponses.set('помощь', 'Доступны базовые команды и голосовая активация протоколов.');

    // Emergency команды
    this.localKnowledge.emergencyCommands.set('протокол танос приближается', 'EMERGENCY_PROTOCOL_THANOS');
    this.localKnowledge.emergencyCommands.set('протокол призрак', 'EMERGENCY_PROTOCOL_GHOST');
    this.localKnowledge.emergencyCommands.set('protocol seven seven', 'EMERGENCY_PROTOCOL_77');
    this.localKnowledge.emergencyCommands.set('протокол выхода нет', 'EMERGENCY_PROTOCOL_NO_EXIT');

    // Мониторинг подключения (заглушка для сервера)
    // window.addEventListener('online', () => this.handleOnlineStatus(true));
    // window.addEventListener('offline', () => this.handleOnlineStatus(false));
  }

  // Синхронизация угроз между сервером и iPhone
  private setupThreatSynchronization() {
    // Получение угроз с сервера
    this.on('serverThreatDetected', (threat: ThreatSync) => {
      console.log(`🚨 Угроза получена с сервера: ${threat.threatType} (${threat.threatLevel})`);
      this.processServerThreat(threat);
    });

    // Отправка угроз на сервер
    this.on('deviceThreatDetected', (threat: ThreatSync) => {
      console.log(`📱 Угроза обнаружена на устройстве: ${threat.threatType} (${threat.threatLevel})`);
      this.syncThreatToServer(threat);
    });
  }

  // Голосовая активация протоколов (заглушка для сервера)
  private setupVoiceProtocolActivation() {
    // Серверная версия - обработка будет на клиенте
    console.log('🎤 Голосовая активация будет обрабатываться на клиенте');
    this.voiceProtocolsActive = true;
  }

  // Обработка голосовых команд
  private processVoiceCommand(command: string) {
    console.log(`🎙️ Голосовая команда: "${command}"`);

    // Проверка emergency протоколов
    for (const [trigger, protocol] of this.localKnowledge.emergencyCommands) {
      if (command.includes(trigger)) {
        console.log(`🚨 АКТИВАЦИЯ ПРОТОКОЛА: ${protocol}`);
        this.activateEmergencyProtocol(protocol, command);
        return;
      }
    }

    // Базовые ответы
    for (const [trigger, response] of this.localKnowledge.basicResponses) {
      if (command.includes(trigger)) {
        this.speak(response);
        return;
      }
    }

    // Если команда не распознана
    if (command.trim().length > 0) {
      this.speak('Команда не распознана в offline режиме. Доступны базовые функции и протоколы.');
    }
  }

  // Активация emergency протоколов
  private activateEmergencyProtocol(protocol: string, voiceCommand: string) {
    const activation = {
      protocol,
      voiceCommand,
      timestamp: Date.now(),
      deviceId: this.getDeviceId(),
      userId: this.getCurrentUserId()
    };

    console.log(`🚨 ПРОТОКОЛ АКТИВИРОВАН: ${protocol}`);
    this.speak(`Протокол активирован: ${protocol}`);

    // Отправка на сервер (если online)
    if (this.state.isOnline) {
      this.sendProtocolActivationToServer(activation);
    } else {
      // Сохранение в очередь для отправки при подключении
      this.queueOperation('protocol_activation', activation);
    }

    // Локальное выполнение протокола
    this.executeProtocolLocally(protocol);
  }

  // Обработка угрозы с сервера
  private processServerThreat(threat: ThreatSync) {
    this.threatSyncQueue.push(threat);

    if (threat.threatLevel === 'CRITICAL') {
      console.log('🚨 КРИТИЧЕСКАЯ УГРОЗА - требуется голосовая активация');
      this.speak(`Критическая угроза обнаружена: ${threat.threatType}. Требуется голосовая активация протокола.`);
      
      if (threat.protocol) {
        this.speak(`Для активации скажите: ${threat.protocol}`);
      }
    }
  }

  // Синхронизация угрозы на сервер
  private syncThreatToServer(threat: ThreatSync) {
    if (this.state.isOnline) {
      // Отправка в реальном времени
      fetch('/api/jarvis/threat-sync', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(threat)
      }).catch(console.error);
    } else {
      // Сохранение в очередь
      this.queueOperation('threat_sync', threat);
    }
  }

  // Обработка статуса подключения
  private handleOnlineStatus(isOnline: boolean) {
    this.state.isOnline = isOnline;
    
    if (isOnline) {
      console.log('🌐 Подключение восстановлено - синхронизация очереди');
      this.syncQueuedOperations();
    } else {
      console.log('📴 Переход в offline режим');
      this.state.lastOnlineTime = Date.now();
    }

    this.emit('connectionStatusChanged', isOnline);
  }

  // Синхронизация очереди операций
  private async syncQueuedOperations() {
    const operations = [...this.state.queuedOperations];
    this.state.queuedOperations = [];

    for (const operation of operations) {
      try {
        await this.processQueuedOperation(operation);
        console.log(`✅ Синхронизировано: ${operation.type}`);
      } catch (error) {
        console.error(`❌ Ошибка синхронизации: ${operation.type}`, error);
        // Возвращаем обратно в очередь
        this.state.queuedOperations.push(operation);
      }
    }
  }

  // Обработка операции из очереди
  private async processQueuedOperation(operation: any) {
    switch (operation.type) {
      case 'protocol_activation':
        await this.sendProtocolActivationToServer(operation.data);
        break;
      case 'threat_sync':
        await this.syncThreatToServer(operation.data);
        break;
      default:
        console.log(`Unknown operation type: ${operation.type}`);
    }
  }

  // Отправка активации протокола на сервер
  private async sendProtocolActivationToServer(activation: any) {
    return fetch('/api/jarvis/protocol-activation', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(activation)
    });
  }

  // Локальное выполнение протокола
  private executeProtocolLocally(protocol: string) {
    switch (protocol) {
      case 'EMERGENCY_PROTOCOL_THANOS':
        console.log('🚨 Активация Протокола Танос - защитные меры включены');
        break;
      case 'EMERGENCY_PROTOCOL_GHOST':
        console.log('👻 Активация Протокола Призрак - скрытый режим');
        break;
      case 'EMERGENCY_PROTOCOL_77':
        console.log('😴 Активация Protocol Seven Seven - спящий режим');
        break;
      case 'EMERGENCY_PROTOCOL_NO_EXIT':
        console.log('🔒 Активация Протокола Выхода Нет - блокировка');
        break;
    }
  }

  // Добавление операции в очередь
  private queueOperation(type: string, data: any) {
    this.state.queuedOperations.push({
      id: `op_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
      type,
      data,
      timestamp: Date.now()
    });
  }

  // Голосовой синтез (заглушка для сервера)
  private speak(text: string) {
    // На сервере только логирование, речь будет на клиенте
    console.log(`🗣️ JARVIS (server): ${text}`);
  }

  // Получение ID устройства (серверная версия)
  private getDeviceId(): string {
    return `server_device_${Date.now()}`;
  }

  // Получение ID пользователя (серверная версия)
  private getCurrentUserId(): string {
    return 'server_user';
  }

  // Публичные методы
  public getState(): OfflineState {
    return { ...this.state };
  }

  public isOnline(): boolean {
    return this.state.isOnline;
  }

  public isInOfflineMode(): boolean {
    return !this.state.isOnline;
  }

  public getQueuedOperationsCount(): number {
    return this.state.queuedOperations.length;
  }

  public getThreatQueue(): ThreatSync[] {
    return [...this.threatSyncQueue];
  }

  public forceSync(): void {
    if (this.state.isOnline) {
      this.syncQueuedOperations();
    }
  }

  // Детекция угрозы на устройстве
  public detectThreat(threatType: string, threatLevel: 'LOW' | 'MEDIUM' | 'HIGH' | 'CRITICAL', requiresVoiceActivation: boolean = false) {
    const threat: ThreatSync = {
      serverId: 'local_device',
      deviceId: this.getDeviceId(),
      threatLevel,
      threatType,
      timestamp: Date.now(),
      requiresVoiceActivation
    };

    this.emit('deviceThreatDetected', threat);
  }

  // Обновление локальной базы знаний
  public updateLocalKnowledge(personality: any, memories: any[]) {
    this.localKnowledge.userPersonality = personality;
    this.localKnowledge.criticalMemories = memories;
    console.log('📚 Локальная база знаний обновлена');
  }
}

// Экспорт singleton instance
export const jarvisOfflineMode = new JarvisOfflineMode();
export { JarvisOfflineMode };