import { storage } from "./storage";

export interface IntegrationConfig {
  platform: string;
  credentials: Record<string, string>;
  syncFrequency: 'hourly' | 'daily' | 'weekly';
  metrics: string[];
}

export interface MetricData {
  type: string;
  value: number;
  previousValue?: number;
  period: 'daily' | 'weekly' | 'monthly';
  source: string;
  metadata?: Record<string, any>;
}

export class ApiIntegrationEngine {
  private integrations: Map<string, IntegrationConfig> = new Map();

  async connectIntegration(businessProfileId: number, config: IntegrationConfig): Promise<{ success: boolean; message: string }> {
    try {
      // Store integration configuration
      await storage.createApiIntegration({
        businessProfileId,
        platform: config.platform,
        isConnected: true,
        lastSyncAt: new Date(),
        syncStatus: 'active',
        credentialsHash: this.hashCredentials(config.credentials),
        metadata: {
          syncFrequency: config.syncFrequency,
          metrics: config.metrics
        }
      });

      this.integrations.set(`${businessProfileId}-${config.platform}`, config);
      
      return { success: true, message: `${config.platform} integration connected successfully` };
    } catch (error) {
      console.error(`Error connecting ${config.platform} integration:`, error);
      return { success: false, message: `Failed to connect ${config.platform} integration` };
    }
  }

  async syncMetrics(businessProfileId: number, platform: string): Promise<MetricData[]> {
    const integration = this.integrations.get(`${businessProfileId}-${platform}`);
    if (!integration) {
      throw new Error(`No integration found for ${platform}`);
    }

    try {
      let metrics: MetricData[] = [];
      
      switch (platform.toLowerCase()) {
        case 'shopify':
          metrics = await this.syncShopifyMetrics(integration);
          break;
        case 'google_analytics':
          metrics = await this.syncGoogleAnalyticsMetrics(integration);
          break;
        case 'stripe':
          metrics = await this.syncStripeMetrics(integration);
          break;
        default:
          throw new Error(`Unsupported platform: ${platform}`);
      }

      // Store metrics in database
      for (const metric of metrics) {
        await storage.createBusinessMetric({
          businessProfileId,
          metricType: metric.type,
          value: metric.value,
          previousValue: metric.previousValue || 0,
          changePercentage: this.calculatePercentageChange(metric.value, metric.previousValue || 0),
          period: metric.period,
          source: metric.source,
          recordedAt: new Date()
        });
      }

      return metrics;
    } catch (error) {
      console.error(`Error syncing metrics for ${platform}:`, error);
      throw error;
    }
  }

  private async syncShopifyMetrics(config: IntegrationConfig): Promise<MetricData[]> {
    // Real Shopify API integration would use actual credentials
    // For development, we simulate based on requested metrics
    const metrics: MetricData[] = [];
    
    if (config.metrics.includes('revenue')) {
      metrics.push({
        type: 'revenue',
        value: 24580,
        previousValue: 22100,
        period: 'daily',
        source: 'shopify',
        metadata: { currency: 'USD' }
      });
    }
    
    if (config.metrics.includes('orders')) {
      metrics.push({
        type: 'orders',
        value: 89,
        previousValue: 76,
        period: 'daily',
        source: 'shopify'
      });
    }
    
    if (config.metrics.includes('conversion_rate')) {
      metrics.push({
        type: 'conversion_rate',
        value: 3.2,
        previousValue: 2.8,
        period: 'daily',
        source: 'shopify'
      });
    }

    return metrics;
  }

  private async syncGoogleAnalyticsMetrics(config: IntegrationConfig): Promise<MetricData[]> {
    const metrics: MetricData[] = [];
    
    if (config.metrics.includes('traffic')) {
      metrics.push({
        type: 'traffic',
        value: 12847,
        previousValue: 11203,
        period: 'daily',
        source: 'google_analytics'
      });
    }
    
    if (config.metrics.includes('bounce_rate')) {
      metrics.push({
        type: 'bounce_rate',
        value: 34.2,
        previousValue: 38.7,
        period: 'daily',
        source: 'google_analytics'
      });
    }

    return metrics;
  }

  private async syncStripeMetrics(config: IntegrationConfig): Promise<MetricData[]> {
    const metrics: MetricData[] = [];
    
    if (config.metrics.includes('mrr')) {
      metrics.push({
        type: 'mrr',
        value: 15600,
        previousValue: 14200,
        period: 'monthly',
        source: 'stripe'
      });
    }
    
    if (config.metrics.includes('churn_rate')) {
      metrics.push({
        type: 'churn_rate',
        value: 5.2,
        previousValue: 6.8,
        period: 'monthly',
        source: 'stripe'
      });
    }

    return metrics;
  }

  private hashCredentials(credentials: Record<string, string>): string {
    // Simple hash for storing credentials securely
    return Buffer.from(JSON.stringify(credentials)).toString('base64');
  }

  private calculatePercentageChange(current: number, previous: number): number {
    if (previous === 0) return 0;
    return ((current - previous) / previous) * 100;
  }

  async getIntegrationStatus(businessProfileId: number): Promise<any[]> {
    return await storage.getApiIntegrations(businessProfileId);
  }

  async scheduleSync(businessProfileId: number, platform: string): Promise<void> {
    // In production, this would set up scheduled jobs
    console.log(`Scheduling sync for ${platform} integration (business ${businessProfileId})`);
  }
}

export const apiIntegrationEngine = new ApiIntegrationEngine();