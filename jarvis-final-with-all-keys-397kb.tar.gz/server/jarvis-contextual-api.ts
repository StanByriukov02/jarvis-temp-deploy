import type { Express } from "express";
import { jarvisContextualEngine } from "./jarvis-contextual-engine";

export function registerJarvisContextualRoutes(app: Express) {
  
  // Главный endpoint для получения контекстного анализа при входе в систему
  app.post("/api/jarvis/contextual-analysis", async (req, res) => {
    try {
      const { userId, systemType } = req.body;

      if (!userId || !systemType) {
        return res.status(400).json({ 
          error: "userId and systemType are required" 
        });
      }

      console.log(`🧠 JARVIS Contextual Analysis requested: User ${userId} → ${systemType}`);

      // Анализируем полный контекст пользователя
      const userContext = await jarvisContextualEngine.analyzeUserContext(userId, systemType);
      
      // Генерируем персонализированный подход
      const contextualResponse = await jarvisContextualEngine.generateContextualApproach(userContext, systemType);

      res.json({
        success: true,
        userContext: {
          activeSystems: userContext.activeSystems.length,
          dailyTimeLoad: userContext.totalDailyTimeLoad,
          stressLevel: userContext.currentStressLevel,
          emotionalState: userContext.emotionalState,
          availableTime: userContext.availableTime,
          energyLevel: userContext.energyLevel
        },
        jarvisResponse: contextualResponse,
        timestamp: new Date().toISOString()
      });

    } catch (error) {
      console.error("Error in JARVIS contextual analysis:", error);
      res.status(500).json({ 
        error: "JARVIS analysis temporarily unavailable",
        fallback: {
          shouldProceed: true,
          personalizedMessage: "Давай разберем твою систему.",
          recommendations: ["Уделяй системе достаточно времени"],
          systemConflicts: [],
          emotionalInsights: "Анализ временно недоступен."
        }
      });
    }
  });

  // Endpoint для быстрой проверки готовности к новой системе
  app.post("/api/jarvis/readiness-check", async (req, res) => {
    try {
      const { userId } = req.body;

      const userContext = await jarvisContextualEngine.analyzeUserContext(userId, "general");
      
      const readinessScore = calculateReadinessScore(userContext);
      
      res.json({
        ready: readinessScore > 70,
        score: readinessScore,
        factors: {
          timeAvailable: userContext.availableTime > 2,
          stressLevel: userContext.currentStressLevel < 7,
          systemLoad: userContext.activeSystems.length < 3,
          energyLevel: userContext.energyLevel > 4
        },
        recommendation: readinessScore > 70 ? 
          "Хорошее время для новой системы" : 
          "Лучше сначала завершить текущие задачи"
      });

    } catch (error) {
      console.error("Error in readiness check:", error);
      res.status(500).json({ error: "Readiness check failed" });
    }
  });

  // Endpoint для получения персонализированного тона JARVIS
  app.get("/api/jarvis/personality-tone/:userId", async (req, res) => {
    try {
      const { userId } = req.params;
      
      const userContext = await jarvisContextualEngine.analyzeUserContext(userId, "tone_check");
      
      res.json({
        personalityLevel: userContext.starkPersonalityLevel,
        emotionalState: userContext.emotionalState,
        interactionHistory: userContext.recentInteractions.length,
        recommendedTone: userContext.starkPersonalityLevel
      });

    } catch (error) {
      console.error("Error getting personality tone:", error);
      res.status(500).json({ error: "Personality analysis failed" });
    }
  });

  // Endpoint для обновления контекста после действий пользователя
  app.post("/api/jarvis/update-context", async (req, res) => {
    try {
      const { userId, action, systemType, metadata } = req.body;

      console.log(`📊 Context Update: User ${userId} performed ${action} in ${systemType}`);

      // В реальной реализации здесь бы обновлялись behavioral patterns
      // Сейчас просто логируем и возвращаем успех
      
      res.json({
        success: true,
        message: "Context updated successfully",
        timestamp: new Date().toISOString()
      });

    } catch (error) {
      console.error("Error updating context:", error);
      res.status(500).json({ error: "Context update failed" });
    }
  });
}

// Вспомогательная функция для расчета готовности пользователя
function calculateReadinessScore(context: any): number {
  let score = 100;

  // Снижаем за активные системы
  score -= context.activeSystems.length * 15;

  // Снижаем за высокую временную нагрузку
  if (context.totalDailyTimeLoad > 6) score -= 20;
  if (context.totalDailyTimeLoad > 8) score -= 30;

  // Снижаем за высокий стресс
  if (context.currentStressLevel > 7) score -= 25;
  if (context.currentStressLevel > 8) score -= 35;

  // Снижаем за низкую энергию
  if (context.energyLevel < 4) score -= 20;

  // Снижаем за недостаток времени
  if (context.availableTime < 2) score -= 30;

  return Math.max(0, Math.min(100, score));
}