// JARVIS Offline Server - серверная часть ЭТАП 3
// Обработка offline режима и синхронизация с устройствами

import { EventEmitter } from 'events';
import { WebSocket } from 'ws';

interface ServerOfflineState {
  connectedDevices: Map<string, DeviceConnection>;
  threatDetectionActive: boolean;
  offlineCapabilities: {
    threatSync: boolean;
    protocolActivation: boolean;
    emergencyResponse: boolean;
  };
  threatHistory: ThreatEvent[];
}

interface DeviceConnection {
  deviceId: string;
  userId: string;
  websocket?: WebSocket;
  lastSeen: number;
  isOnline: boolean;
  capabilities: string[];
  threatLevel: 'LOW' | 'MEDIUM' | 'HIGH' | 'CRITICAL';
}

interface ThreatEvent {
  id: string;
  source: 'server' | 'device';
  deviceId: string;
  threatType: string;
  threatLevel: 'LOW' | 'MEDIUM' | 'HIGH' | 'CRITICAL';
  timestamp: number;
  handled: boolean;
  protocolActivated?: string;
}

interface ProtocolActivation {
  protocol: string;
  voiceCommand: string;
  timestamp: number;
  deviceId: string;
  userId: string;
  verified: boolean;
}

class JarvisOfflineServer extends EventEmitter {
  private state: ServerOfflineState;
  private emergencyProtocols: Map<string, any> = new Map();
  private threatDetectionInterval: NodeJS.Timeout | null = null;

  constructor() {
    super();
    this.state = {
      connectedDevices: new Map(),
      threatDetectionActive: true,
      offlineCapabilities: {
        threatSync: true,
        protocolActivation: true,
        emergencyResponse: true
      },
      threatHistory: []
    };

    this.setupEmergencyProtocols();
    this.startThreatDetection();
  }

  // Настройка emergency протоколов
  private setupEmergencyProtocols() {
    this.emergencyProtocols.set('EMERGENCY_PROTOCOL_THANOS', {
      name: 'Протокол Танос приближается',
      description: 'Максимальная защита от критических угроз',
      actions: ['lockdown_mode', 'data_protection', 'alert_all_devices'],
      requiredAuth: 'voice_verified'
    });

    this.emergencyProtocols.set('EMERGENCY_PROTOCOL_GHOST', {
      name: 'Протокол Призрак',
      description: 'Скрытый режим работы',
      actions: ['stealth_mode', 'minimal_logging', 'encrypted_communications'],
      requiredAuth: 'voice_verified'
    });

    this.emergencyProtocols.set('EMERGENCY_PROTOCOL_77', {
      name: 'Protocol Seven Seven',
      description: 'Спящий режим',
      actions: ['sleep_mode', 'minimal_functions', 'energy_conservation'],
      requiredAuth: 'voice_verified'
    });

    this.emergencyProtocols.set('EMERGENCY_PROTOCOL_NO_EXIT', {
      name: 'Протокол Выхода Нет',
      description: 'Блокировка системы',
      actions: ['system_lock', 'access_denied', 'emergency_contacts'],
      requiredAuth: 'voice_verified'
    });
  }

  // Запуск детекции угроз
  private startThreatDetection() {
    this.threatDetectionInterval = setInterval(() => {
      this.performThreatScan();
    }, 10000); // Каждые 10 секунд

    console.log('🔍 Детекция угроз активирована');
  }

  // Сканирование угроз
  private performThreatScan() {
    // Симуляция различных типов угроз
    const threatTypes = [
      'unauthorized_access_attempt',
      'data_breach_attempt',
      'system_intrusion',
      'malware_detection',
      'ddos_attack',
      'social_engineering'
    ];

    // Случайная генерация угроз для тестирования
    if (Math.random() < 0.1) { // 10% шанс обнаружения угрозы
      const threatType = threatTypes[Math.floor(Math.random() * threatTypes.length)];
      const threatLevel = this.determineThreatLevel(threatType);
      
      this.detectThreat(threatType, threatLevel, 'server');
    }
  }

  // Определение уровня угрозы
  private determineThreatLevel(threatType: string): 'LOW' | 'MEDIUM' | 'HIGH' | 'CRITICAL' {
    const criticalThreats = ['system_intrusion', 'data_breach_attempt'];
    const highThreats = ['unauthorized_access_attempt', 'malware_detection'];
    const mediumThreats = ['ddos_attack', 'social_engineering'];

    if (criticalThreats.includes(threatType)) return 'CRITICAL';
    if (highThreats.includes(threatType)) return 'HIGH';
    if (mediumThreats.includes(threatType)) return 'MEDIUM';
    return 'LOW';
  }

  // Обнаружение угрозы
  private detectThreat(threatType: string, threatLevel: 'LOW' | 'MEDIUM' | 'HIGH' | 'CRITICAL', source: 'server' | 'device', deviceId: string = 'server') {
    const threat: ThreatEvent = {
      id: `threat_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
      source,
      deviceId,
      threatType,
      threatLevel,
      timestamp: Date.now(),
      handled: false
    };

    this.state.threatHistory.push(threat);
    console.log(`🚨 Угроза обнаружена: ${threatType} (${threatLevel}) от ${source}`);

    // Обработка угрозы
    this.handleThreat(threat);
  }

  // Обработка угрозы
  private handleThreat(threat: ThreatEvent) {
    // Отправка угрозы на все подключенные устройства
    this.syncThreatToDevices(threat);

    // Если угроза критическая - требуется голосовая активация
    if (threat.threatLevel === 'CRITICAL') {
      console.log('🚨 КРИТИЧЕСКАЯ УГРОЗА - требуется голосовая активация протокола');
      this.requestVoiceProtocolActivation(threat);
    }

    // Автоматическая обработка для менее критических угроз
    if (threat.threatLevel === 'HIGH') {
      this.autoHandleThreat(threat);
    }
  }

  // Синхронизация угрозы на устройства
  private syncThreatToDevices(threat: ThreatEvent) {
    const syncMessage = {
      type: 'threat_sync',
      threat: {
        serverId: 'main_server',
        deviceId: threat.deviceId,
        threatLevel: threat.threatLevel,
        threatType: threat.threatType,
        timestamp: threat.timestamp,
        requiresVoiceActivation: threat.threatLevel === 'CRITICAL'
      }
    };

    // Отправка на все подключенные устройства
    this.state.connectedDevices.forEach((device, deviceId) => {
      if (device.websocket && device.isOnline) {
        try {
          device.websocket.send(JSON.stringify(syncMessage));
          console.log(`📱 Угроза отправлена на устройство: ${deviceId}`);
        } catch (error) {
          console.error(`❌ Ошибка отправки на устройство ${deviceId}:`, error);
        }
      }
    });
  }

  // Запрос голосовой активации протокола
  private requestVoiceProtocolActivation(threat: ThreatEvent) {
    const activationRequest = {
      type: 'voice_protocol_request',
      threat: threat.threatType,
      level: threat.threatLevel,
      suggestedProtocol: this.getSuggestedProtocol(threat.threatType),
      timestamp: Date.now()
    };

    // Отправка запроса на все устройства
    this.state.connectedDevices.forEach((device, deviceId) => {
      if (device.websocket && device.isOnline) {
        try {
          device.websocket.send(JSON.stringify(activationRequest));
          console.log(`🎙️ Запрос голосовой активации отправлен на: ${deviceId}`);
        } catch (error) {
          console.error(`❌ Ошибка запроса активации на ${deviceId}:`, error);
        }
      }
    });
  }

  // Получение рекомендуемого протокола
  private getSuggestedProtocol(threatType: string): string {
    const protocolMap: { [key: string]: string } = {
      'system_intrusion': 'протокол танос приближается',
      'data_breach_attempt': 'протокол призрак',
      'unauthorized_access_attempt': 'protocol seven seven',
      'malware_detection': 'протокол выхода нет'
    };

    return protocolMap[threatType] || 'протокол танос приближается';
  }

  // Автоматическая обработка угрозы
  private autoHandleThreat(threat: ThreatEvent) {
    console.log(`🤖 Автоматическая обработка угрозы: ${threat.threatType}`);
    
    // Базовые защитные меры
    switch (threat.threatType) {
      case 'unauthorized_access_attempt':
        console.log('🔒 Блокировка подозрительного доступа');
        break;
      case 'ddos_attack':
        console.log('🛡️ Активация DDoS защиты');
        break;
      case 'malware_detection':
        console.log('🦠 Изоляция подозрительного файла');
        break;
    }

    threat.handled = true;
  }

  // Регистрация устройства
  public registerDevice(deviceId: string, userId: string, websocket?: WebSocket): void {
    const device: DeviceConnection = {
      deviceId,
      userId,
      websocket,
      lastSeen: Date.now(),
      isOnline: true,
      capabilities: ['voice_recognition', 'offline_mode', 'emergency_protocols'],
      threatLevel: 'LOW'
    };

    this.state.connectedDevices.set(deviceId, device);
    console.log(`📱 Устройство зарегистрировано: ${deviceId}`);

    // Отправка текущих угроз на новое устройство
    this.syncCurrentThreatsToDevice(deviceId);
  }

  // Синхронизация текущих угроз на устройство
  private syncCurrentThreatsToDevice(deviceId: string) {
    const activeThreats = this.state.threatHistory
      .filter(t => !t.handled && Date.now() - t.timestamp < 300000); // За последние 5 минут

    const device = this.state.connectedDevices.get(deviceId);
    if (device && device.websocket && activeThreats.length > 0) {
      const syncMessage = {
        type: 'threat_history_sync',
        threats: activeThreats
      };

      try {
        device.websocket.send(JSON.stringify(syncMessage));
        console.log(`📊 История угроз отправлена на: ${deviceId}`);
      } catch (error) {
        console.error(`❌ Ошибка синхронизации истории на ${deviceId}:`, error);
      }
    }
  }

  // Обработка активации протокола
  public handleProtocolActivation(activation: ProtocolActivation): boolean {
    console.log(`🎙️ Получена активация протокола: ${activation.protocol}`);

    // Проверка протокола
    if (!this.emergencyProtocols.has(activation.protocol)) {
      console.error(`❌ Неизвестный протокол: ${activation.protocol}`);
      return false;
    }

    const protocol = this.emergencyProtocols.get(activation.protocol);
    console.log(`🚨 АКТИВАЦИЯ ПРОТОКОЛА: ${protocol.name}`);

    // Выполнение действий протокола
    this.executeProtocolActions(protocol.actions, activation);

    // Отметка угроз как обработанных
    this.markThreatsAsHandled(activation.protocol);

    return true;
  }

  // Выполнение действий протокола
  private executeProtocolActions(actions: string[], activation: ProtocolActivation) {
    actions.forEach(action => {
      switch (action) {
        case 'lockdown_mode':
          console.log('🔒 Режим блокировки активирован');
          break;
        case 'data_protection':
          console.log('🛡️ Защита данных усилена');
          break;
        case 'alert_all_devices':
          console.log('📢 Оповещение всех устройств');
          this.alertAllDevices(activation.protocol);
          break;
        case 'stealth_mode':
          console.log('👻 Скрытый режим активирован');
          break;
        case 'sleep_mode':
          console.log('😴 Спящий режим активирован');
          break;
        case 'system_lock':
          console.log('🔐 Система заблокирована');
          break;
      }
    });
  }

  // Оповещение всех устройств
  private alertAllDevices(protocol: string) {
    const alert = {
      type: 'protocol_activation_alert',
      protocol,
      timestamp: Date.now(),
      message: `Протокол ${protocol} активирован`
    };

    this.state.connectedDevices.forEach((device, deviceId) => {
      if (device.websocket && device.isOnline) {
        try {
          device.websocket.send(JSON.stringify(alert));
        } catch (error) {
          console.error(`❌ Ошибка оповещения устройства ${deviceId}:`, error);
        }
      }
    });
  }

  // Отметка угроз как обработанных
  private markThreatsAsHandled(protocol: string) {
    this.state.threatHistory.forEach(threat => {
      if (!threat.handled && threat.threatLevel === 'CRITICAL') {
        threat.handled = true;
        threat.protocolActivated = protocol;
      }
    });
  }

  // Получение статуса
  public getStatus() {
    return {
      connectedDevices: this.state.connectedDevices.size,
      threatDetectionActive: this.state.threatDetectionActive,
      activeThreats: this.state.threatHistory.filter(t => !t.handled).length,
      totalThreats: this.state.threatHistory.length,
      offlineCapabilities: this.state.offlineCapabilities
    };
  }

  // Получение истории угроз
  public getThreatHistory() {
    return this.state.threatHistory;
  }

  // Остановка детекции угроз
  public stopThreatDetection() {
    if (this.threatDetectionInterval) {
      clearInterval(this.threatDetectionInterval);
      this.threatDetectionInterval = null;
    }
    this.state.threatDetectionActive = false;
  }

  // Принудительная детекция угрозы (для тестирования)
  public forceThreatDetection(threatType: string, threatLevel: 'LOW' | 'MEDIUM' | 'HIGH' | 'CRITICAL') {
    this.detectThreat(threatType, threatLevel, 'server');
  }
}

// Экспорт singleton instance
export const jarvisOfflineServer = new JarvisOfflineServer();
export { JarvisOfflineServer };