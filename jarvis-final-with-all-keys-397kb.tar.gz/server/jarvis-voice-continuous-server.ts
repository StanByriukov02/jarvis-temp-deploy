/**
 * JARVIS Continuous Voice Listening Server
 * Серверная реализация постоянного прослушивания с интеграцией в био-сингулярность
 */

import { WebSocketServer, WebSocket } from 'ws';
import { JarvisVoiceEngine } from './jarvis-voice-engine';
import { TrueBioSingularityEngine } from './jarvis-true-bio-singularity';
import { Server as HttpServer } from 'http';
import fs from 'fs';
import path from 'path';

interface VoiceSession {
  id: string;
  userId: string;
  ws: WebSocket;
  isListening: boolean;
  bioSingularity: TrueBioSingularityEngine;
  audioBuffer: Buffer[];
  lastActivity: number;
  securityLevel: 'sleeping' | 'awakened' | 'authenticated' | 'authorized';
}

export class JarvisContinuousVoiceServer {
  private wss: WebSocketServer;
  private voiceEngine: JarvisVoiceEngine;
  private activeSessions: Map<string, VoiceSession> = new Map();
  private sessionCleanupInterval: NodeJS.Timeout | undefined;

  constructor(httpServer: HttpServer) {
    this.voiceEngine = new JarvisVoiceEngine();
    
    // WebSocket сервер для голосовых сессий
    this.wss = new WebSocketServer({ 
      server: httpServer, 
      path: '/jarvis-voice-ws',
      clientTracking: true
    });

    this.setupWebSocketHandlers();
    this.startSessionCleanup();
    
    console.log('🎙️ JARVIS Continuous Voice Server initialized');
  }

  private setupWebSocketHandlers(): void {
    this.wss.on('connection', (ws, request) => {
      const sessionId = this.generateSessionId();
      const userId = this.extractUserId(request);
      
      console.log(`🎤 New voice session: ${sessionId} (User: ${userId})`);
      
      // Создание сессии с био-сингулярностью
      const bioSingularity = new TrueBioSingularityEngine();
      
      const session: VoiceSession = {
        id: sessionId,
        userId,
        ws,
        isListening: false,
        bioSingularity,
        audioBuffer: [],
        lastActivity: Date.now(),
        securityLevel: 'sleeping'
      };

      this.activeSessions.set(sessionId, session);

      ws.on('message', (data) => {
        this.handleVoiceMessage(sessionId, data);
      });

      ws.on('close', () => {
        console.log(`🔇 Voice session closed: ${sessionId}`);
        this.activeSessions.delete(sessionId);
      });

      ws.on('error', (error) => {
        console.error(`❌ Voice session error (${sessionId}):`, error);
        this.activeSessions.delete(sessionId);
      });

      // Приветственное сообщение
      this.sendToSession(sessionId, {
        type: 'session_ready',
        sessionId,
        message: 'JARVIS голосовая сессия готова к работе'
      });
    });
  }

  private async handleVoiceMessage(sessionId: string, data: any): Promise<void> {
    const session = this.activeSessions.get(sessionId);
    if (!session) return;

    session.lastActivity = Date.now();

    try {
      if (typeof data === 'string') {
        // Команды управления
        const command = JSON.parse(data);
        await this.handleVoiceCommand(sessionId, command);
      } else if (Buffer.isBuffer(data)) {
        // Аудио данные как Buffer
        await this.handleAudioData(sessionId, data);
      } else {
        // Другие типы данных (Uint8Array, ArrayBuffer)
        const buffer = Buffer.from(data);
        await this.handleAudioData(sessionId, buffer);
      }
    } catch (error) {
      console.error(`❌ Voice message handling error (${sessionId}):`, error);
      this.sendToSession(sessionId, {
        type: 'error',
        message: 'Ошибка обработки голосового сообщения'
      });
    }
  }

  private async handleVoiceCommand(sessionId: string, command: any): Promise<void> {
    const session = this.activeSessions.get(sessionId);
    if (!session) return;

    switch (command.type) {
      case 'start_listening':
        await this.startListening(sessionId);
        break;
      
      case 'stop_listening':
        await this.stopListening(sessionId);
        break;
      
      case 'security_phrase':
        await this.handleSecurityPhrase(sessionId, command.phrase);
        break;
      
      case 'biometric_data':
        await this.handleBiometricData(sessionId, command.data);
        break;
      
      default:
        console.log(`⚠️ Unknown voice command: ${command.type}`);
    }
  }

  private async handleAudioData(sessionId: string, audioData: Buffer): Promise<void> {
    const session = this.activeSessions.get(sessionId);
    if (!session || !session.isListening) return;

    session.audioBuffer.push(audioData);

    // Анализируем каждые 3 секунды аудио
    if (session.audioBuffer.length >= 3) {
      const combinedAudio = Buffer.concat(session.audioBuffer);
      session.audioBuffer = [];

      try {
        // Распознавание речи
        const transcription = await this.voiceEngine.transcribeAudio(combinedAudio, 'ru');
        
        console.log(`🎤 Transcribed (${sessionId}): ${transcription.text}`);
        
        // Проверка на wake word
        if (this.isWakeWord(transcription.text)) {
          console.log(`🎯 Wake word detected in session ${sessionId}`);
          await this.handleWakeWordDetected(sessionId, transcription);
        }
        
        // Если уже активирован, обрабатываем как команду
        if (session.securityLevel !== 'sleeping') {
          await this.processVoiceCommand(sessionId, transcription);
        }

      } catch (error) {
        console.error(`❌ Audio processing error (${sessionId}):`, error);
      }
    }
  }

  private async handleWakeWordDetected(sessionId: string, transcription: any): Promise<void> {
    const session = this.activeSessions.get(sessionId);
    if (!session) return;

    // Переход в состояние "пробужден"
    session.securityLevel = 'awakened';
    
    // Отправляем приветствие
    const response = await this.voiceEngine.synthesizeVoice(
      'Слушаю вас. Для полной активации произнесите фразу безопасности.',
      true // Global JARVIS
    );

    this.sendToSession(sessionId, {
      type: 'wake_word_detected',
      message: 'JARVIS активирован',
      audio: response.toString('base64'),
      securityLevel: session.securityLevel
    });
  }

  private async handleSecurityPhrase(sessionId: string, phrase: string): Promise<void> {
    const session = this.activeSessions.get(sessionId);
    if (!session) return;

    // Проверка фразы безопасности "гром начинается"
    if (phrase.toLowerCase().includes('гром начинается')) {
      session.securityLevel = 'authenticated';
      
      const response = await this.voiceEngine.synthesizeVoice(
        'Аутентификация пройдена. Ожидаю биометрические данные для полной авторизации.',
        true
      );

      this.sendToSession(sessionId, {
        type: 'security_authenticated',
        message: 'Аутентификация пройдена',
        audio: response.toString('base64'),
        securityLevel: session.securityLevel
      });
    } else {
      const response = await this.voiceEngine.synthesizeVoice(
        'Неверная фраза безопасности. Возврат в спящий режим.',
        true
      );

      session.securityLevel = 'sleeping';
      this.sendToSession(sessionId, {
        type: 'security_failed',
        message: 'Неверная фраза безопасности',
        audio: response.toString('base64'),
        securityLevel: session.securityLevel
      });
    }
  }

  private async handleBiometricData(sessionId: string, biometricData: any): Promise<void> {
    const session = this.activeSessions.get(sessionId);
    if (!session || session.securityLevel !== 'authenticated') return;

    // Здесь будет интеграция с биометрикой (Face ID, голос, NFC кольцо)
    // Пока имитируем успешную проверку
    const biometricValid = this.validateBiometrics(biometricData);
    
    if (biometricValid) {
      session.securityLevel = 'authorized';
      
      const response = await this.voiceEngine.synthesizeVoice(
        'Полная авторизация завершена. JARVIS готов к работе.',
        true,
        null
      );

      this.sendToSession(sessionId, {
        type: 'fully_authorized',
        message: 'JARVIS полностью активирован',
        audio: response.toString('base64'),
        securityLevel: session.securityLevel
      });
    } else {
      session.securityLevel = 'sleeping';
      
      const response = await this.voiceEngine.synthesizeVoice(
        'Биометрическая проверка не пройдена. Возврат в спящий режим.',
        true,
        null
      );

      this.sendToSession(sessionId, {
        type: 'biometric_failed',
        message: 'Биометрическая проверка не пройдена',
        audio: response.toString('base64'),
        securityLevel: session.securityLevel
      });
    }
  }

  private async processVoiceCommand(sessionId: string, transcription: any): Promise<void> {
    const session = this.activeSessions.get(sessionId);
    if (!session || session.securityLevel !== 'authorized') return;

    // Обработка команды через био-сингулярность
    const bioResponse = await session.bioSingularity.processInteraction(session.userId, transcription.text);
    
    // Синтез ответа
    const voiceResponse = await this.voiceEngine.synthesizeVoice(
      bioResponse.response,
      false, // Персональный JARVIS
      bioResponse.personalTone || null
    );

    this.sendToSession(sessionId, {
      type: 'jarvis_response',
      message: bioResponse.response,
      audio: voiceResponse.toString('base64'),
      evolution: bioResponse.evolution,
      emotionalState: bioResponse.emotionalState
    });
  }

  private async startListening(sessionId: string): Promise<void> {
    const session = this.activeSessions.get(sessionId);
    if (!session) return;

    session.isListening = true;
    console.log(`🎤 Started listening for session ${sessionId}`);

    this.sendToSession(sessionId, {
      type: 'listening_started',
      message: 'Прослушивание активировано'
    });
  }

  private async stopListening(sessionId: string): Promise<void> {
    const session = this.activeSessions.get(sessionId);
    if (!session) return;

    session.isListening = false;
    session.audioBuffer = [];
    console.log(`🔇 Stopped listening for session ${sessionId}`);

    this.sendToSession(sessionId, {
      type: 'listening_stopped',
      message: 'Прослушивание остановлено'
    });
  }

  private isWakeWord(text: string): boolean {
    const wakeWords = [
      'hey jarvis',
      'хей джарвис',
      'эй джарвис',
      'wake up jarvis',
      'просыпайся джарвис',
      'джарвис активация',
      'jarvis ready',
      'джарвис готов'
    ];

    const normalizedText = text.toLowerCase().trim();
    return wakeWords.some(wake => normalizedText.includes(wake));
  }

  private validateBiometrics(data: any): boolean {
    // Здесь будет настоящая биометрическая проверка
    // Пока возвращаем true для тестирования
    return true;
  }

  private sendToSession(sessionId: string, message: any): void {
    const session = this.activeSessions.get(sessionId);
    if (session && session.ws.readyState === WebSocket.OPEN) {
      session.ws.send(JSON.stringify(message));
    }
  }

  private generateSessionId(): string {
    return `voice_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
  }

  private extractUserId(request: any): string {
    // Извлекаем userId из query параметров или headers
    const url = new URL(request.url, 'http://localhost');
    return url.searchParams.get('userId') || 'anonymous';
  }

  private startSessionCleanup(): void {
    this.sessionCleanupInterval = setInterval(() => {
      const now = Date.now();
      const timeout = 30 * 60 * 1000; // 30 минут

      for (const [sessionId, session] of this.activeSessions.entries()) {
        if (now - session.lastActivity > timeout) {
          console.log(`🧹 Cleaning up inactive session: ${sessionId}`);
          session.ws.close();
          this.activeSessions.delete(sessionId);
        }
      }
    }, 5 * 60 * 1000); // Проверка каждые 5 минут
  }

  // Статус сервера
  getStatus(): any {
    return {
      activeSessions: this.activeSessions.size,
      sessions: Array.from(this.activeSessions.values()).map(s => ({
        id: s.id,
        userId: s.userId,
        isListening: s.isListening,
        securityLevel: s.securityLevel,
        lastActivity: s.lastActivity
      }))
    };
  }

  // Остановка сервера
  stop(): void {
    if (this.sessionCleanupInterval) {
      clearInterval(this.sessionCleanupInterval);
    }
    
    this.wss.close();
    console.log('🔇 JARVIS Continuous Voice Server stopped');
  }
}