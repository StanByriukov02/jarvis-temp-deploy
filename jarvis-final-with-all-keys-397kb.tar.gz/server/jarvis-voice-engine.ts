import OpenAI from 'openai';
import { jarvisVoiceAnalyzer } from './jarvis-voice-analyzer';
import { jarvisVoiceEvolution } from './jarvis-voice-evolution';

// Voice Engine - органы речи биосингулярности
export class JarvisVoiceEngine {
  private openai: OpenAI;
  private elevenLabsApiKey: string | null;
  private paulBettanyVoiceId: string = 'EXAVITQu4vr4xnSDxMaL'; // Paul Bettany voice ID в ElevenLabs
  private russianJarvisVoiceId: string = 'wDsJlOXPqcvIUKdLXjDs'; // Правильный Voice ID (чистый звук)
  private isListening: boolean = false;
  private audioContext: AudioContext | null = null;
  private mediaRecorder: MediaRecorder | null = null;
  private audioChunks: Blob[] = [];

  constructor() {
    this.openai = new OpenAI({ 
      apiKey: process.env.OPENAI_API_KEY 
    });
    this.elevenLabsApiKey = process.env.ELEVENLABS_API_KEY || null;
    
    console.log('🎙️ JARVIS Voice Engine initialized');
    console.log(`🎯 ElevenLabs API: ${this.elevenLabsApiKey ? 'Connected' : 'Not configured'}`);
    console.log(`🎭 Paul Bettany Voice: ${this.paulBettanyVoiceId}`);
    console.log(`🇷🇺 Russian JARVIS Voice: ${this.russianJarvisVoiceId !== 'RUSSIAN_JARVIS_VOICE_ID' ? this.russianJarvisVoiceId : 'Not configured'}`);
  }

  // Whisper интеграция - распознавание речи
  async transcribeAudio(audioBuffer: Buffer, language: string = 'ru'): Promise<{
    text: string;
    confidence: number;
    emotionalTone?: string;
    detectedLanguage: string;
  }> {
    try {
      console.log('🎤 Transcribing audio with Whisper...');
      
      // Создаем временный файл для Whisper
      const audioFile = new File([audioBuffer], 'audio.webm', { type: 'audio/webm' });
      
      const transcription = await this.openai.audio.transcriptions.create({
        file: audioFile,
        model: 'whisper-1',
        language: language,
        response_format: 'verbose_json',
        temperature: 0.2
      });

      // Анализируем эмоциональный тон речи
      const emotionalAnalysis = await this.analyzeVoiceEmotion(transcription.text);

      console.log(`🎯 Transcribed: "${transcription.text}"`);
      console.log(`🎭 Emotional tone: ${emotionalAnalysis.tone}`);

      return {
        text: transcription.text,
        confidence: transcription.segments?.[0]?.no_speech_prob ? 
          1 - transcription.segments[0].no_speech_prob : 0.9,
        emotionalTone: emotionalAnalysis.tone,
        detectedLanguage: transcription.language || language
      };

    } catch (error: any) {
      console.error('❌ Whisper transcription failed:', error);
      throw new Error(`Voice transcription failed: ${error.message}`);
    }
  }

  // Анализ эмоционального тона голоса
  private async analyzeVoiceEmotion(text: string): Promise<{
    tone: string;
    intensity: number;
    emotions: string[];
  }> {
    try {
      const response = await this.openai.chat.completions.create({
        model: 'gpt-4o', // the newest OpenAI model is "gpt-4o" which was released May 13, 2024. do not change this unless explicitly requested by the user
        messages: [{
          role: 'system',
          content: `Analyze the emotional tone of this spoken text. Focus on voice patterns typical for emotions. 
          Respond with JSON: {"tone": "serious|excited|concerned|playful|frustrated|calm", "intensity": 0-1, "emotions": ["primary", "secondary"]}`
        }, {
          role: 'user',
          content: text
        }],
        response_format: { type: "json_object" },
        temperature: 0.3
      });

      return JSON.parse(response.choices[0].message.content || '{"tone":"neutral","intensity":0.5,"emotions":["neutral"]}');
    } catch (error) {
      console.warn('⚠️ Voice emotion analysis failed, using defaults');
      return { tone: 'neutral', intensity: 0.5, emotions: ['neutral'] };
    }
  }

  // ElevenLabs синтез речи
  async synthesizeVoice(text: string, personalTone: any, isGlobalJarvis: boolean = false): Promise<{
    audioBuffer: Buffer;
    audioUrl?: string;
    voiceSettings: any;
  }> {
    if (!this.elevenLabsApiKey) {
      console.warn('⚠️ ElevenLabs API key not configured, voice synthesis disabled');
      throw new Error('ElevenLabs API key required for voice synthesis');
    }

    try {
      console.log('🎭 Synthesizing voice with ElevenLabs...');
      
      // Выбираем голос: русский JARVIS для русского текста, Paul Bettany для английского
      const { voiceId, voiceName } = this.selectVoiceByLanguage(text, isGlobalJarvis, personalTone);
      
      // Настройки голоса на основе анализа оригинального голоса Всеволода
      const voiceSettings = await this.generateVoiceSettings(personalTone);
      
      console.log(`🎯 Using voice: ${voiceId} (${voiceName})`);
      console.log(`🎛️ Voice settings:`, voiceSettings);

      const response = await fetch(`https://api.elevenlabs.io/v1/text-to-speech/${voiceId}`, {
        method: 'POST',
        headers: {
          'Accept': 'audio/mpeg',
          'Content-Type': 'application/json',
          'xi-api-key': this.elevenLabsApiKey
        },
        body: JSON.stringify({
          text: text,
          model_id: 'eleven_multilingual_v2', // Поддержка русского языка
          voice_settings: voiceSettings
        })
      });

      if (!response.ok) {
        const errorText = await response.text();
        throw new Error(`ElevenLabs API error: ${response.status} - ${errorText}`);
      }

      const audioBuffer = Buffer.from(await response.arrayBuffer());
      
      console.log(`✅ Voice synthesized: ${audioBuffer.length} bytes`);
      
      return {
        audioBuffer,
        voiceSettings
      };

    } catch (error: any) {
      console.error('❌ Voice synthesis failed:', error);
      throw new Error(`Voice synthesis failed: ${error.message}`);
    }
  }

  // Умный выбор голоса на основе языка текста
  private selectVoiceByLanguage(text: string, isGlobalJarvis: boolean, personalTone: any): { voiceId: string, voiceName: string } {
    // Определяем язык по тексту (простая эвристика)
    const russianPattern = /[а-яё]/i;
    const isRussian = russianPattern.test(text);
    
    console.log(`🌐 Detected language: ${isRussian ? 'Russian' : 'English'}`);
    
    if (isRussian) {
      // Для русского текста - используем АУТЕНТИЧНЫЙ русский JARVIS (Всеволод Кузнецов)
      if (this.russianJarvisVoiceId !== 'RUSSIAN_JARVIS_VOICE_ID') {
        console.log('🎯 Using AUTHENTIC Russian JARVIS voice (Всеволод Кузнецов)');
        return { voiceId: this.russianJarvisVoiceId, voiceName: 'Всеволод Кузнецов (Russian JARVIS)' };
      } else {
        console.log('⚠️ Russian JARVIS voice not configured, using Paul Bettany with multilingual');
        return { voiceId: this.paulBettanyVoiceId, voiceName: 'Paul Bettany (Fallback)' };
      }
    } else {
      // Для английского текста - стандартная логика
      const voiceId = isGlobalJarvis ? this.paulBettanyVoiceId : this.getPersonalVoiceId(personalTone);
      const voiceName = isGlobalJarvis ? 'Paul Bettany (English)' : 'Personal Voice';
      console.log(`🎯 Using English voice: ${voiceName}`);
      return { voiceId, voiceName };
    }
  }

  // Генерация настроек голоса на основе анализа оригинального голоса Всеволода
  private async generateVoiceSettings(personalTone: any): Promise<any> {
    try {
      // Получаем эволюционные параметры (если доступны) или оптимальные настройки
      console.log('🎭 Getting optimal voice settings from bio-singularity analysis...');
      
      let settings;
      try {
        settings = jarvisVoiceEvolution.getCurrentParameters();
        console.log('🧬 Using evolved voice parameters from bio-singularity learning');
      } catch (error) {
        // Fallback к анализу если эволюция недоступна
        const voiceAnalysis = await jarvisVoiceAnalyzer.getVoiceAnalysis();
        settings = { ...voiceAnalysis.optimalSettings };
        
        console.log('🧠 Bio-singularity analyzed original Vsevolod voice:');
        console.log(`   🎵 Pitch: ${voiceAnalysis.averagePitch.toFixed(1)} Hz`);
        console.log(`   🗣️  Speech Rate: ${voiceAnalysis.speechRate.toFixed(1)} wpm`);
        console.log(`   ⏸️  Pauses: ${voiceAnalysis.pauseDuration.toFixed(2)}s`);
        console.log(`   🎭 Emotional Range: ${voiceAnalysis.emotionalRange.toFixed(2)}`);
      }
      
      if (personalTone) {
        // Тонкая настройка на основе персонального тона
        const emotionalAdjustment = personalTone.energy * 0.1;
        settings.style = Math.max(0.1, Math.min(0.4, settings.style + emotionalAdjustment));
        
        const confidenceAdjustment = (personalTone.confidence - 0.5) * 0.05;
        settings.stability = Math.max(0.7, Math.min(0.95, settings.stability + confidenceAdjustment));
        
        console.log(`🎯 Adjusted for personal tone: style +${emotionalAdjustment.toFixed(2)}, stability +${confidenceAdjustment.toFixed(2)}`);
      }

      console.log('✅ Bio-singularity optimized voice settings:', settings);
      return settings;

    } catch (error) {
      console.warn('⚠️ Voice analysis failed, using optimized defaults');
      
      // Fallback к рабочим настройкам (те что давали чистый звук)
      if (!personalTone) {
        return {
          stability: 0.9,         // Рабочее значение 
          similarity_boost: 0.98, // Рабочее значение
          style: 0.19,            // Рабочее значение 
          use_speaker_boost: true
        };
      }

      const stability = Math.max(0.7, Math.min(0.95, 
        0.8 + (personalTone.confidence - 0.5) * 0.15
      ));
      
      const similarity_boost = Math.max(0.85, Math.min(0.95,
        0.9 + (personalTone.intelligence - 0.5) * 0.05
      ));
      
      const style = Math.max(0.1, Math.min(0.4,
        0.2 + personalTone.energy * 0.2
      ));

      return {
        stability,
        similarity_boost,
        style,
        use_speaker_boost: true
      };
    }
  }

  // Настройка русского JARVIS голоса
  setRussianJarvisVoice(voiceId: string): void {
    this.russianJarvisVoiceId = voiceId;
    console.log(`🇷🇺 Russian JARVIS voice configured: ${voiceId}`);
  }

  // Получение текущего русского голоса
  getRussianJarvisVoice(): string {
    return this.russianJarvisVoiceId;
  }

  // Получение ID персонального голоса (можно расширить для разных голосов)
  private getPersonalVoiceId(personalTone: any): string {
    // Пока используем Paul Bettany для всех, но архитектура готова для разных голосов
    return this.paulBettanyVoiceId;
  }

  // Continuous listening - активация по ключевым фразам
  async startContinuousListening(onWakeWordDetected: (audio: Buffer) => void): Promise<void> {
    if (this.isListening) {
      console.log('🎤 Already listening...');
      return;
    }

    try {
      console.log('🎤 Starting continuous listening for "Hey JARVIS"...');
      this.isListening = true;

      // Инициализация аудио контекста
      if (typeof window !== 'undefined') {
        this.audioContext = new (window.AudioContext || (window as any).webkitAudioContext)();
        
        const stream = await navigator.mediaDevices.getUserMedia({ 
          audio: {
            echoCancellation: true,
            noiseSuppression: true,
            sampleRate: 16000
          } 
        });

        this.mediaRecorder = new MediaRecorder(stream, {
          mimeType: 'audio/webm;codecs=opus'
        });

        this.mediaRecorder.ondataavailable = (event) => {
          this.audioChunks.push(event.data);
        };

        this.mediaRecorder.onstop = async () => {
          const audioBlob = new Blob(this.audioChunks, { type: 'audio/webm' });
          const audioBuffer = Buffer.from(await audioBlob.arrayBuffer());
          
          // Проверяем на ключевые фразы
          const transcription = await this.transcribeAudio(audioBuffer);
          if (this.isWakeWord(transcription.text)) {
            console.log('🎯 Wake word detected!');
            onWakeWordDetected(audioBuffer);
          }
          
          this.audioChunks = [];
          
          // Перезапускаем запись если еще слушаем
          if (this.isListening) {
            setTimeout(() => {
              if (this.mediaRecorder && this.isListening) {
                this.mediaRecorder.start(3000); // 3-секундные сегменты
              }
            }, 100);
          }
        };

        this.mediaRecorder.start(3000);
        console.log('✅ Continuous listening started');
      }

    } catch (error) {
      console.error('❌ Failed to start continuous listening:', error);
      this.isListening = false;
      throw error;
    }
  }

  // Остановка прослушивания
  stopContinuousListening(): void {
    console.log('🔇 Stopping continuous listening...');
    this.isListening = false;
    
    if (this.mediaRecorder) {
      this.mediaRecorder.stop();
      this.mediaRecorder = null;
    }
    
    if (this.audioContext) {
      this.audioContext.close();
      this.audioContext = null;
    }
    
    this.audioChunks = [];
    console.log('✅ Continuous listening stopped');
  }

  // Распознавание ключевых фраз активации
  private isWakeWord(text: string): boolean {
    const wakeWords = [
      'hey jarvis',
      'хей джарвис',
      'эй джарвис',
      'wake up jarvis',
      'просыпайся джарвис',
      'джарвис активация',
      'jarvis ready',
      'джарвис готов'
    ];

    const normalizedText = text.toLowerCase().trim();
    return wakeWords.some(wake => normalizedText.includes(wake));
  }

  // Воспроизведение аудио (клиентская сторона)
  async playAudio(audioBuffer: Buffer): Promise<void> {
    if (typeof window === 'undefined') {
      console.log('🔊 Audio playback available only in browser environment');
      return;
    }

    try {
      const audioContext = new (window.AudioContext || (window as any).webkitAudioContext)();
      const audioData = await audioContext.decodeAudioData(audioBuffer.buffer);
      
      const source = audioContext.createBufferSource();
      source.buffer = audioData;
      source.connect(audioContext.destination);
      source.start();
      
      console.log('🔊 Audio playback started');
    } catch (error) {
      console.error('❌ Audio playback failed:', error);
    }
  }

  // Установка русского голоса JARVIS
  setRussianJarvisVoice(voiceId: string): void {
    console.log(`🇷🇺 Setting Russian JARVIS voice: ${voiceId}`);
    this.russianJarvisVoiceId = voiceId;
    console.log(`✅ Russian JARVIS voice updated to: ${this.russianJarvisVoiceId}`);
  }

  // Получение текущего русского голоса
  getRussianJarvisVoice(): string {
    return this.russianJarvisVoiceId;
  }

  // Статус голосовой системы
  getVoiceStatus(): {
    elevenLabsConnected: boolean;
    whisperAvailable: boolean;
    listeningActive: boolean;
    audioContextReady: boolean;
    russianJarvisVoice: string;
    russianJarvisConfigured: boolean;
  } {
    return {
      elevenLabsConnected: !!this.elevenLabsApiKey,
      whisperAvailable: !!this.openai,
      listeningActive: this.isListening,
      audioContextReady: !!this.audioContext,
      russianJarvisVoice: this.russianJarvisVoiceId,
      russianJarvisConfigured: this.russianJarvisVoiceId !== 'RUSSIAN_JARVIS_VOICE_ID'
    };
  }
}

// Singleton instance
export const jarvisVoiceEngine = new JarvisVoiceEngine();