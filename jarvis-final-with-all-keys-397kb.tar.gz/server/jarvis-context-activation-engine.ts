/**
 * JARVIS Context Activation Engine
 * Определяет КОГДА JARVIS должен вмешаться в разговор
 * 
 * Это ключевая система того, как JARVIS работает у Тони Старка:
 * - Слышит ВСЕ разговоры (ambient listening)
 * - Анализирует контекст и важность
 * - Вмешивается только в критические моменты
 * - Развивается через биосингулярность
 */

interface ContextAnalysis {
  // Контекстные сигналы
  isDirectAddress: boolean;          // Прямое обращение к JARVIS
  isCriticalSituation: boolean;      // Критическая ситуация
  isStuckMoment: boolean;            // Пользователь "застрял"
  isAskingForHelp: boolean;         // Просит помощи (не прямо)
  isDiscussingWork: boolean;         // Обсуждает работу/проекты
  
  // Эмоциональные сигналы
  frustrationLevel: number;          // 0-100 уровень фрустрации
  confusionLevel: number;           // 0-100 уровень замешательства
  excitementLevel: number;          // 0-100 уровень возбуждения
  stressLevel: number;              // 0-100 уровень стресса
  
  // Ситуационные сигналы
  isPresentingToOthers: boolean;     // Презентует кому-то
  isInMeeting: boolean;             // На встрече/звонке
  isAlone: boolean;                 // Один
  isWithFamily: boolean;            // С семьей
  
  // Биосингулярные сигналы
  userNeedsGuidance: number;        // 0-100 нужна помощь
  jarvisRelevance: number;          // 0-100 релевантность JARVIS
  interventionConfidence: number;    // 0-100 уверенность во вмешательстве
}

interface ActivationDecision {
  shouldActivate: boolean;
  activationType: 'wake_word' | 'ambient_critical' | 'proactive_help' | 'emergency';
  confidence: number;
  reasoning: string;
  suggestedResponse?: string;
}

export class JarvisContextActivationEngine {
  private bioSingularity: any;
  private userId: string;
  
  // Пороги активации (развиваются через биосингулярность)
  private activationThresholds = {
    critical: 75,      // Критическая ситуация
    frustration: 80,   // Высокая фрустрация
    proactive: 65,     // Проактивная помощь
    confusion: 70,     // Замешательство
    presentation: 90   // Во время презентации (очень осторожно)
  };

  constructor(bioSingularity: any, userId: string) {
    this.bioSingularity = bioSingularity;
    this.userId = userId;
  }

  /**
   * ГЛАВНАЯ ФУНКЦИЯ: Анализ контекста и принятие решения об активации
   */
  async analyzeActivationContext(
    transcript: string,
    audioFeatures: any,
    situationalContext: any
  ): Promise<ActivationDecision> {
    
    // 1. Анализ прямого обращения (всегда активируем)
    if (this.detectDirectAddress(transcript)) {
      return {
        shouldActivate: true,
        activationType: 'wake_word',
        confidence: 100,
        reasoning: 'Direct address to JARVIS detected'
      };
    }

    // 2. Глубокий контекстный анализ
    const context = await this.analyzeDeepContext(transcript, audioFeatures, situationalContext);
    
    // 3. Биосингулярное принятие решения
    const decision = await this.makeBioSingularDecision(context);
    
    return decision;
  }

  /**
   * Определение прямого обращения к JARVIS
   */
  private detectDirectAddress(transcript: string): boolean {
    const lowerTranscript = transcript.toLowerCase();
    
    // Классические wake words
    const wakeWords = [
      'hey jarvis', 'jarvis', 'джарвис', 
      'wake up jarvis', 'activate jarvis'
    ];
    
    // Неявные обращения (как у Тони)
    const implicitAddresses = [
      'what do you think', 'что думаешь',
      'any suggestions', 'предложения',
      'run analysis', 'analyze this',
      'show me', 'покажи мне'
    ];

    return wakeWords.some(word => lowerTranscript.includes(word)) ||
           implicitAddresses.some(phrase => lowerTranscript.includes(phrase));
  }

  /**
   * Глубокий анализ контекста разговора
   */
  private async analyzeDeepContext(
    transcript: string, 
    audioFeatures: any, 
    situationalContext: any
  ): Promise<ContextAnalysis> {
    
    const analysis: ContextAnalysis = {
      // Контекстные сигналы
      isDirectAddress: this.detectDirectAddress(transcript),
      isCriticalSituation: this.detectCriticalSituation(transcript),
      isStuckMoment: this.detectStuckMoment(transcript, audioFeatures),
      isAskingForHelp: this.detectHelpRequest(transcript),
      isDiscussingWork: this.detectWorkDiscussion(transcript),
      
      // Эмоциональные сигналы из голоса
      frustrationLevel: this.analyzeFrustration(audioFeatures),
      confusionLevel: this.analyzeConfusion(audioFeatures),
      excitementLevel: this.analyzeExcitement(audioFeatures),
      stressLevel: this.analyzeStress(audioFeatures),
      
      // Ситуационные сигналы
      isPresentingToOthers: situationalContext?.isPresenting || false,
      isInMeeting: situationalContext?.isInMeeting || false,
      isAlone: situationalContext?.isAlone !== false,
      isWithFamily: situationalContext?.isWithFamily || false,
      
      // Биосингулярные инсайты
      userNeedsGuidance: await this.assessGuidanceNeed(transcript),
      jarvisRelevance: await this.assessJarvisRelevance(transcript),
      interventionConfidence: 0 // Будет вычислен ниже
    };

    // Вычисляем общую уверенность во вмешательстве
    analysis.interventionConfidence = this.calculateInterventionConfidence(analysis);
    
    return analysis;
  }

  /**
   * Детекция критической ситуации (как у Тони в фильмах)
   */
  private detectCriticalSituation(transcript: string): boolean {
    const criticalPhrases = [
      'не работает', 'broken', 'ошибка', 'error',
      'срочно', 'urgent', 'помогите', 'help',
      'что делать', 'what to do', 'застрял', 'stuck',
      'не понимаю', 'confused', 'не получается', 'failing'
    ];

    return criticalPhrases.some(phrase => 
      transcript.toLowerCase().includes(phrase)
    );
  }

  /**
   * Детекция момента "застревания" пользователя
   */
  private detectStuckMoment(transcript: string, audioFeatures: any): boolean {
    // Лингвистические маркеры
    const stuckPhrases = [
      'хм', 'hmm', 'эээ', 'umm', 'блин', 'damn',
      'не знаю', "don't know", 'как же', 'how to'
    ];
    
    // Голосовые маркеры (паузы, нерешительность)
    const hasLongPauses = audioFeatures?.pauseDuration > 3000; // 3+ секунд
    const hasUncertainty = audioFeatures?.uncertaintyLevel > 0.7;
    
    const hasStuckLanguage = stuckPhrases.some(phrase => 
      transcript.toLowerCase().includes(phrase)
    );

    return hasStuckLanguage || hasLongPauses || hasUncertainty;
  }

  /**
   * Анализ эмоций из голосовых характеристик
   */
  private analyzeFrustration(audioFeatures: any): number {
    if (!audioFeatures) return 0;
    
    // Маркеры фрустрации: повышенный тон, быстрая речь, резкость
    let frustration = 0;
    
    if (audioFeatures.pitch > audioFeatures.avgPitch * 1.3) frustration += 30;
    if (audioFeatures.speed > audioFeatures.avgSpeed * 1.4) frustration += 25;
    if (audioFeatures.volume > audioFeatures.avgVolume * 1.2) frustration += 20;
    if (audioFeatures.sharpness > 0.7) frustration += 25;
    
    return Math.min(frustration, 100);
  }

  private analyzeConfusion(audioFeatures: any): number {
    if (!audioFeatures) return 0;
    
    // Маркеры замешательства: паузы, медленная речь, неуверенность
    let confusion = 0;
    
    if (audioFeatures.pauseDuration > 2000) confusion += 40;
    if (audioFeatures.speed < audioFeatures.avgSpeed * 0.7) confusion += 30;
    if (audioFeatures.uncertaintyLevel > 0.6) confusion += 30;
    
    return Math.min(confusion, 100);
  }

  private analyzeStress(audioFeatures: any): number {
    if (!audioFeatures) return 0;
    
    // Маркеры стресса: дрожание голоса, высокий тон, быстрая речь
    let stress = 0;
    
    if (audioFeatures.tremor > 0.5) stress += 35;
    if (audioFeatures.pitch > audioFeatures.avgPitch * 1.4) stress += 30;
    if (audioFeatures.breathingPattern === 'irregular') stress += 35;
    
    return Math.min(stress, 100);
  }

  private analyzeExcitement(audioFeatures: any): number {
    if (!audioFeatures) return 0;
    
    // Маркеры возбуждения: энергичная речь, повышенный тон, быстрый темп
    let excitement = 0;
    
    if (audioFeatures.energy > 0.7) excitement += 40;
    if (audioFeatures.pitch > audioFeatures.avgPitch * 1.2) excitement += 30;
    if (audioFeatures.speed > audioFeatures.avgSpeed * 1.2) excitement += 30;
    
    return Math.min(excitement, 100);
  }

  /**
   * Биосингулярная оценка необходимости вмешательства
   */
  private async assessGuidanceNeed(transcript: string): Promise<number> {
    // Здесь биосингулярность анализирует паттерны пользователя
    // и определяет, нужна ли помощь основываясь на:
    // - Истории взаимодействий
    // - Персональных теориях о пользователе  
    // - Эмоциональной памяти
    
    try {
      const bioAnalysis = await this.bioSingularity.analyzeGuidanceNeed({
        transcript,
        userId: this.userId,
        context: 'ambient_listening'
      });
      
      return bioAnalysis.guidanceNeedLevel || 0;
    } catch {
      return 0;
    }
  }

  private async assessJarvisRelevance(transcript: string): Promise<number> {
    // Биосингулярность определяет, насколько JARVIS релевантен
    // текущему разговору основываясь на:
    // - Тематике разговора
    // - Специализации JARVIS
    // - Персональных предпочтениях пользователя
    
    try {
      const bioAnalysis = await this.bioSingularity.analyzeJarvisRelevance({
        transcript,
        userId: this.userId,
        context: 'topic_analysis'
      });
      
      return bioAnalysis.relevanceLevel || 0;
    } catch {
      return 0;
    }
  }

  /**
   * Вычисление общей уверенности во вмешательстве
   */
  private calculateInterventionConfidence(analysis: ContextAnalysis): number {
    let confidence = 0;
    
    // Критическая ситуация = высокий приоритет
    if (analysis.isCriticalSituation) confidence += 40;
    
    // Высокая фрустрация = нужна помощь
    if (analysis.frustrationLevel > 70) confidence += 30;
    
    // Замешательство = возможно нужно объяснение
    if (analysis.confusionLevel > 60) confidence += 25;
    
    // Момент "застревания" = помощь уместна
    if (analysis.isStuckMoment) confidence += 35;
    
    // Биосингулярные инсайты
    confidence += (analysis.userNeedsGuidance * 0.3);
    confidence += (analysis.jarvisRelevance * 0.2);
    
    // Снижаем если презентация или встреча
    if (analysis.isPresentingToOthers) confidence *= 0.3;
    if (analysis.isInMeeting) confidence *= 0.5;
    
    // Повышаем если один на один
    if (analysis.isAlone) confidence *= 1.2;
    
    return Math.min(confidence, 100);
  }

  /**
   * Финальное решение о вмешательстве через биосингулярность
   */
  private async makeBioSingularDecision(analysis: ContextAnalysis): Promise<ActivationDecision> {
    
    // Аварийная ситуация - вмешиваемся всегда
    if (analysis.isCriticalSituation && analysis.interventionConfidence > this.activationThresholds.critical) {
      return {
        shouldActivate: true,
        activationType: 'ambient_critical',
        confidence: analysis.interventionConfidence,
        reasoning: 'Critical situation detected - intervention required',
        suggestedResponse: 'Sir, I noticed you might need assistance with this issue.'
      };
    }

    // Высокая фрустрация - предлагаем помощь
    if (analysis.frustrationLevel > this.activationThresholds.frustration && analysis.isAlone) {
      return {
        shouldActivate: true,
        activationType: 'proactive_help',
        confidence: analysis.interventionConfidence,
        reasoning: 'High frustration detected - offering assistance',
        suggestedResponse: 'I can see you\'re working through something challenging. Would you like me to help?'
      };
    }

    // Момент застревания + высокая релевантность JARVIS
    if (analysis.isStuckMoment && 
        analysis.jarvisRelevance > 70 && 
        analysis.interventionConfidence > this.activationThresholds.proactive) {
      return {
        shouldActivate: true,
        activationType: 'proactive_help',
        confidence: analysis.interventionConfidence,
        reasoning: 'User appears stuck in JARVIS-relevant area',
        suggestedResponse: 'It looks like you might benefit from a different approach here.'
      };
    }

    // По умолчанию не вмешиваемся
    return {
      shouldActivate: false,
      activationType: 'wake_word',
      confidence: analysis.interventionConfidence,
      reasoning: 'Context does not warrant intervention - continuing ambient monitoring'
    };
  }

  /**
   * Детекция обсуждения рабочих вопросов
   */
  private detectWorkDiscussion(transcript: string): boolean {
    const workKeywords = [
      'проект', 'project', 'код', 'code', 'алгоритм', 'algorithm',
      'технология', 'technology', 'система', 'system', 'разработка', 'development',
      'программа', 'program', 'архитектура', 'architecture', 'база данных', 'database'
    ];

    return workKeywords.some(keyword => 
      transcript.toLowerCase().includes(keyword)
    );
  }

  /**
   * Детекция неявных просьб о помощи
   */
  private detectHelpRequest(transcript: string): boolean {
    const helpPhrases = [
      'как это сделать', 'how to do', 'что делать', 'what to do',
      'не знаю как', "don't know how", 'подскажи', 'tell me',
      'объясни', 'explain', 'покажи', 'show me'
    ];

    return helpPhrases.some(phrase => 
      transcript.toLowerCase().includes(phrase)
    );
  }

  /**
   * Обновление порогов активации через биосингулярность
   */
  async evolveBioSingularThresholds(feedback: any): Promise<void> {
    // Биосингулярность учится на обратной связи:
    // - Если пользователь был рад вмешательству = снижаем пороги
    // - Если вмешательство было неуместным = повышаем пороги
    // - Адаптируемся под личные предпочтения пользователя
    
    try {
      await this.bioSingularity.evolveActivationThresholds({
        userId: this.userId,
        feedback,
        currentThresholds: this.activationThresholds
      });
    } catch (error) {
      console.error('Failed to evolve thresholds:', error);
    }
  }
}

export { ContextAnalysis, ActivationDecision };