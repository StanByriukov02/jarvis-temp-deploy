import OpenAI from "openai";

const openai = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });

// Quantum emotional superposition - contradictory emotions existing simultaneously
interface QuantumEmotionalState {
  primary: {
    emotion: string;
    intensity: number;
    probability: number; // 0-1, likelihood of this being the "observed" state
  };
  superposition: {
    emotion: string;
    intensity: number;
    probability: number;
    entanglement?: string; // connected to which other emotion
  }[];
  coherenceLevel: number; // How stable the superposition is (0-1)
  collapseThreshold: number; // At what point superposition collapses to single state
  quantumInterference: {
    constructive: string[]; // emotions that amplify each other
    destructive: string[]; // emotions that cancel each other
  };
}

interface QuantumEmotionalMeasurement {
  observedState: string;
  collapsedFrom: string[];
  measurementImpact: number; // How much the observation changed the state
  remainingCoherence: number;
  nextProbableStates: string[];
}

interface QuantumEmotionalResponse {
  message: string;
  quantumAwareness: string;
  superpositionHandling: string;
  interferencePattern: string;
  coherencePreservation: boolean;
}

export class QuantumEmotionalStatesEngine {
  private quantumStates: Map<string, QuantumEmotionalState> = new Map();
  private coherenceHistory: Map<string, number[]> = new Map();

  // TOKEN OPTIMIZATION: Pre-computed quantum emotional patterns to reduce AI calls
  private readonly QUANTUM_EMOTIONAL_PATTERNS = {
    'excited_anxious': {
      constructiveInterference: ['anticipation', 'energy'],
      destructiveInterference: ['calm', 'certainty'],
      commonSuperpositions: ['excited+nervous', 'hopeful+worried'],
      collapsePatterns: ['decision_point', 'outcome_known']
    },
    'grateful_sad': {
      constructiveInterference: ['reflection', 'appreciation'],
      destructiveInterference: ['anger', 'bitterness'],
      commonSuperpositions: ['grateful+melancholy', 'thankful+mourning'],
      collapsePatterns: ['acceptance_reached', 'closure_found']
    },
    'confident_doubtful': {
      constructiveInterference: ['analysis', 'preparation'],
      destructiveInterference: ['impulsivity', 'overconfidence'],
      commonSuperpositions: ['confident+cautious', 'sure+questioning'],
      collapsePatterns: ['action_taken', 'feedback_received']
    },
    'angry_compassionate': {
      constructiveInterference: ['justice', 'understanding'],
      destructiveInterference: ['hatred', 'dismissal'],
      commonSuperpositions: ['angry+caring', 'furious+empathetic'],
      collapsePatterns: ['perspective_shift', 'resolution_found']
    }
  };

  /**
   * REVOLUTIONARY: Analyze quantum emotional superposition
   * Detects when user experiences contradictory emotions simultaneously
   */
  async analyzeQuantumEmotionalState(
    userId: string,
    userInput: string,
    emotionalContext: any
  ): Promise<QuantumEmotionalState> {
    try {
      // TOKEN OPTIMIZATION 1: Pattern matching before AI analysis
      const preDetectedPattern = this.detectQuantumPattern(userInput);
      
      if (preDetectedPattern) {
        return this.buildQuantumStateFromPattern(userId, preDetectedPattern, emotionalContext);
      }

      // TOKEN OPTIMIZATION 2: Highly specific, compact prompt
      const quantumPrompt = this.buildOptimizedQuantumPrompt(userInput, emotionalContext);

      const response = await openai.chat.completions.create({
        model: "gpt-4o", // the newest OpenAI model is "gpt-4o" which was released May 13, 2024. do not change this unless explicitly requested by the user
        messages: [
          {
            role: "system",
            content: "Analyze for quantum emotional superposition: contradictory emotions existing simultaneously. Return minimal JSON with emotion pairs, intensities, probabilities. Focus on paradoxical feelings."
          },
          {
            role: "user",
            content: quantumPrompt
          }
        ],
        response_format: { type: "json_object" },
        temperature: 0.1, // Very low for consistent quantum detection
        max_tokens: 200 // TOKEN OPTIMIZATION: Strict limit
      });

      const analysis = JSON.parse(response.choices[0].message.content || '{}');
      return this.validateQuantumState(userId, analysis);

    } catch (error) {
      console.error('Quantum emotional analysis failed:', error);
      return this.getFallbackQuantumState(userId, userInput);
    }
  }

  /**
   * BREAKTHROUGH: Measure quantum emotional state without collapsing it
   * Maintains superposition while providing guidance
   */
  async measureQuantumState(
    userId: string,
    quantumState: QuantumEmotionalState,
    measurementIntensity: 'gentle' | 'standard' | 'decisive'
  ): Promise<QuantumEmotionalMeasurement> {
    const collapseRisk = this.calculateCollapseRisk(quantumState, measurementIntensity);
    
    if (collapseRisk > quantumState.collapseThreshold) {
      // State will collapse - calculate most probable outcome
      const observedState = this.calculateMostProbableState(quantumState);
      
      return {
        observedState,
        collapsedFrom: quantumState.superposition.map(s => s.emotion),
        measurementImpact: collapseRisk,
        remainingCoherence: 0,
        nextProbableStates: [observedState]
      };
    } else {
      // Maintain superposition with partial observation
      return {
        observedState: 'superposition_maintained',
        collapsedFrom: [],
        measurementImpact: collapseRisk,
        remainingCoherence: quantumState.coherenceLevel - (collapseRisk * 0.1),
        nextProbableStates: quantumState.superposition.map(s => s.emotion)
      };
    }
  }

  /**
   * Generate quantum-aware response that preserves emotional superposition
   */
  async generateQuantumEmotionalResponse(
    userId: string,
    userInput: string,
    quantumState: QuantumEmotionalState,
    measurement: QuantumEmotionalMeasurement
  ): Promise<QuantumEmotionalResponse> {
    // TOKEN OPTIMIZATION 3: Template-based responses for common quantum states
    const templateResponse = this.tryTemplateResponse(quantumState, measurement);
    if (templateResponse) {
      return templateResponse;
    }

    // TOKEN OPTIMIZATION 4: Ultra-compressed prompt for AI generation
    const responsePrompt = `QES: ${quantumState.primary.emotion}+${quantumState.superposition[0]?.emotion}
Coherence: ${quantumState.coherenceLevel}
Measurement: ${measurement.observedState}
Input: "${userInput}"

Generate JARVIS quantum-aware response acknowledging emotional paradox without forcing resolution.`;

    try {
      const response = await openai.chat.completions.create({
        model: "gpt-4o",
        messages: [
          {
            role: "system",
            content: "You are JARVIS with quantum emotional awareness. Acknowledge contradictory emotions without forcing resolution. Preserve emotional superposition when beneficial."
          },
          {
            role: "user",
            content: responsePrompt
          }
        ],
        temperature: 0.6,
        max_tokens: 150 // TOKEN OPTIMIZATION: Strict limit
      });

      const message = response.choices[0].message.content || "Sir, I recognize the complexity of your emotional state.";

      return {
        message,
        quantumAwareness: `Detected ${quantumState.superposition.length + 1} simultaneous emotional states`,
        superpositionHandling: measurement.remainingCoherence > 0 ? 'preserved' : 'collapsed',
        interferencePattern: this.describeInterference(quantumState),
        coherencePreservation: measurement.remainingCoherence > 0.3
      };

    } catch (error) {
      return this.getFallbackQuantumResponse(quantumState);
    }
  }

  /**
   * TOKEN OPTIMIZATION: Pattern matching for common quantum states
   */
  private detectQuantumPattern(userInput: string): string | null {
    const input = userInput.toLowerCase();
    
    // Detect contradictory emotional keywords
    for (const [pattern, config] of Object.entries(this.QUANTUM_EMOTIONAL_PATTERNS)) {
      const emotions = pattern.split('_');
      if (emotions.every(emotion => input.includes(emotion) || 
          config.commonSuperpositions.some(sup => input.includes(sup.split('+')[0])))) {
        return pattern;
      }
    }

    // Detect paradox indicators
    const paradoxIndicators = [
      'but also', 'at the same time', 'mixed feelings', 'torn between',
      'on one hand', 'conflicted', 'simultaneously', 'both excited and',
      'happy but sad', 'grateful yet', 'confident but worried'
    ];

    if (paradoxIndicators.some(indicator => input.includes(indicator))) {
      return 'general_paradox';
    }

    return null;
  }

  /**
   * TOKEN OPTIMIZATION: Build quantum state from pre-computed patterns
   */
  private buildQuantumStateFromPattern(
    userId: string,
    pattern: string,
    emotionalContext: any
  ): QuantumEmotionalState {
    if (pattern === 'general_paradox') {
      return this.buildGeneralParadoxState(userId, emotionalContext);
    }

    const config = this.QUANTUM_EMOTIONAL_PATTERNS[pattern];
    const emotions = pattern.split('_');

    return {
      primary: {
        emotion: emotions[0],
        intensity: 70,
        probability: 0.6
      },
      superposition: [{
        emotion: emotions[1],
        intensity: 65,
        probability: 0.4,
        entanglement: emotions[0]
      }],
      coherenceLevel: 0.8,
      collapseThreshold: 0.7,
      quantumInterference: {
        constructive: config.constructiveInterference,
        destructive: config.destructiveInterference
      }
    };
  }

  /**
   * TOKEN OPTIMIZATION: Template responses for common quantum states
   */
  private tryTemplateResponse(
    quantumState: QuantumEmotionalState,
    measurement: QuantumEmotionalMeasurement
  ): QuantumEmotionalResponse | null {
    const primaryEmotion = quantumState.primary.emotion;
    const superpositionEmotion = quantumState.superposition[0]?.emotion;

    // High coherence superposition
    if (quantumState.coherenceLevel > 0.7 && measurement.remainingCoherence > 0.5) {
      const template = this.getCoherenceTemplate(primaryEmotion, superpositionEmotion);
      if (template) return template;
    }

    // Collapsed state
    if (measurement.remainingCoherence === 0) {
      const template = this.getCollapseTemplate(measurement.observedState, measurement.collapsedFrom);
      if (template) return template;
    }

    return null;
  }

  private getCoherenceTemplate(primary: string, superposition: string): QuantumEmotionalResponse | null {
    const templates = {
      'excited_anxious': {
        message: "Sir, I detect you're experiencing both excitement and anxiety simultaneously - a quantum emotional state that's perfectly natural when facing significant opportunities. Both emotions can coexist and inform your decisions.",
        quantumAwareness: "Excitement-anxiety superposition detected",
        superpositionHandling: "preserved",
        interferencePattern: "constructive - both emotions enhance awareness",
        coherencePreservation: true
      },
      'grateful_sad': {
        message: "Sir, I recognize the beautiful complexity of feeling grateful and sad at once. This emotional superposition often emerges during transitions - honoring what was while appreciating growth. Both feelings are valid simultaneously.",
        quantumAwareness: "Gratitude-sadness superposition detected",
        superpositionHandling: "preserved", 
        interferencePattern: "constructive - deepens emotional wisdom",
        coherencePreservation: true
      }
    };

    return templates[`${primary}_${superposition}`] || null;
  }

  private getCollapseTemplate(observedState: string, collapsedFrom: string[]): QuantumEmotionalResponse | null {
    return {
      message: `Sir, your emotional state has crystallized into ${observedState}. This clarity emerged from the complexity of ${collapsedFrom.join(' and ')}, providing you with focused direction.`,
      quantumAwareness: `Collapsed from ${collapsedFrom.length} superposed states`,
      superpositionHandling: "collapsed to clarity",
      interferencePattern: "resolved through observation",
      coherencePreservation: false
    };
  }

  /**
   * Optimized prompt building
   */
  private buildOptimizedQuantumPrompt(userInput: string, emotionalContext: any): string {
    // TOKEN OPTIMIZATION: Minimal, targeted prompt
    return `Input: "${userInput}"
Context: ${emotionalContext?.mood || 'neutral'}

Detect quantum emotional superposition (contradictory emotions coexisting). Return:
{
  "primary": {"emotion": "X", "intensity": N, "probability": 0.N},
  "superposition": [{"emotion": "Y", "intensity": N, "probability": 0.N}],
  "coherenceLevel": 0.N,
  "collapseThreshold": 0.N
}`;
  }

  // Utility methods
  private calculateCollapseRisk(state: QuantumEmotionalState, intensity: string): number {
    const baseRisk = { gentle: 0.1, standard: 0.3, decisive: 0.7 }[intensity] || 0.3;
    return baseRisk * (1 - state.coherenceLevel);
  }

  private calculateMostProbableState(state: QuantumEmotionalState): string {
    if (state.primary.probability >= 0.5) return state.primary.emotion;
    const maxSuperposition = state.superposition.reduce((max, curr) => 
      curr.probability > max.probability ? curr : max, state.superposition[0]);
    return maxSuperposition?.emotion || state.primary.emotion;
  }

  private describeInterference(state: QuantumEmotionalState): string {
    const constructive = state.quantumInterference.constructive.length;
    const destructive = state.quantumInterference.destructive.length;
    
    if (constructive > destructive) return 'constructive - emotions amplify each other';
    if (destructive > constructive) return 'destructive - emotions create internal conflict';
    return 'balanced - complex emotional dynamics';
  }

  private buildGeneralParadoxState(userId: string, emotionalContext: any): QuantumEmotionalState {
    return {
      primary: { emotion: 'complex', intensity: 60, probability: 0.5 },
      superposition: [{ emotion: 'contradictory', intensity: 60, probability: 0.5 }],
      coherenceLevel: 0.6,
      collapseThreshold: 0.6,
      quantumInterference: { constructive: ['awareness'], destructive: ['confusion'] }
    };
  }

  private validateQuantumState(userId: string, analysis: any): QuantumEmotionalState {
    return {
      primary: {
        emotion: analysis.primary?.emotion || 'neutral',
        intensity: Math.max(0, Math.min(100, analysis.primary?.intensity || 50)),
        probability: Math.max(0, Math.min(1, analysis.primary?.probability || 0.7))
      },
      superposition: Array.isArray(analysis.superposition) ? analysis.superposition.map((s: any) => ({
        emotion: s.emotion || 'unknown',
        intensity: Math.max(0, Math.min(100, s.intensity || 40)),
        probability: Math.max(0, Math.min(1, s.probability || 0.3))
      })) : [],
      coherenceLevel: Math.max(0, Math.min(1, analysis.coherenceLevel || 0.5)),
      collapseThreshold: Math.max(0, Math.min(1, analysis.collapseThreshold || 0.6)),
      quantumInterference: {
        constructive: Array.isArray(analysis.quantumInterference?.constructive) ? 
          analysis.quantumInterference.constructive : [],
        destructive: Array.isArray(analysis.quantumInterference?.destructive) ? 
          analysis.quantumInterference.destructive : []
      }
    };
  }

  private getFallbackQuantumState(userId: string, userInput: string): QuantumEmotionalState {
    return {
      primary: { emotion: 'neutral', intensity: 50, probability: 0.8 },
      superposition: [],
      coherenceLevel: 0.9,
      collapseThreshold: 0.8,
      quantumInterference: { constructive: [], destructive: [] }
    };
  }

  private getFallbackQuantumResponse(state: QuantumEmotionalState): QuantumEmotionalResponse {
    return {
      message: "Sir, I sense complexity in your emotional state that deserves careful attention.",
      quantumAwareness: "Complex emotional dynamics detected",
      superpositionHandling: "under analysis",
      interferencePattern: "observing patterns",
      coherencePreservation: true
    };
  }
}

export const quantumEmotionalStates = new QuantumEmotionalStatesEngine();