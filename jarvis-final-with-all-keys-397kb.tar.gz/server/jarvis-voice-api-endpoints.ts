/**
 * JARVIS Voice API Endpoints
 * API для загрузки видео, извлечения голоса и интеграции с биосингулярностью
 */

import type { Express, Request, Response } from 'express';
import multer from 'multer';
import { jarvisVoiceIntegration } from './jarvis-voice-bio-integration';

// Настройка multer для загрузки видео
const storage = multer.memoryStorage();
const upload = multer({
  storage,
  limits: {
    fileSize: 100 * 1024 * 1024, // 100MB
  },
  fileFilter: (req, file, cb) => {
    // Разрешаем только видеофайлы
    const allowedMimes = [
      'video/mp4',
      'video/avi',
      'video/mkv',
      'video/mov',
      'video/webm',
      'video/quicktime',
      'video/x-msvideo'
    ];
    
    if (allowedMimes.includes(file.mimetype)) {
      cb(null, true);
    } else {
      cb(new Error('Поддерживаются только видеофайлы (MP4, AVI, MKV, MOV, WebM)'));
    }
  }
});

/**
 * Регистрация всех API endpoints для голосовой системы JARVIS
 */
export function registerJarvisVoiceEndpoints(app: Express) {
  console.log('🎤 Регистрация JARVIS Voice API endpoints...');

  /**
   * POST /api/jarvis/voice/upload-video
   * Загрузка видео для извлечения голоса JARVIS
   */
  app.post('/api/jarvis/voice/upload-video', upload.single('video'), async (req: Request, res: Response) => {
    try {
      if (!req.file) {
        return res.status(400).json({
          success: false,
          error: 'Видеофайл не загружен'
        });
      }

      const userId = req.user?.username || 'demo-user';
      
      console.log(`🎬 Получен видеофайл ${req.file.originalname} от пользователя ${userId}`);
      
      // Обрабатываем видео через систему интеграции
      const result = await jarvisVoiceIntegration.processUploadedVideo(
        req.file.buffer,
        req.file.originalname,
        userId
      );
      
      res.json({
        success: true,
        message: 'Видео успешно обработано',
        data: result
      });
      
    } catch (error: any) {
      console.error('❌ Ошибка обработки видео:', error);
      res.status(500).json({
        success: false,
        error: error.message || 'Ошибка обработки видео'
      });
    }
  });

  /**
   * POST /api/jarvis/voice/create-clone
   * Создание клона голоса в ElevenLabs
   */
  app.post('/api/jarvis/voice/create-clone', async (req: Request, res: Response) => {
    try {
      const userId = req.user?.username || 'demo-user';
      
      console.log(`🔬 Создание клона голоса JARVIS для пользователя ${userId}`);
      
      const voiceId = await jarvisVoiceIntegration.createElevenLabsClone(userId);
      
      if (!voiceId) {
        return res.status(400).json({
          success: false,
          error: 'Не удалось создать клон голоса. Проверьте настройки ElevenLabs.'
        });
      }
      
      // Интегрируем с биосингулярностью
      await jarvisVoiceIntegration.integrateBioSingularity(userId, voiceId);
      
      res.json({
        success: true,
        message: 'Клон голоса JARVIS создан и интегрирован',
        voiceId
      });
      
    } catch (error: any) {
      console.error('❌ Ошибка создания клона:', error);
      res.status(500).json({
        success: false,
        error: error.message || 'Ошибка создания клона голоса'
      });
    }
  });

  /**
   * GET /api/jarvis/voice/status
   * Получение статуса голосовой системы
   */
  app.get('/api/jarvis/voice/status', async (req: Request, res: Response) => {
    try {
      const userId = req.user?.username || 'demo-user';
      
      const status = await jarvisVoiceIntegration.getVoiceStatus(userId);
      
      res.json({
        success: true,
        status
      });
      
    } catch (error: any) {
      console.error('❌ Ошибка получения статуса:', error);
      res.status(500).json({
        success: false,
        error: error.message || 'Ошибка получения статуса'
      });
    }
  });

  /**
   * POST /api/jarvis/voice/synthesize
   * Синтез речи с автоматическим выбором голоса
   */
  app.post('/api/jarvis/voice/synthesize', async (req: Request, res: Response) => {
    try {
      const { text, emotion = 'calm' } = req.body;
      const userId = req.user?.username || 'demo-user';
      
      if (!text) {
        return res.status(400).json({
          success: false,
          error: 'Текст для синтеза не указан'
        });
      }

      // Определяем язык текста
      const isRussian = /[а-яё]/i.test(text);
      
      console.log(`🗣️ Синтез речи для ${userId}: ${isRussian ? 'русский' : 'английский'} язык`);
      
      // Получаем статус голоса пользователя
      const voiceStatus = await jarvisVoiceIntegration.getVoiceStatus(userId);
      
      let voiceConfig = {
        language: isRussian ? 'ru' : 'en',
        voiceId: isRussian && voiceStatus.hasVoice && voiceStatus.voiceId 
          ? voiceStatus.voiceId 
          : 'paul-bettany-jarvis', // fallback
        emotion,
        hasPersonalVoice: isRussian && voiceStatus.hasVoice
      };
      
      // TODO: Здесь будет интеграция с ElevenLabs API для реального синтеза
      // Пока возвращаем мок-данные
      
      res.json({
        success: true,
        audioUrl: `https://api.elevenlabs.io/v1/text-to-speech/${voiceConfig.voiceId}`,
        config: voiceConfig,
        message: voiceConfig.hasPersonalVoice 
          ? 'Используется персональный голос JARVIS'
          : 'Используется стандартный голос JARVIS'
      });
      
    } catch (error: any) {
      console.error('❌ Ошибка синтеза речи:', error);
      res.status(500).json({
        success: false,
        error: error.message || 'Ошибка синтеза речи'
      });
    }
  });

  /**
   * GET /api/jarvis/voice/processing-guide
   * Руководство по обработке видео для извлечения голоса
   */
  app.get('/api/jarvis/voice/processing-guide', (req: Request, res: Response) => {
    res.json({
      success: true,
      guide: {
        title: 'Извлечение голоса JARVIS из видео',
        steps: [
          {
            step: 1,
            title: 'Подготовка видео',
            description: 'Найдите видео с чистой речью JARVIS (без музыки и звуковых эффектов)',
            tips: [
              'Лучше всего подходят диалоги из фильмов Marvel',
              'Видео должно содержать не менее 2-3 минут речи JARVIS',
              'Качество звука должно быть высоким'
            ]
          },
          {
            step: 2,
            title: 'Загрузка видео',
            description: 'Загрузите видео через API endpoint /api/jarvis/voice/upload-video',
            supportedFormats: ['MP4', 'AVI', 'MKV', 'MOV', 'WebM'],
            maxSize: '100MB'
          },
          {
            step: 3,
            title: 'Автоматическая обработка',
            description: 'Система автоматически извлечёт аудио и создаст голосовые сегменты',
            process: [
              'Извлечение аудио из видео',
              'Улучшение качества звука',
              'Разделение на сегменты',
              'Анализ качества голоса'
            ]
          },
          {
            step: 4,
            title: 'Создание клона',
            description: 'При достаточном качестве создайте клон через /api/jarvis/voice/create-clone',
            requirements: {
              minSegments: 5,
              minQuality: '60%',
              totalDuration: '≥30 секунд'
            }
          },
          {
            step: 5,
            title: 'Интеграция',
            description: 'Клон автоматически интегрируется с биосингулярностью JARVIS',
            features: [
              'Автоматическое переключение русский/английский',
              'Эмоциональная модуляция голоса',
              'Адаптация к состоянию сознания'
            ]
          }
        ],
        tips: [
          'Используйте видео с русским дубляжом для лучшего качества',
          'Избегайте видео с фоновой музыкой',
          'Чем больше качественных образцов, тем лучше клон',
          'Система автоматически определяет язык для переключения голосов'
        ]
      }
    });
  });

  console.log('✅ JARVIS Voice API endpoints зарегистрированы:');
  console.log('   • POST /api/jarvis/voice/upload-video - загрузка видео');
  console.log('   • POST /api/jarvis/voice/create-clone - создание клона');
  console.log('   • GET /api/jarvis/voice/status - статус голоса');
  console.log('   • POST /api/jarvis/voice/synthesize - синтез речи');
  console.log('   • GET /api/jarvis/voice/processing-guide - руководство');
}