// JARVIS Unified Coordination System
// Интеграция между Offline Mode (ЭТАП 3) и Device Discovery (ЭТАП 4)

import { EventEmitter } from 'events';
import { jarvisOfflineMode } from './jarvis-offline-mode';
import { jarvisDeviceDiscovery, DeviceInfo, PermissionLevel } from './jarvis-device-discovery';

interface CoordinationConfig {
  enableThreatSynchronization: boolean;
  enableDeviceProtectionProtocols: boolean;
  enableUnifiedVoiceActivation: boolean;
  threatEscalationThreshold: number;
  deviceTrustLevels: {
    [key: string]: number; // deviceId -> trust level (0-1)
  };
}

interface UnifiedThreatDetection {
  threatId: string;
  threatType: string;
  threatLevel: 'LOW' | 'MEDIUM' | 'HIGH' | 'CRITICAL';
  sourceDevice: string;
  affectedDevices: string[];
  detectionTime: number;
  protocolsActivated: string[];
  requiresVoiceConfirmation: boolean;
}

class JarvisUnifiedCoordination extends EventEmitter {
  private config: CoordinationConfig;
  private activeThreatScenarios: Map<string, UnifiedThreatDetection> = new Map();
  private deviceTrustScores: Map<string, number> = new Map();
  private isCoordinationActive: boolean = false;

  constructor() {
    super();
    
    this.config = {
      enableThreatSynchronization: true,
      enableDeviceProtectionProtocols: true,
      enableUnifiedVoiceActivation: true,
      threatEscalationThreshold: 0.7, // 70% уверенности для эскалации
      deviceTrustLevels: {}
    };

    this.initializeCoordination();
  }

  private initializeCoordination() {
    console.log('🔄 Initializing JARVIS Unified Coordination System...');

    // Интеграция событий Offline Mode
    this.setupOfflineModeIntegration();
    
    // Интеграция событий Device Discovery
    this.setupDeviceDiscoveryIntegration();
    
    // Унифицированные протоколы защиты
    this.setupUnifiedProtectionProtocols();
    
    this.isCoordinationActive = true;
    console.log('✅ JARVIS Unified Coordination System active');
  }

  private setupOfflineModeIntegration() {
    // Слушаем события угроз от offline режима
    jarvisOfflineMode.on('threatDetected', (threat) => {
      this.handleThreatFromOfflineMode(threat);
    });

    jarvisOfflineMode.on('emergencyProtocolActivated', (protocol) => {
      this.propagateEmergencyProtocolToDevices(protocol);
    });

    jarvisOfflineMode.on('voiceProtocolTriggered', (command) => {
      this.handleUnifiedVoiceProtocol(command);
    });
  }

  private setupDeviceDiscoveryIntegration() {
    // Слушаем события обнаружения устройств
    jarvisDeviceDiscovery.on('deviceConnected', (device: DeviceInfo) => {
      this.assessDeviceTrustLevel(device);
      this.syncThreatIntelligenceToDevice(device);
    });

    jarvisDeviceDiscovery.on('deviceConnectionFailed', (scanResult, error) => {
      this.handleSuspiciousDeviceActivity(scanResult, error);
    });

    jarvisDeviceDiscovery.on('devicePermissionsUpdated', (device: DeviceInfo) => {
      this.updateDeviceTrustScore(device);
    });
  }

  private setupUnifiedProtectionProtocols() {
    // Периодическая оценка общего состояния безопасности
    setInterval(() => {
      this.performUnifiedThreatAssessment();
    }, 30000); // Каждые 30 секунд

    // Автоматическая синхронизация состояний
    setInterval(() => {
      this.synchronizeSystemStates();
    }, 60000); // Каждую минуту
  }

  // Обработка угроз от offline режима
  private handleThreatFromOfflineMode(threat: any) {
    const unifiedThreat: UnifiedThreatDetection = {
      threatId: `offline_${Date.now()}`,
      threatType: threat.threatType || 'unknown_offline_threat',
      threatLevel: threat.threatLevel || 'MEDIUM',
      sourceDevice: 'server_offline_mode',
      affectedDevices: this.getAllConnectedDeviceIds(),
      detectionTime: Date.now(),
      protocolsActivated: [],
      requiresVoiceConfirmation: threat.requiresVoiceActivation || false
    };

    this.processUnifiedThreat(unifiedThreat);
  }

  // Обработка угроз от обнаруженных устройств
  private handleSuspiciousDeviceActivity(scanResult: any, error: any) {
    const suspicionLevel = this.calculateSuspicionLevel(scanResult, error);
    
    if (suspicionLevel > 0.6) { // 60% подозрительности
      const unifiedThreat: UnifiedThreatDetection = {
        threatId: `device_${Date.now()}`,
        threatType: 'suspicious_device_activity',
        threatLevel: suspicionLevel > 0.8 ? 'HIGH' : 'MEDIUM',
        sourceDevice: scanResult.deviceId || 'unknown_device',
        affectedDevices: [scanResult.deviceId],
        detectionTime: Date.now(),
        protocolsActivated: [],
        requiresVoiceConfirmation: suspicionLevel > 0.8
      };

      this.processUnifiedThreat(unifiedThreat);
    }
  }

  // Обработка унифицированных угроз
  private processUnifiedThreat(threat: UnifiedThreatDetection) {
    console.log(`⚠️ Unified threat detected: ${threat.threatType} (${threat.threatLevel})`);
    
    this.activeThreatScenarios.set(threat.threatId, threat);

    // Определение протоколов для активации
    const protocolsToActivate = this.determineProtocols(threat);
    threat.protocolsActivated = protocolsToActivate;

    // Активация протоколов на всех устройствах
    this.activateProtocolsOnDevices(threat, protocolsToActivate);

    // Уведомление offline режима
    jarvisOfflineMode.detectThreat(
      threat.threatType,
      threat.threatLevel,
      threat.requiresVoiceConfirmation
    );

    // Эмитим событие для других систем
    this.emit('unifiedThreatProcessed', threat);

    // Логирование для анализа
    this.logThreatForAnalysis(threat);
  }

  // Определение протоколов безопасности
  private determineProtocols(threat: UnifiedThreatDetection): string[] {
    const protocols: string[] = [];

    switch (threat.threatLevel) {
      case 'CRITICAL':
        protocols.push('EMERGENCY_PROTOCOL_LOCKDOWN');
        protocols.push('PROTOCOL_TANATOS_APPROACHING');
        protocols.push('VOICE_VERIFICATION_REQUIRED');
        break;
      
      case 'HIGH':
        protocols.push('ELEVATED_MONITORING');
        protocols.push('DEVICE_ISOLATION_STANDBY');
        if (threat.requiresVoiceConfirmation) {
          protocols.push('VOICE_PROTOCOL_ACTIVATION');
        }
        break;
      
      case 'MEDIUM':
        protocols.push('ENHANCED_MONITORING');
        protocols.push('TRUST_LEVEL_REDUCTION');
        break;
      
      case 'LOW':
        protocols.push('BASELINE_MONITORING');
        break;
    }

    // Добавляем специфичные протоколы по типу угрозы
    if (threat.threatType.includes('device')) {
      protocols.push('DEVICE_VERIFICATION_PROTOCOL');
    }

    if (threat.threatType.includes('network')) {
      protocols.push('NETWORK_ISOLATION_STANDBY');
    }

    return protocols;
  }

  // Активация протоколов на устройствах
  private activateProtocolsOnDevices(threat: UnifiedThreatDetection, protocols: string[]) {
    const connectedDevices = jarvisDeviceDiscovery.getDiscoveredDevices();
    
    connectedDevices.forEach(device => {
      if (threat.affectedDevices.includes(device.id) || threat.threatLevel === 'CRITICAL') {
        this.activateProtocolOnDevice(device, protocols, threat);
      }
    });
  }

  private activateProtocolOnDevice(device: DeviceInfo, protocols: string[], threat: UnifiedThreatDetection) {
    console.log(`🛡️ Activating protocols on ${device.name}: ${protocols.join(', ')}`);
    
    // Здесь будет отправка команд на устройство
    // В реальной реализации это будет WebSocket или HTTP запрос
    
    // Логирование активации протокола
    this.emit('protocolActivatedOnDevice', {
      deviceId: device.id,
      deviceName: device.name,
      protocols,
      threatId: threat.threatId,
      timestamp: Date.now()
    });
  }

  // Распространение emergency протоколов
  private propagateEmergencyProtocolToDevices(protocol: any) {
    const connectedDevices = jarvisDeviceDiscovery.getDiscoveredDevices();
    
    // Отправляем только на доверенные устройства
    const trustedDevices = connectedDevices.filter(device => 
      [PermissionLevel.ADVANCED, PermissionLevel.ADMIN, PermissionLevel.FULL].includes(device.permissionLevel as PermissionLevel)
    );

    trustedDevices.forEach(device => {
      console.log(`🚨 Emergency protocol "${protocol}" propagated to ${device.name}`);
      // Здесь будет реальная отправка команды на устройство
    });
  }

  // Обработка унифицированных голосовых протоколов
  private handleUnifiedVoiceProtocol(command: string) {
    console.log(`🎤 Unified voice protocol activated: "${command}"`);
    
    // Определяем уровень протокола
    let protocolLevel = 'STANDARD';
    if (command.includes('танос') || command.includes('seven seven')) {
      protocolLevel = 'EMERGENCY';
    }

    // Активируем на всех совместимых устройствах
    const compatibleDevices = jarvisDeviceDiscovery.getDiscoveredDevices()
      .filter(device => device.capabilities.includes('voice_recognition'));

    compatibleDevices.forEach(device => {
      this.sendVoiceProtocolToDevice(device, command, protocolLevel);
    });
  }

  private sendVoiceProtocolToDevice(device: DeviceInfo, command: string, level: string) {
    console.log(`🎙️ Voice protocol "${command}" (${level}) sent to ${device.name}`);
    // Реальная отправка команды на устройство
  }

  // Оценка уровня доверия устройства
  private assessDeviceTrustLevel(device: DeviceInfo) {
    let trustScore = 0.5; // Базовый уровень

    // Увеличиваем доверие для известных типов устройств
    if (['iphone', 'ipad', 'macbook', 'imac'].includes(device.type)) {
      trustScore += 0.2;
    }

    // Увеличиваем доверие для устройств с полными возможностями
    if (device.capabilities.includes('voice_recognition')) {
      trustScore += 0.1;
    }

    // Увеличиваем доверие для устройств с высокими разрешениями
    if ([PermissionLevel.ADMIN, PermissionLevel.FULL].includes(device.permissionLevel as PermissionLevel)) {
      trustScore += 0.2;
    }

    // Уменьшаем доверие для неизвестных устройств
    if (device.type === 'unknown') {
      trustScore -= 0.3;
    }

    // Нормализуем от 0 до 1
    trustScore = Math.max(0, Math.min(1, trustScore));
    
    this.deviceTrustScores.set(device.id, trustScore);
    
    console.log(`🔒 Device trust assessed: ${device.name} = ${(trustScore * 100).toFixed(0)}%`);
    
    return trustScore;
  }

  private updateDeviceTrustScore(device: DeviceInfo) {
    const currentScore = this.deviceTrustScores.get(device.id) || 0.5;
    const newScore = this.assessDeviceTrustLevel(device);
    
    if (Math.abs(newScore - currentScore) > 0.1) {
      console.log(`📊 Trust score updated for ${device.name}: ${(currentScore * 100).toFixed(0)}% → ${(newScore * 100).toFixed(0)}%`);
    }
  }

  // Вспомогательные методы
  private calculateSuspicionLevel(scanResult: any, error: any): number {
    let suspicion = 0;

    // Ошибки подключения увеличивают подозрения
    if (error) {
      suspicion += 0.3;
    }

    // Неизвестные устройства более подозрительны
    if (scanResult.deviceType === 'unknown') {
      suspicion += 0.2;
    }

    // Низкая уверенность в классификации
    if (scanResult.confidence < 0.5) {
      suspicion += 0.2;
    }

    // Необычные открытые порты
    if (scanResult.openPorts && scanResult.openPorts.length > 10) {
      suspicion += 0.1;
    }

    return Math.min(1, suspicion);
  }

  private getAllConnectedDeviceIds(): string[] {
    return jarvisDeviceDiscovery.getDiscoveredDevices()
      .filter(device => device.isOnline)
      .map(device => device.id);
  }

  private performUnifiedThreatAssessment() {
    // Анализ общего состояния безопасности
    const connectedDevices = jarvisDeviceDiscovery.getDiscoveredDevices();
    const offlineState = jarvisOfflineMode.getState();
    
    const overallThreatLevel = this.calculateOverallThreatLevel(connectedDevices, offlineState);
    
    if (overallThreatLevel > this.config.threatEscalationThreshold) {
      console.log(`⚠️ Elevated threat level detected: ${(overallThreatLevel * 100).toFixed(0)}%`);
      
      // Активируем превентивные меры
      this.activatePreventiveMeasures(overallThreatLevel);
    }
  }

  private calculateOverallThreatLevel(devices: DeviceInfo[], offlineState: any): number {
    let threatLevel = 0;

    // Оценка угроз от устройств
    const untrustedDevices = devices.filter(device => 
      (this.deviceTrustScores.get(device.id) || 0.5) < 0.4
    );
    
    threatLevel += (untrustedDevices.length / devices.length) * 0.3;

    // Оценка угроз из offline режима
    const queuedThreats = offlineState.queuedOperations?.filter((op: any) => 
      op.type === 'threat_detection'
    ).length || 0;
    
    threatLevel += Math.min(queuedThreats * 0.1, 0.4);

    // Активные сценарии угроз
    threatLevel += this.activeThreatScenarios.size * 0.1;

    return Math.min(1, threatLevel);
  }

  private activatePreventiveMeasures(threatLevel: number) {
    if (threatLevel > 0.8) {
      console.log('🚨 CRITICAL threat level - activating emergency protocols');
      jarvisOfflineMode.detectThreat('unified_critical_assessment', 'CRITICAL', true);
    } else if (threatLevel > 0.6) {
      console.log('⚠️ HIGH threat level - activating elevated monitoring');
      jarvisOfflineMode.detectThreat('unified_high_assessment', 'HIGH', false);
    }
  }

  private synchronizeSystemStates() {
    // Синхронизация состояний между системами
    const deviceCount = jarvisDeviceDiscovery.getDiscoveredDevices().length;
    const offlineCapabilities = jarvisOfflineMode.getState().offlineCapabilities;
    
    console.log(`🔄 System sync: ${deviceCount} devices, offline capabilities: ${Object.values(offlineCapabilities).filter(Boolean).length}/4`);
  }

  private syncThreatIntelligenceToDevice(device: DeviceInfo) {
    // Отправка актуальной информации об угрозах на новое устройство
    console.log(`📊 Syncing threat intelligence to ${device.name}`);
  }

  private logThreatForAnalysis(threat: UnifiedThreatDetection) {
    // Логирование для последующего анализа и машинного обучения
    console.log(`📝 Threat logged for analysis: ${threat.threatId}`);
  }

  // Публичные методы
  public getCoordinationStatus() {
    return {
      isActive: this.isCoordinationActive,
      activeThreatScenarios: this.activeThreatScenarios.size,
      connectedDevices: jarvisDeviceDiscovery.getDiscoveredDevices().length,
      averageTrustScore: this.calculateAverageTrustScore(),
      config: this.config
    };
  }

  private calculateAverageTrustScore(): number {
    const scores = Array.from(this.deviceTrustScores.values());
    return scores.length > 0 ? scores.reduce((a, b) => a + b, 0) / scores.length : 0;
  }

  public updateConfiguration(newConfig: Partial<CoordinationConfig>) {
    this.config = { ...this.config, ...newConfig };
    console.log('⚙️ Coordination configuration updated');
  }

  public getActiveThreatScenarios() {
    return Array.from(this.activeThreatScenarios.values());
  }

  public getDeviceTrustScores() {
    return Object.fromEntries(this.deviceTrustScores);
  }

  public clearThreatScenario(threatId: string) {
    const cleared = this.activeThreatScenarios.delete(threatId);
    if (cleared) {
      console.log(`✅ Threat scenario cleared: ${threatId}`);
    }
    return cleared;
  }

  public manualThreatDetection(threatType: string, threatLevel: 'LOW' | 'MEDIUM' | 'HIGH' | 'CRITICAL', deviceIds: string[] = []) {
    const manualThreat: UnifiedThreatDetection = {
      threatId: `manual_${Date.now()}`,
      threatType: `manual_${threatType}`,
      threatLevel,
      sourceDevice: 'manual_detection',
      affectedDevices: deviceIds.length > 0 ? deviceIds : this.getAllConnectedDeviceIds(),
      detectionTime: Date.now(),
      protocolsActivated: [],
      requiresVoiceConfirmation: threatLevel === 'CRITICAL'
    };

    this.processUnifiedThreat(manualThreat);
    return manualThreat.threatId;
  }
}

// Экспорт singleton instance
export const jarvisUnifiedCoordination = new JarvisUnifiedCoordination();
export { JarvisUnifiedCoordination };