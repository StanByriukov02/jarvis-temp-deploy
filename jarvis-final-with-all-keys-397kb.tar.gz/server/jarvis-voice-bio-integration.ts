/**
 * JARVIS Voice Bio-Singularity Integration
 * Интеграция системы клонирования голоса с биосингулярностью JARVIS
 */

import { db } from './db';
import { jarvisBioStates, jarvisVoiceConfigs } from '../shared/schema';
import { eq } from 'drizzle-orm';
import fs from 'fs/promises';
import path from 'path';
import { exec } from 'child_process';
import { promisify } from 'util';

const execAsync = promisify(exec);

export class JarvisVoiceBioIntegration {
  private workDir: string;
  private elevenLabsApiKey?: string;

  constructor() {
    this.workDir = path.join(process.cwd(), 'jarvis-processing');
    this.elevenLabsApiKey = process.env.ELEVENLABS_API_KEY;
  }

  /**
   * Автоматическое извлечение голоса из загруженного видео
   */
  async processUploadedVideo(videoBuffer: Buffer, fileName: string, userId: string) {
    console.log(`🎬 Начинаю обработку видео ${fileName} для пользователя ${userId}`);
    
    try {
      // Создаём временный файл
      const tempVideoPath = path.join(this.workDir, 'temp', `${Date.now()}_${fileName}`);
      await fs.mkdir(path.dirname(tempVideoPath), { recursive: true });
      await fs.writeFile(tempVideoPath, videoBuffer);

      // Извлекаем аудио с улучшением для голоса JARVIS
      const audioPath = await this.extractEnhancedAudio(tempVideoPath);
      
      // Создаём голосовые сегменты
      const segments = await this.createVoiceSegments(audioPath, userId);
      
      // Анализируем качество голоса
      const analysis = await this.analyzeVoiceQuality(segments);
      
      // Создаём конфигурацию для клонирования
      const config = await this.createCloneConfiguration(analysis, segments, userId);
      
      // Сохраняем в базу данных
      await this.saveVoiceConfig(userId, config);
      
      // Очищаем временные файлы
      await fs.unlink(tempVideoPath);
      
      console.log(`✅ Видео обработано для пользователя ${userId}: ${segments.length} сегментов`);
      
      return {
        success: true,
        segmentsCount: segments.length,
        quality: analysis.qualityScore,
        readyForCloning: analysis.readyForCloning,
        config
      };
      
    } catch (error) {
      console.error(`❌ Ошибка обработки видео для ${userId}:`, error);
      throw error;
    }
  }

  /**
   * Извлечение и улучшение аудио для голоса JARVIS
   */
  private async extractEnhancedAudio(videoPath: string): Promise<string> {
    const outputPath = path.join(this.workDir, 'processed', `jarvis_${Date.now()}.wav`);
    await fs.mkdir(path.dirname(outputPath), { recursive: true });
    
    // Команда FFmpeg для извлечения и улучшения голоса JARVIS
    const command = `ffmpeg -i "${videoPath}" ` +
      `-vn -acodec pcm_s16le -ar 44100 -ac 1 ` +
      `-af "highpass=f=80,lowpass=f=8000,` +
      `compand=.3,.8:-90/-90|-60/-20|-40/-12|-20/-8:6:0:.6:0:-90:0.2,` +
      `equalizer=f=1000:width_type=h:width=200:g=4,` +
      `equalizer=f=3000:width_type=h:width=500:g=3,` +
      `volume=1.2" ` +
      `"${outputPath}" -y`;
    
    await execAsync(command);
    return outputPath;
  }

  /**
   * Создание голосовых сегментов для клонирования
   */
  private async createVoiceSegments(audioPath: string, userId: string): Promise<string[]> {
    const segmentsDir = path.join(this.workDir, 'voice-samples', userId);
    await fs.mkdir(segmentsDir, { recursive: true });
    
    // Разделяем аудио на сегменты по тишине
    const segmentCommand = `ffmpeg -i "${audioPath}" ` +
      `-f segment -segment_time 8 -segment_format wav ` +
      `"${path.join(segmentsDir, 'jarvis_%03d.wav')}" -y`;
    
    await execAsync(segmentCommand);
    
    // Возвращаем список созданных сегментов
    const files = await fs.readdir(segmentsDir);
    return files
      .filter(f => f.startsWith('jarvis_') && f.endsWith('.wav'))
      .map(f => path.join(segmentsDir, f))
      .sort();
  }

  /**
   * Анализ качества голосовых сегментов
   */
  private async analyzeVoiceQuality(segments: string[]) {
    let totalDuration = 0;
    let goodSegments = 0;
    
    for (const segment of segments) {
      try {
        const infoCommand = `ffprobe -v quiet -show_entries format=duration -of csv=p=0 "${segment}"`;
        const { stdout } = await execAsync(infoCommand);
        const duration = parseFloat(stdout.trim());
        
        // Считаем сегмент хорошим, если он длится от 3 до 15 секунд
        if (duration >= 3 && duration <= 15) {
          goodSegments++;
        }
        totalDuration += duration;
      } catch (error) {
        console.warn(`⚠️ Ошибка анализа сегмента: ${segment}`);
      }
    }
    
    const qualityScore = Math.round((goodSegments / segments.length) * 100);
    const readyForCloning = qualityScore >= 60 && goodSegments >= 5;
    
    return {
      totalSegments: segments.length,
      goodSegments,
      totalDuration: Math.round(totalDuration),
      qualityScore,
      readyForCloning
    };
  }

  /**
   * Создание конфигурации для клонирования голоса
   */
  private async createCloneConfiguration(analysis: any, segments: string[], userId: string) {
    return {
      userId,
      voiceName: `JARVIS_${userId}`,
      description: 'Персональный клон голоса JARVIS из русского дубляжа Marvel',
      segments: segments.slice(0, 25), // Максимум 25 образцов для ElevenLabs
      analysis,
      characteristics: {
        language: 'Russian',
        voiceActor: 'Всеволод Кузнецов',
        tone: 'Интеллектуальный, спокойный',
        timbre: 'Тёплый синтетический с цифровой обработкой',
        emotionalRange: 'Контролируемая эмпатия до холодной логики'
      },
      elevenLabsSettings: {
        stability: 0.75,
        similarityBoost: 0.85,
        style: 0.65,
        useSpeakerBoost: true
      },
      bioSingularityIntegration: {
        autoLanguageDetection: true,
        emotionalModulation: true,
        realTimeAdaptation: true
      },
      createdAt: new Date().toISOString(),
      status: analysis.readyForCloning ? 'ready_for_cloning' : 'needs_more_samples'
    };
  }

  /**
   * Сохранение конфигурации голоса в базу данных
   */
  private async saveVoiceConfig(userId: string, config: any) {
    try {
      // Проверяем, есть ли уже конфигурация для этого пользователя
      const existingConfig = await db
        .select()
        .from(jarvisVoiceConfigs)
        .where(eq(jarvisVoiceConfigs.userId, userId))
        .limit(1);

      if (existingConfig.length > 0) {
        // Обновляем существующую конфигурацию
        await db
          .update(jarvisVoiceConfigs)
          .set({
            config: JSON.stringify(config),
            updatedAt: new Date()
          })
          .where(eq(jarvisVoiceConfigs.userId, userId));
      } else {
        // Создаём новую конфигурацию
        await db
          .insert(jarvisVoiceConfigs)
          .values({
            userId,
            voiceName: config.voiceName,
            language: 'ru',
            config: JSON.stringify(config),
            status: config.status,
            createdAt: new Date()
          });
      }
      
      console.log(`💾 Конфигурация голоса сохранена для пользователя ${userId}`);
    } catch (error) {
      console.error('❌ Ошибка сохранения конфигурации голоса:', error);
      throw error;
    }
  }

  /**
   * Автоматическое создание клона в ElevenLabs
   */
  async createElevenLabsClone(userId: string): Promise<string | null> {
    if (!this.elevenLabsApiKey) {
      console.warn('⚠️ ElevenLabs API ключ не настроен');
      return null;
    }

    try {
      // Получаем конфигурацию пользователя
      const configData = await db
        .select()
        .from(jarvisVoiceConfigs)
        .where(eq(jarvisVoiceConfigs.userId, userId))
        .limit(1);

      if (configData.length === 0) {
        throw new Error('Конфигурация голоса не найдена');
      }

      const config = JSON.parse(configData[0].config);
      
      if (!config.analysis.readyForCloning) {
        throw new Error('Голос не готов к клонированию - недостаточно качественных образцов');
      }

      // TODO: Здесь будет интеграция с ElevenLabs API
      // Пока возвращаем mock voice ID
      const mockVoiceId = `jarvis_${userId}_${Date.now()}`;
      
      // Обновляем конфигурацию с voice ID
      config.elevenLabsVoiceId = mockVoiceId;
      config.status = 'cloned';
      
      await db
        .update(jarvisVoiceConfigs)
        .set({
          voiceId: mockVoiceId,
          config: JSON.stringify(config),
          status: 'cloned',
          updatedAt: new Date()
        })
        .where(eq(jarvisVoiceConfigs.userId, userId));

      console.log(`✅ Голос JARVIS клонирован для пользователя ${userId}: ${mockVoiceId}`);
      return mockVoiceId;
      
    } catch (error) {
      console.error(`❌ Ошибка создания клона для ${userId}:`, error);
      throw error;
    }
  }

  /**
   * Интеграция клонированного голоса с биосингулярностью
   */
  async integrateBioSingularity(userId: string, voiceId: string) {
    try {
      // Получаем состояние биосингулярности пользователя
      const bioStates = await db
        .select()
        .from(jarvisBioStates)
        .where(eq(jarvisBioStates.userId, userId))
        .limit(1);

      if (bioStates.length === 0) {
        console.log(`ℹ️ Состояние биосингулярности не найдено для ${userId}, создаём новое`);
        return;
      }

      const bioState = JSON.parse(JSON.stringify(bioStates[0].organismState));
      
      // Добавляем голосовые способности в биосингулярность
      if (!bioState.voiceCapabilities) {
        bioState.voiceCapabilities = {};
      }
      
      bioState.voiceCapabilities.russianJarvis = {
        voiceId,
        language: 'ru',
        characteristics: {
          warmth: 0.7,
          intelligence: 0.95,
          authority: 0.8,
          empathy: 0.6,
          digitalProcessing: 0.9
        },
        emotionalModulation: {
          calm: { stability: 0.8, similarity: 0.9, style: 0.4 },
          analytical: { stability: 0.9, similarity: 0.8, style: 0.7 },
          empathetic: { stability: 0.6, similarity: 0.9, style: 0.8 },
          authoritative: { stability: 0.9, similarity: 0.7, style: 0.9 }
        },
        active: true,
        integrationDate: new Date().toISOString()
      };
      
      // Сохраняем обновлённое состояние
      await db
        .update(jarvisBioStates)
        .set({
          organismState: bioState,
          updatedAt: new Date()
        })
        .where(eq(jarvisBioStates.userId, userId));

      console.log(`🧬 Голос JARVIS интегрирован с биосингулярностью пользователя ${userId}`);
      
    } catch (error) {
      console.error(`❌ Ошибка интеграции с биосингулярностью для ${userId}:`, error);
      throw error;
    }
  }

  /**
   * Получение статуса голосовой системы для пользователя
   */
  async getVoiceStatus(userId: string) {
    try {
      const configData = await db
        .select()
        .from(jarvisVoiceConfigs)
        .where(eq(jarvisVoiceConfigs.userId, userId))
        .limit(1);

      if (configData.length === 0) {
        return {
          hasVoice: false,
          status: 'not_configured',
          message: 'Голос JARVIS не настроен'
        };
      }

      const config = JSON.parse(configData[0].config);
      
      return {
        hasVoice: true,
        status: configData[0].status,
        voiceId: configData[0].voiceId,
        quality: config.analysis?.qualityScore || 0,
        segmentsCount: config.analysis?.totalSegments || 0,
        readyForCloning: config.analysis?.readyForCloning || false,
        createdAt: configData[0].createdAt
      };
      
    } catch (error) {
      console.error(`❌ Ошибка получения статуса голоса для ${userId}:`, error);
      throw error;
    }
  }
}

export const jarvisVoiceIntegration = new JarvisVoiceBioIntegration();