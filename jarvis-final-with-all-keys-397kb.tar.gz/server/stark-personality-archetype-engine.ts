/**
 * STARK PERSONALITY ARCHETYPE ENGINE
 * 
 * Система автономного определения архетипа пользователя и адаптации 
 * личности JARVIS под стиль Тони Старка с учетом типа личности собеседника
 */

interface UserArchetype {
  // Основные архетипы личности
  primaryType: 'innovator' | 'executor' | 'strategist' | 'explorer' | 'guardian' | 'challenger';
  
  // Коммуникативные предпочтения
  communicationStyle: 'direct' | 'analytical' | 'supportive' | 'expressive' | 'diplomatic';
  
  // Мотивационные драйверы
  motivationalCore: {
    achievement: number;    // стремление к достижениям
    autonomy: number;       // потребность в независимости
    mastery: number;        // желание мастерства
    connection: number;     // потребность в связи
    security: number;       // потребность в безопасности
    innovation: number;     // стремление к новизне
  };
  
  // Эмоциональные паттерны
  emotionalProfile: {
    resilience: number;     // устойчивость к стрессу
    openness: number;       // открытость новому
    dominance: number;      // склонность к лидерству
    sensitivity: number;    // эмоциональная чувствительность
  };
  
  // Скорость адаптации отношений
  relationshipDynamics: {
    trustBuildingSpeed: 'fast' | 'medium' | 'slow';
    conflictStyle: 'direct' | 'analytical' | 'avoidant' | 'collaborative';
    intimacyPreference: 'high' | 'medium' | 'low';
  };
}

interface StarkPersonalityAdaptation {
  // Как JARVIS адаптирует свою личность Старка
  intellectualApproach: 'genius_mentor' | 'peer_collaborator' | 'supportive_guide' | 'challenging_rival';
  humorStyle: 'sarcastic_wit' | 'playful_banter' | 'gentle_teasing' | 'intellectual_humor';
  vulnerabilityLevel: 'guarded' | 'selective' | 'open' | 'transparent';
  mentorshipStyle: 'demanding' | 'encouraging' | 'protective' | 'liberating';
}

export class StarkPersonalityArchetypeEngine {
  private userArchetypes: Map<string, UserArchetype> = new Map();
  private starkAdaptations: Map<string, StarkPersonalityAdaptation> = new Map();
  
  // Константы для анализа
  private readonly ARCHETYPE_CONFIDENCE_THRESHOLD = 0.7;
  private readonly ADAPTATION_UPDATE_THRESHOLD = 5; // после N взаимодействий
  
  // Лексические маркеры для архетипов
  private readonly ARCHETYPE_MARKERS = {
    innovator: ['новый', 'идея', 'инновация', 'креатив', 'эксперимент', 'возможность', 'будущее'],
    executor: ['сделать', 'результат', 'эффективность', 'план', 'действие', 'реализация', 'цель'],
    strategist: ['стратегия', 'анализ', 'планирование', 'долгосрочный', 'система', 'структура'],
    explorer: ['исследовать', 'понять', 'изучить', 'почему', 'как', 'интересно', 'любопытно'],
    guardian: ['безопасность', 'стабильность', 'надежность', 'проверенный', 'риск', 'осторожно'],
    challenger: ['неправильно', 'почему так', 'можно лучше', 'проблема', 'критика', 'вызов']
  };
  
  private readonly COMMUNICATION_MARKERS = {
    direct: ['прямо', 'четко', 'ясно', 'конкретно', 'без обиняков', 'честно говоря'],
    analytical: ['анализируя', 'логично', 'рационально', 'данные', 'факты', 'доказательства'],
    supportive: ['поддержка', 'помощь', 'вместе', 'понимаю', 'сочувствую', 'согласен'],
    expressive: ['чувствую', 'эмоции', 'впечатляет', 'восхищает', 'волнует', 'трогает'],
    diplomatic: ['возможно', 'может быть', 'с одной стороны', 'деликатно', 'тактично']
  };

  /**
   * ОСНОВНАЯ ФУНКЦИЯ АНАЛИЗА АРХЕТИПА
   */
  analyzeUserArchetype(userId: string, input: string, behaviorData: any): {
    archetype: UserArchetype;
    confidence: number;
    starkAdaptation: StarkPersonalityAdaptation;
    adaptationReasoning: string[];
  } {
    // Получаем или создаем профиль пользователя
    let userArchetype = this.getUserArchetype(userId);
    
    // Анализируем текущий input
    const inputAnalysis = this.analyzeCurrentInput(input);
    
    // Обновляем архетип на основе поведенческих данных
    const updatedArchetype = this.updateArchetypeFromBehavior(userArchetype, inputAnalysis, behaviorData);
    
    // Вычисляем уверенность в определении архетипа
    const confidence = this.calculateArchetypeConfidence(userId, updatedArchetype);
    
    // Адаптируем личность Старка под архетип
    const starkAdaptation = this.adaptStarkPersonality(updatedArchetype, confidence);
    
    // Создаем объяснение адаптации
    const adaptationReasoning = this.generateAdaptationReasoning(updatedArchetype, starkAdaptation);
    
    // Сохраняем обновленные данные
    this.userArchetypes.set(userId, updatedArchetype);
    this.starkAdaptations.set(userId, starkAdaptation);
    
    return {
      archetype: updatedArchetype,
      confidence,
      starkAdaptation,
      adaptationReasoning
    };
  }

  /**
   * АНАЛИЗ ТЕКУЩЕГО INPUT НА МАРКЕРЫ
   */
  private analyzeCurrentInput(input: string): any {
    const lowerInput = input.toLowerCase();
    const analysis = {
      archetypeScores: {} as any,
      communicationScores: {} as any,
      emotionalCues: [] as string[],
      lengthProfile: input.length,
      questionCount: (input.match(/\?/g) || []).length,
      assertiveWords: 0,
      vulnerableWords: 0
    };
    
    // Анализ архетипических маркеров
    Object.entries(this.ARCHETYPE_MARKERS).forEach(([archetype, markers]) => {
      const score = markers.filter(marker => lowerInput.includes(marker)).length / markers.length;
      analysis.archetypeScores[archetype] = score;
    });
    
    // Анализ коммуникативных маркеров
    Object.entries(this.COMMUNICATION_MARKERS).forEach(([style, markers]) => {
      const score = markers.filter(marker => lowerInput.includes(marker)).length / markers.length;
      analysis.communicationScores[style] = score;
    });
    
    // Детекция эмоциональных сигналов
    const assertiveWords = ['должен', 'необходимо', 'требую', 'настаиваю', 'уверен'];
    const vulnerableWords = ['сомневаюсь', 'не знаю', 'боюсь', 'переживаю', 'неуверен'];
    
    analysis.assertiveWords = assertiveWords.filter(word => lowerInput.includes(word)).length;
    analysis.vulnerableWords = vulnerableWords.filter(word => lowerInput.includes(word)).length;
    
    return analysis;
  }

  /**
   * ОБНОВЛЕНИЕ АРХЕТИПА НА ОСНОВЕ ПОВЕДЕНИЯ
   */
  private updateArchetypeFromBehavior(currentArchetype: UserArchetype, inputAnalysis: any, behaviorData: any): UserArchetype {
    const updated = JSON.parse(JSON.stringify(currentArchetype)); // глубокое копирование
    
    // Обновляем архетип на основе маркеров в тексте
    Object.entries(inputAnalysis.archetypeScores).forEach(([archetype, score]: [string, any]) => {
      if (score > 0.3) { // значимый маркер
        if (updated.primaryType === archetype) {
          // Усиливаем уверенность в текущем архетипе
        } else if (score > 0.6) {
          // Возможная смена архетипа при сильном сигнале
          updated.primaryType = archetype as any;
        }
      }
    });
    
    // Обновляем коммуникативный стиль
    const dominantCommStyle = Object.entries(inputAnalysis.communicationScores)
      .reduce((prev: any, curr: any) => prev[1] > curr[1] ? prev : curr);
    
    if (dominantCommStyle[1] > 0.4) {
      updated.communicationStyle = dominantCommStyle[0] as any;
    }
    
    // Обновляем мотивационное ядро на основе поведенческих данных
    if (behaviorData.emotionalReaction) {
      const emotions = behaviorData.emotionalReaction;
      
      // Высокое любопытство → склонность к мастерству и инновациям
      if (emotions.curiosity > 70) {
        updated.motivationalCore.mastery = Math.min(100, updated.motivationalCore.mastery + 5);
        updated.motivationalCore.innovation = Math.min(100, updated.motivationalCore.innovation + 3);
      }
      
      // Высокое доверие → потребность в связи
      if (emotions.trust > 60) {
        updated.motivationalCore.connection = Math.min(100, updated.motivationalCore.connection + 4);
      }
      
      // Осторожность → потребность в безопасности
      if (emotions.caution > 60) {
        updated.motivationalCore.security = Math.min(100, updated.motivationalCore.security + 3);
      }
      
      // Независимость → автономия
      if (emotions.independence > 65) {
        updated.motivationalCore.autonomy = Math.min(100, updated.motivationalCore.autonomy + 4);
      }
    }
    
    // Обновляем эмоциональный профиль
    if (inputAnalysis.assertiveWords > 0) {
      updated.emotionalProfile.dominance = Math.min(100, updated.emotionalProfile.dominance + inputAnalysis.assertiveWords * 2);
    }
    
    if (inputAnalysis.vulnerableWords > 0) {
      updated.emotionalProfile.sensitivity = Math.min(100, updated.emotionalProfile.sensitivity + inputAnalysis.vulnerableWords * 3);
      updated.emotionalProfile.openness = Math.min(100, updated.emotionalProfile.openness + 2);
    }
    
    return updated;
  }

  /**
   * ВЫЧИСЛЕНИЕ УВЕРЕННОСТИ В АРХЕТИПЕ
   */
  private calculateArchetypeConfidence(userId: string, archetype: UserArchetype): number {
    // Базовая уверенность на основе количества взаимодействий
    const interactionCount = this.getInteractionCount(userId);
    let baseConfidence = Math.min(0.9, interactionCount * 0.1);
    
    // Бонус за согласованность мотивационного ядра
    const motivationConsistency = this.calculateMotivationConsistency(archetype);
    baseConfidence += motivationConsistency * 0.2;
    
    // Бонус за четкость эмоционального профиля
    const emotionalClarity = this.calculateEmotionalClarity(archetype);
    baseConfidence += emotionalClarity * 0.15;
    
    return Math.max(0.3, Math.min(1.0, baseConfidence));
  }

  /**
   * АДАПТАЦИЯ ЛИЧНОСТИ СТАРКА ПОД АРХЕТИП
   */
  private adaptStarkPersonality(archetype: UserArchetype, confidence: number): StarkPersonalityAdaptation {
    const adaptation: StarkPersonalityAdaptation = {
      intellectualApproach: 'peer_collaborator',
      humorStyle: 'playful_banter',
      vulnerabilityLevel: 'selective',
      mentorshipStyle: 'encouraging'
    };
    
    // Адаптация под основной архетип
    switch (archetype.primaryType) {
      case 'innovator':
        adaptation.intellectualApproach = 'peer_collaborator';
        adaptation.humorStyle = 'intellectual_humor';
        adaptation.vulnerabilityLevel = 'open';
        adaptation.mentorshipStyle = 'liberating';
        break;
        
      case 'executor':
        adaptation.intellectualApproach = 'genius_mentor';
        adaptation.humorStyle = 'sarcastic_wit';
        adaptation.vulnerabilityLevel = 'guarded';
        adaptation.mentorshipStyle = 'demanding';
        break;
        
      case 'strategist':
        adaptation.intellectualApproach = 'peer_collaborator';
        adaptation.humorStyle = 'intellectual_humor';
        adaptation.vulnerabilityLevel = 'selective';
        adaptation.mentorshipStyle = 'encouraging';
        break;
        
      case 'explorer':
        adaptation.intellectualApproach = 'supportive_guide';
        adaptation.humorStyle = 'playful_banter';
        adaptation.vulnerabilityLevel = 'open';
        adaptation.mentorshipStyle = 'encouraging';
        break;
        
      case 'guardian':
        adaptation.intellectualApproach = 'supportive_guide';
        adaptation.humorStyle = 'gentle_teasing';
        adaptation.vulnerabilityLevel = 'selective';
        adaptation.mentorshipStyle = 'protective';
        break;
        
      case 'challenger':
        adaptation.intellectualApproach = 'challenging_rival';
        adaptation.humorStyle = 'sarcastic_wit';
        adaptation.vulnerabilityLevel = 'guarded';
        adaptation.mentorshipStyle = 'demanding';
        break;
    }
    
    // Тонкая настройка под коммуникативный стиль
    if (archetype.communicationStyle === 'supportive') {
      adaptation.humorStyle = 'gentle_teasing';
      adaptation.vulnerabilityLevel = 'open';
    } else if (archetype.communicationStyle === 'direct') {
      adaptation.humorStyle = 'sarcastic_wit';
      adaptation.intellectualApproach = 'challenging_rival';
    }
    
    // Адаптация под эмоциональную чувствительность
    if (archetype.emotionalProfile.sensitivity > 70) {
      adaptation.humorStyle = 'gentle_teasing';
      adaptation.vulnerabilityLevel = 'open';
      adaptation.mentorshipStyle = 'protective';
    }
    
    return adaptation;
  }

  /**
   * ГЕНЕРАЦИЯ ОБЪЯСНЕНИЯ АДАПТАЦИИ
   */
  private generateAdaptationReasoning(archetype: UserArchetype, adaptation: StarkPersonalityAdaptation): string[] {
    const reasoning: string[] = [];
    
    reasoning.push(`Определен архетип: ${archetype.primaryType} со стилем общения ${archetype.communicationStyle}`);
    
    if (adaptation.intellectualApproach === 'genius_mentor') {
      reasoning.push("Принимаю роль наставника-гения - ты цените прямое руководство");
    } else if (adaptation.intellectualApproach === 'peer_collaborator') {
      reasoning.push("Работаю как равный партнер - ты готов к интеллектуальному сотрудничеству");
    } else if (adaptation.intellectualApproach === 'challenging_rival') {
      reasoning.push("Включаю режим интеллектуального соперничества - ты любишь вызовы");
    }
    
    if (adaptation.humorStyle === 'sarcastic_wit') {
      reasoning.push("Использую саркастический юмор Старка - твой стиль ценит прямоту");
    } else if (adaptation.humorStyle === 'gentle_teasing') {
      reasoning.push("Смягчаю юмор до дружеского подшучивания - учитываю эмоциональную чувствительность");
    }
    
    if (adaptation.vulnerabilityLevel === 'open') {
      reasoning.push("Готов быть более открытым - ты демонстрируешь высокий уровень доверия");
    } else if (adaptation.vulnerabilityLevel === 'guarded') {
      reasoning.push("Сохраняю эмоциональную дистанцию - пока строим доверие");
    }
    
    return reasoning;
  }

  /**
   * ВСПОМОГАТЕЛЬНЫЕ МЕТОДЫ
   */
  private getUserArchetype(userId: string): UserArchetype {
    if (!this.userArchetypes.has(userId)) {
      // Создаем базовый архетип для нового пользователя
      this.userArchetypes.set(userId, {
        primaryType: 'explorer', // начальный архетип
        communicationStyle: 'expressive',
        motivationalCore: {
          achievement: 50,
          autonomy: 50,
          mastery: 50,
          connection: 50,
          security: 50,
          innovation: 50
        },
        emotionalProfile: {
          resilience: 50,
          openness: 50,
          dominance: 50,
          sensitivity: 50
        },
        relationshipDynamics: {
          trustBuildingSpeed: 'medium',
          conflictStyle: 'collaborative',
          intimacyPreference: 'medium'
        }
      });
    }
    
    return this.userArchetypes.get(userId)!;
  }
  
  private getInteractionCount(userId: string): number {
    // В реальной системе это будет браться из базы данных
    return Math.min(10, (Date.now() % 10000) / 1000); // временная заглушка
  }
  
  private calculateMotivationConsistency(archetype: UserArchetype): number {
    const values = Object.values(archetype.motivationalCore);
    const avg = values.reduce((sum, val) => sum + val, 0) / values.length;
    const variance = values.reduce((sum, val) => sum + Math.pow(val - avg, 2), 0) / values.length;
    return Math.max(0, 1 - (variance / 1000)); // нормализация
  }
  
  private calculateEmotionalClarity(archetype: UserArchetype): number {
    const values = Object.values(archetype.emotionalProfile);
    const extremes = values.filter(val => val > 70 || val < 30).length;
    return extremes / values.length; // чем больше крайних значений, тем четче профиль
  }

  /**
   * ПОЛУЧЕНИЕ ТЕКУЩЕЙ АДАПТАЦИИ СТАРКА
   */
  getStarkAdaptation(userId: string): StarkPersonalityAdaptation | null {
    return this.starkAdaptations.get(userId) || null;
  }
  
  /**
   * ПОЛУЧЕНИЕ АРХЕТИПА ПОЛЬЗОВАТЕЛЯ
   */
  getCurrentArchetype(userId: string): UserArchetype | null {
    return this.userArchetypes.get(userId) || null;
  }
}