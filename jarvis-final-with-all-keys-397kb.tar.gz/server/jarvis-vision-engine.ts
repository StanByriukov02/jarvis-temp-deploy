import OpenAI from "openai";
import screenshot from "screenshot-desktop";
import sharp from "sharp";
import { exec } from "child_process";
import { promisify } from "util";
import fs from "fs/promises";
import path from "path";

const execAsync = promisify(exec);

// the newest OpenAI model is "gpt-4o" which was released May 13, 2024. do not change this unless explicitly requested by the user
const openai = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });

export interface VisualAnalysisResult {
  screenContent: {
    mainElements: string[];
    activeApplication: string;
    gameState?: GameState;
    interfaceType: 'desktop' | 'game' | 'browser' | 'application';
    textContent: string[];
    clickableElements: ClickableElement[];
  };
  contextualUnderstanding: {
    userActivity: string;
    currentTask: string;
    emotionalState: string;
    urgencyLevel: 'low' | 'medium' | 'high' | 'critical';
    recommendations: string[];
  };
  systemState: {
    runningProcesses: string[];
    activeWindows: WindowInfo[];
    resourceUsage: ResourceInfo;
    networkActivity: string[];
  };
  opportunities: {
    automationPossibilities: AutomationOpportunity[];
    proactiveActions: ProactiveAction[];
    optimizations: string[];
  };
}

export interface GameState {
  gameName: string;
  gameMode: string;
  playerStatus: {
    health?: number;
    level?: number;
    resources?: Record<string, number>;
    location?: string;
  };
  availableActions: string[];
  gameUI: {
    inventoryOpen: boolean;
    menuOpen: boolean;
    chatVisible: boolean;
    minimapVisible: boolean;
  };
}

export interface ClickableElement {
  type: 'button' | 'link' | 'input' | 'menu' | 'icon';
  text: string;
  position: { x: number; y: number; width: number; height: number };
  action: string;
  confidence: number;
}

export interface WindowInfo {
  title: string;
  processName: string;
  isActive: boolean;
  position: { x: number; y: number; width: number; height: number };
}

export interface ResourceInfo {
  cpuUsage: number;
  memoryUsage: number;
  diskUsage: number;
  networkUsage: number;
}

export interface AutomationOpportunity {
  action: string;
  description: string;
  confidence: number;
  estimatedTimeSaving: number;
  requiredPermissions: string[];
}

export interface ProactiveAction {
  type: 'suggestion' | 'reminder' | 'optimization' | 'warning';
  message: string;
  priority: 'low' | 'medium' | 'high';
  timing: 'immediate' | 'delayed' | 'scheduled';
  context: string;
}

export class JarvisVisionEngine {
  private screenshotCache: Map<string, Buffer> = new Map();
  private analysisCache: Map<string, VisualAnalysisResult> = new Map();
  private cacheTimeout = 5000; // 5 seconds
  private isAnalyzing = false;

  constructor() {
    console.log('🔍 JARVIS Vision Engine initialized');
  }

  /**
   * Главный метод анализа экрана
   */
  async analyzeScreen(options: {
    includeSystemState?: boolean;
    includeGameAnalysis?: boolean;
    includeAutomationOpportunities?: boolean;
    captureAllDisplays?: boolean;
    focusArea?: { x: number; y: number; width: number; height: number };
  } = {}): Promise<VisualAnalysisResult> {
    if (this.isAnalyzing) {
      console.log('⏳ Analysis already in progress, waiting...');
      await this.waitForAnalysis();
    }

    this.isAnalyzing = true;

    try {
      console.log('📸 Capturing screen...');
      const screenshots = await this.captureScreen(options.captureAllDisplays);
      
      console.log('🧠 Analyzing visual content...');
      const visualAnalysis = await this.analyzeVisualContent(screenshots, options);
      
      if (options.includeSystemState) {
        console.log('⚙️ Gathering system state...');
        visualAnalysis.systemState = await this.gatherSystemState();
      }

      if (options.includeAutomationOpportunities) {
        console.log('🚀 Identifying automation opportunities...');
        visualAnalysis.opportunities = await this.identifyOpportunities(visualAnalysis);
      }

      this.cacheAnalysis(visualAnalysis);
      
      console.log('✅ Vision analysis complete');
      return visualAnalysis;

    } catch (error: any) {
      console.error('❌ Vision analysis failed:', error);
      throw new Error(`Vision analysis failed: ${error.message}`);
    } finally {
      this.isAnalyzing = false;
    }
  }

  /**
   * Захват скриншотов экрана
   */
  private async captureScreen(captureAll: boolean = false): Promise<Buffer[]> {
    try {
      if (captureAll) {
        // Захват всех дисплеев
        const displays = await screenshot.listDisplays();
        const screenshots: Buffer[] = [];
        
        for (const display of displays) {
          const img = await screenshot({ screen: display.id });
          screenshots.push(img);
        }
        
        return screenshots;
      } else {
        // Захват основного дисплея
        const img = await screenshot();
        return [img];
      }
    } catch (error: any) {
      throw new Error(`Screenshot capture failed: ${error.message}`);
    }
  }

  /**
   * Анализ визуального контента через OpenAI Vision
   */
  private async analyzeVisualContent(
    screenshots: Buffer[], 
    options: any
  ): Promise<VisualAnalysisResult> {
    try {
      // Конвертируем скриншоты в base64
      const base64Images = await Promise.all(
        screenshots.map(async (buffer) => {
          // Оптимизируем изображение для анализа
          const optimized = await sharp(buffer)
            .resize(1920, 1080, { fit: 'inside', withoutEnlargement: true })
            .jpeg({ quality: 85 })
            .toBuffer();
          
          return optimized.toString('base64');
        })
      );

      // Создаем промпт для анализа
      const analysisPrompt = this.createAnalysisPrompt(options);

      // Отправляем на анализ в OpenAI Vision
      const response = await openai.chat.completions.create({
        model: "gpt-4o", // the newest OpenAI model is "gpt-4o" which was released May 13, 2024. do not change this unless explicitly requested by the user
        messages: [
          {
            role: "system",
            content: "You are JARVIS, Tony Stark's AI assistant. Analyze the screen with the intelligence and insight of an advanced AI system. Provide detailed, actionable analysis in JSON format."
          },
          {
            role: "user",
            content: [
              {
                type: "text",
                text: analysisPrompt
              },
              ...base64Images.map((image: string) => ({
                type: "image_url" as const,
                image_url: {
                  url: `data:image/jpeg;base64,${image}`
                }
              }))
            ]
          }
        ],
        response_format: { type: "json_object" },
        max_tokens: 4000
      });

      const analysisResult = JSON.parse(response.choices[0].message.content || "{}");
      
      return this.validateAndStructureAnalysis(analysisResult);

    } catch (error: any) {
      throw new Error(`Visual content analysis failed: ${error.message}`);
    }
  }

  /**
   * Создание промпта для анализа
   */
  private createAnalysisPrompt(options: any): string {
    return `
Analyze this screen as JARVIS would for Tony Stark. Provide comprehensive analysis in JSON format with these sections:

{
  "screenContent": {
    "mainElements": ["list of main UI elements visible"],
    "activeApplication": "name of the active application",
    "gameState": null or {
      "gameName": "detected game name",
      "gameMode": "current game mode",
      "playerStatus": {
        "health": number or null,
        "level": number or null,
        "resources": {},
        "location": "current location"
      },
      "availableActions": ["possible game actions"],
      "gameUI": {
        "inventoryOpen": boolean,
        "menuOpen": boolean,
        "chatVisible": boolean,
        "minimapVisible": boolean
      }
    },
    "interfaceType": "desktop|game|browser|application",
    "textContent": ["readable text on screen"],
    "clickableElements": [
      {
        "type": "button|link|input|menu|icon",
        "text": "element text",
        "position": {"x": 0, "y": 0, "width": 0, "height": 0},
        "action": "what this element does",
        "confidence": 0.95
      }
    ]
  },
  "contextualUnderstanding": {
    "userActivity": "what the user is currently doing",
    "currentTask": "specific task being performed",
    "emotionalState": "calm|focused|frustrated|excited|stressed",
    "urgencyLevel": "low|medium|high|critical",
    "recommendations": ["actionable suggestions"]
  },
  "opportunities": {
    "automationPossibilities": [
      {
        "action": "specific automation",
        "description": "what it would do",
        "confidence": 0.9,
        "estimatedTimeSaving": 30,
        "requiredPermissions": ["list of required permissions"]
      }
    ],
    "proactiveActions": [
      {
        "type": "suggestion|reminder|optimization|warning",
        "message": "proactive message",
        "priority": "low|medium|high",
        "timing": "immediate|delayed|scheduled",
        "context": "when to trigger this"
      }
    ],
    "optimizations": ["performance and workflow optimizations"]
  }
}

${options.includeGameAnalysis ? 'Pay special attention to game state analysis if a game is detected.' : ''}
${options.includeAutomationOpportunities ? 'Focus on identifying automation opportunities.' : ''}

Be precise, actionable, and think like JARVIS would - anticipate needs and provide intelligent insights.
`;
  }

  /**
   * Валидация и структурирование результата анализа
   */
  private validateAndStructureAnalysis(rawAnalysis: any): VisualAnalysisResult {
    // Обеспечиваем правильную структуру данных
    const result: VisualAnalysisResult = {
      screenContent: {
        mainElements: rawAnalysis.screenContent?.mainElements || [],
        activeApplication: rawAnalysis.screenContent?.activeApplication || 'Unknown',
        gameState: rawAnalysis.screenContent?.gameState || null,
        interfaceType: rawAnalysis.screenContent?.interfaceType || 'desktop',
        textContent: rawAnalysis.screenContent?.textContent || [],
        clickableElements: rawAnalysis.screenContent?.clickableElements || []
      },
      contextualUnderstanding: {
        userActivity: rawAnalysis.contextualUnderstanding?.userActivity || 'Unknown activity',
        currentTask: rawAnalysis.contextualUnderstanding?.currentTask || 'Unknown task',
        emotionalState: rawAnalysis.contextualUnderstanding?.emotionalState || 'neutral',
        urgencyLevel: rawAnalysis.contextualUnderstanding?.urgencyLevel || 'low',
        recommendations: rawAnalysis.contextualUnderstanding?.recommendations || []
      },
      systemState: {
        runningProcesses: [],
        activeWindows: [],
        resourceUsage: { cpuUsage: 0, memoryUsage: 0, diskUsage: 0, networkUsage: 0 },
        networkActivity: []
      },
      opportunities: {
        automationPossibilities: rawAnalysis.opportunities?.automationPossibilities || [],
        proactiveActions: rawAnalysis.opportunities?.proactiveActions || [],
        optimizations: rawAnalysis.opportunities?.optimizations || []
      }
    };

    return result;
  }

  /**
   * Сбор информации о состоянии системы
   */
  private async gatherSystemState(): Promise<{
    runningProcesses: string[];
    activeWindows: WindowInfo[];
    resourceUsage: ResourceInfo;
    networkActivity: string[];
  }> {
    try {
      const [processes, windows, resources] = await Promise.all([
        this.getRunningProcesses(),
        this.getActiveWindows(),
        this.getResourceUsage()
      ]);

      return {
        runningProcesses: processes,
        activeWindows: windows,
        resourceUsage: resources,
        networkActivity: [] // TODO: Implement network monitoring
      };
    } catch (error) {
      console.error('Error gathering system state:', error);
      return {
        runningProcesses: [],
        activeWindows: [],
        resourceUsage: { cpuUsage: 0, memoryUsage: 0, diskUsage: 0, networkUsage: 0 },
        networkActivity: []
      };
    }
  }

  /**
   * Получение списка запущенных процессов
   */
  private async getRunningProcesses(): Promise<string[]> {
    try {
      const { stdout } = await execAsync(process.platform === 'win32' 
        ? 'tasklist /fo csv | findstr /v "^INFO"' 
        : 'ps aux --no-headers');
      
      const processes = stdout.split('\n')
        .filter(line => line.trim())
        .map(line => {
          if (process.platform === 'win32') {
            return line.split(',')[0].replace(/"/g, '');
          } else {
            return line.split(/\s+/)[10] || '';
          }
        })
        .filter(name => name && !name.startsWith('['));

      return [...new Set(processes)].slice(0, 20); // Ограничиваем количество
    } catch (error) {
      console.error('Error getting processes:', error);
      return [];
    }
  }

  /**
   * Получение информации об активных окнах
   */
  private async getActiveWindows(): Promise<WindowInfo[]> {
    try {
      if (process.platform === 'win32') {
        // Windows implementation
        const { stdout } = await execAsync('powershell "Get-Process | Where-Object {$_.MainWindowTitle} | Select-Object ProcessName,MainWindowTitle"');
        // Parse Windows output
        return [];
      } else if (process.platform === 'linux') {
        // Linux implementation with xdotool
        const { stdout } = await execAsync('xdotool search --name "." getwindowname %@');
        // Parse Linux output
        return [];
      } else {
        // macOS implementation
        const { stdout } = await execAsync('osascript -e "tell application \\"System Events\\" to get name of (processes where background only is false)"');
        // Parse macOS output
        return [];
      }
    } catch (error) {
      console.error('Error getting windows:', error);
      return [];
    }
  }

  /**
   * Получение информации об использовании ресурсов
   */
  private async getResourceUsage(): Promise<ResourceInfo> {
    try {
      // Simple implementation - can be enhanced
      const { stdout } = await execAsync(process.platform === 'win32'
        ? 'wmic cpu get loadpercentage /value'
        : 'top -bn1 | grep "Cpu(s)" | awk \'{print $2}\' | cut -d\'%\' -f1');
      
      const cpuUsage = parseFloat(stdout.match(/\d+/)?.[0] || '0');
      
      return {
        cpuUsage,
        memoryUsage: 0, // TODO: Implement
        diskUsage: 0,   // TODO: Implement
        networkUsage: 0 // TODO: Implement
      };
    } catch (error) {
      return { cpuUsage: 0, memoryUsage: 0, diskUsage: 0, networkUsage: 0 };
    }
  }

  /**
   * Определение возможностей для автоматизации
   */
  private async identifyOpportunities(analysis: VisualAnalysisResult): Promise<{
    automationPossibilities: AutomationOpportunity[];
    proactiveActions: ProactiveAction[];
    optimizations: string[];
  }> {
    // Эта логика будет улучшена с помощью машинного обучения
    const opportunities = analysis.opportunities || {
      automationPossibilities: [],
      proactiveActions: [],
      optimizations: []
    };

    // Добавляем базовые возможности автоматизации
    if (analysis.screenContent.interfaceType === 'game') {
      opportunities.automationPossibilities.push({
        action: 'Auto-heal when health is low',
        description: 'Automatically use healing items when health drops below 30%',
        confidence: 0.8,
        estimatedTimeSaving: 5,
        requiredPermissions: ['keyboard_simulation']
      });
    }

    return opportunities;
  }

  /**
   * Анализ конкретной области экрана
   */
  async analyzeRegion(region: { x: number; y: number; width: number; height: number }): Promise<VisualAnalysisResult> {
    return this.analyzeScreen({ focusArea: region });
  }

  /**
   * Поиск конкретного элемента на экране
   */
  async findElement(description: string): Promise<ClickableElement | null> {
    const analysis = await this.analyzeScreen();
    
    // Ищем элемент по описанию
    const element = analysis.screenContent.clickableElements.find(el => 
      el.text.toLowerCase().includes(description.toLowerCase()) ||
      el.action.toLowerCase().includes(description.toLowerCase())
    );

    return element || null;
  }

  /**
   * Кэширование анализа
   */
  private cacheAnalysis(analysis: VisualAnalysisResult): void {
    const cacheKey = `analysis_${Date.now()}`;
    this.analysisCache.set(cacheKey, analysis);
    
    // Очистка старого кэша
    setTimeout(() => {
      this.analysisCache.delete(cacheKey);
    }, this.cacheTimeout);
  }

  /**
   * Ожидание завершения анализа
   */
  private async waitForAnalysis(): Promise<void> {
    while (this.isAnalyzing) {
      await new Promise(resolve => setTimeout(resolve, 100));
    }
  }

  /**
   * Получение статуса системы
   */
  getStatus(): {
    isAnalyzing: boolean;
    cacheSize: number;
    lastAnalysis: string | null;
  } {
    return {
      isAnalyzing: this.isAnalyzing,
      cacheSize: this.analysisCache.size,
      lastAnalysis: this.analysisCache.size > 0 ? 'Recently analyzed' : null
    };
  }
}

export const jarvisVisionEngine = new JarvisVisionEngine();