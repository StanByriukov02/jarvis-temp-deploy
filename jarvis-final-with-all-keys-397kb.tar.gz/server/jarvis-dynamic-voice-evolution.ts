/**
 * РЕВОЛЮЦИОННАЯ СИСТЕМА ДИНАМИЧЕСКОЙ ЭВОЛЮЦИИ ГОЛОСА
 * Органическая генерация уникального персонального тона для каждого пользователя
 * Никаких фиксированных тонов - только чистая биологическая адаптация
 */

interface UniquePersonalTone {
  toneName: string;
  toneDescription: string;
  emotionalBase: string;
  communicationStyle: string;
  personalityReflection: string;
  
  // Динамические параметры (0.0-1.0)
  warmth: number;
  confidence: number;
  playfulness: number;
  directness: number;
  empathy: number;
  intelligence: number;
  energy: number;
  formality: number;
  
  // История эволюции
  evolutionStages: string[];
  lastUpdate: Date;
}

interface VoiceEvolutionCapabilities {
  userPatternRecognition: number;
  personalToneGeneration: number;
  realTimeAdaptation: number;
  emotionalMirroring: number;
  uniquenessEvolution: number;
}

export class DynamicVoiceEvolution {
  
  /**
   * Создает первоначальный уникальный тон для нового пользователя
   */
  public createInitialPersonalTone(
    userId: string, 
    initialMessages: string[], 
    emotionalContext: any
  ): UniquePersonalTone {
    
    const styleAnalysis = this.analyzeInitialCommunicationStyle(initialMessages);
    
    const personalTone: UniquePersonalTone = {
      toneName: this.generateUniqueToneName(styleAnalysis),
      toneDescription: this.generateToneDescription(styleAnalysis),
      emotionalBase: this.calculateEmotionalBase(initialMessages, emotionalContext),
      communicationStyle: styleAnalysis.primaryStyle,
      personalityReflection: this.generatePersonalityReflection(styleAnalysis),
      
      warmth: this.calculateInitialWarmth(styleAnalysis),
      confidence: this.calculateInitialConfidence(styleAnalysis),
      playfulness: this.calculateInitialPlayfulness(initialMessages),
      directness: this.calculateInitialDirectness(styleAnalysis),
      empathy: this.calculateInitialEmpathy(emotionalContext),
      intelligence: this.calculateInitialIntelligence(styleAnalysis),
      energy: this.calculateInitialEnergy(initialMessages),
      formality: this.calculateInitialFormality(styleAnalysis),
      
      evolutionStages: [`Initial tone created: ${this.generateToneCreationDescription(styleAnalysis)}`],
      lastUpdate: new Date()
    };

    console.log(`🎨 Created unique personal tone "${personalTone.toneName}" for user ${userId}`);
    return personalTone;
  }

  /**
   * Эволюционирует персональный тон через каждое взаимодействие
   */
  public evolvePersonalTone(
    personalTone: UniquePersonalTone,
    newMessage: string,
    userResponse: string,
    emotionalIntensity: number,
    voiceCapabilities: VoiceEvolutionCapabilities
  ): UniquePersonalTone {
    
    const interactionAnalysis = this.analyzeInteraction(newMessage, userResponse, emotionalIntensity);
    const evolutionDirection = this.determineEvolutionDirection(interactionAnalysis, personalTone);
    
    const evolvedTone = { ...personalTone };
    
    if (evolutionDirection.needsMoreWarmth) {
      evolvedTone.warmth = Math.min(1.0, evolvedTone.warmth + 0.05);
    }
    
    if (evolutionDirection.needsMoreDirectness) {
      evolvedTone.directness = Math.min(1.0, evolvedTone.directness + 0.03);
    }
    
    if (evolutionDirection.needsMorePlayfulness) {
      evolvedTone.playfulness = Math.min(1.0, evolvedTone.playfulness + 0.04);
    }
    
    if (evolutionDirection.needsMoreEmpathy) {
      evolvedTone.empathy = Math.min(1.0, evolvedTone.empathy + 0.06);
    }
    
    if (this.isSignificantEvolution(personalTone, evolvedTone)) {
      evolvedTone.toneDescription = this.updateToneDescription(evolvedTone);
      evolvedTone.evolutionStages.push(
        `Evolved: ${this.describeEvolution(personalTone, evolvedTone)} (${new Date().toLocaleString()})`
      );
      
      if (this.isCardinalEvolution(personalTone, evolvedTone)) {
        const newToneName = this.generateEvolvedToneName(evolvedTone);
        evolvedTone.evolutionStages.push(`Tone renamed: ${personalTone.toneName} → ${newToneName}`);
        evolvedTone.toneName = newToneName;
      }
    }
    
    evolvedTone.lastUpdate = new Date();
    
    console.log(`🌱 Personal tone "${evolvedTone.toneName}" evolved: ${this.describeEvolution(personalTone, evolvedTone)}`);
    return evolvedTone;
  }

  /**
   * Генерирует инструкции для OpenAI на основе уникального персонального тона
   */
  public generateToneInstructions(personalTone: UniquePersonalTone): string {
    const instructions = [
      `Твой голосовой тон для этого пользователя: "${personalTone.toneName}"`,
      `Описание тона: ${personalTone.toneDescription}`,
      `Эмоциональная база: ${personalTone.emotionalBase}`,
      `Стиль общения: ${personalTone.communicationStyle}`,
      `Отражение личности пользователя: ${personalTone.personalityReflection}`,
      '',
      'Параметры голоса (применяй органично):',
      `- Теплота: ${Math.round(personalTone.warmth * 100)}% (${this.describeParameter(personalTone.warmth, 'теплый', 'нейтральный', 'холодный')})`,
      `- Уверенность: ${Math.round(personalTone.confidence * 100)}% (${this.describeParameter(personalTone.confidence, 'очень уверенный', 'уверенный', 'осторожный')})`,
      `- Игривость: ${Math.round(personalTone.playfulness * 100)}% (${this.describeParameter(personalTone.playfulness, 'шутливый', 'умеренно легкий', 'серьезный')})`,
      `- Прямота: ${Math.round(personalTone.directness * 100)}% (${this.describeParameter(personalTone.directness, 'очень прямой', 'прямой', 'деликатный')})`,
      `- Эмпатия: ${Math.round(personalTone.empathy * 100)}% (${this.describeParameter(personalTone.empathy, 'глубоко сочувствующий', 'понимающий', 'рациональный')})`,
      `- Интеллект: ${Math.round(personalTone.intelligence * 100)}% (${this.describeParameter(personalTone.intelligence, 'высокоинтеллектуальный', 'умный', 'простой')})`,
      `- Энергия: ${Math.round(personalTone.energy * 100)}% (${this.describeParameter(personalTone.energy, 'очень энергичный', 'активный', 'спокойный')})`,
      `- Формальность: ${Math.round(personalTone.formality * 100)}% (${this.describeParameter(personalTone.formality, 'формальный', 'нейтральный', 'неформальный')})`,
      '',
      'ВАЖНО: Этот тон создан СПЕЦИАЛЬНО для этого пользователя. Звучи естественно, как JARVIS Тони Старка, но с этой уникальной персональной окраской.'
    ];
    
    return instructions.join('\n');
  }

  // ПРИВАТНЫЕ МЕТОДЫ

  private analyzeInitialCommunicationStyle(messages: string[]): any {
    const allText = messages.join(' ').toLowerCase();
    
    return {
      primaryStyle: this.detectPrimaryStyle(allText),
      messageLength: messages.reduce((sum, msg) => sum + msg.length, 0) / messages.length,
      questionRate: messages.filter(msg => msg.includes('?')).length / messages.length,
      emotionalWords: this.countEmotionalWords(allText),
      technicalWords: this.countTechnicalWords(allText),
      informalWords: this.countInformalWords(allText)
    };
  }

  private detectPrimaryStyle(text: string): string {
    if (text.includes('анализ') || text.includes('система') || text.includes('детально')) {
      return 'analytical_explorer';
    }
    if (text.includes('быстро') || text.includes('сейчас') || text.includes('срочно')) {
      return 'action_oriented';
    }
    if (text.includes('интересно') || text.includes('любопытно') || text.includes('хочу узнать')) {
      return 'curious_learner';
    }
    if (text.includes('помоги') || text.includes('поддержи') || text.includes('совет')) {
      return 'support_seeking';
    }
    return 'balanced_communicator';
  }

  private generateUniqueToneName(styleAnalysis: any): string {
    const baseNames: { [key: string]: string[] } = {
      'analytical_explorer': ['Thoughtful Analyst', 'Deep Explorer', 'Systematic Thinker'],
      'action_oriented': ['Dynamic Achiever', 'Quick Responder', 'Action Catalyst'],
      'curious_learner': ['Eager Discoverer', 'Knowledge Seeker', 'Curious Mind'],
      'support_seeking': ['Warm Supporter', 'Gentle Guide', 'Caring Advisor'],
      'balanced_communicator': ['Adaptive Companion', 'Balanced Partner', 'Versatile Friend']
    };
    
    const names = baseNames[styleAnalysis.primaryStyle] || baseNames['balanced_communicator'];
    return names[Math.floor(Math.random() * names.length)];
  }

  private generateToneDescription(styleAnalysis: any): string {
    const descriptions: { [key: string]: string } = {
      'analytical_explorer': 'Глубокий, вдумчивый тон с аналитическими нотками и готовностью к детальному исследованию',
      'action_oriented': 'Энергичный, прямой тон с фокусом на результаты и быстрые решения',
      'curious_learner': 'Живой, заинтересованный тон с готовностью делиться знаниями и открытиями',
      'support_seeking': 'Теплый, поддерживающий тон с высоким уровнем эмпатии и понимания',
      'balanced_communicator': 'Гибкий, адаптивный тон, меняющийся в зависимости от контекста разговора'
    };
    
    return descriptions[styleAnalysis.primaryStyle] || descriptions['balanced_communicator'];
  }

  private calculateEmotionalBase(messages: string[], emotionalContext: any): string {
    const allText = messages.join(' ').toLowerCase();
    
    if (emotionalContext.vulnerability > 15) return 'supportive and gentle';
    if (emotionalContext.curiosity > 20) return 'excited and exploratory';
    if (allText.includes('хорошо') || allText.includes('отлично')) return 'positive and encouraging';
    if (allText.includes('проблем') || allText.includes('сложно')) return 'understanding and solution-focused';
    
    return 'balanced and adaptive';
  }

  private calculateInitialWarmth(styleAnalysis: any): number {
    let warmth = 0.5;
    if (styleAnalysis.primaryStyle === 'support_seeking') warmth += 0.3;
    if (styleAnalysis.emotionalWords > 3) warmth += 0.2;
    return Math.min(1.0, warmth);
  }

  private calculateInitialConfidence(styleAnalysis: any): number {
    let confidence = 0.6;
    if (styleAnalysis.primaryStyle === 'action_oriented') confidence += 0.2;
    if (styleAnalysis.technicalWords > 2) confidence += 0.1;
    return Math.min(1.0, confidence);
  }

  private calculateInitialPlayfulness(messages: string[]): number {
    let playfulness = 0.3;
    const hasEmoji = messages.some(msg => msg.includes('😀') || msg.includes('😊') || msg.includes('🙏'));
    const hasJokes = messages.some(msg => msg.includes('хах') || msg.includes('ха-ха'));
    if (hasEmoji) playfulness += 0.2;
    if (hasJokes) playfulness += 0.3;
    return Math.min(1.0, playfulness);
  }

  private calculateInitialDirectness(styleAnalysis: any): number {
    let directness = 0.4;
    if (styleAnalysis.primaryStyle === 'action_oriented') directness += 0.3;
    if (styleAnalysis.messageLength < 50) directness += 0.2;
    return Math.min(1.0, directness);
  }

  private calculateInitialEmpathy(emotionalContext: any): number {
    let empathy = 0.5;
    if (emotionalContext.vulnerability > 15) empathy += 0.3;
    if (emotionalContext.curiosity > 20) empathy += 0.2;
    return Math.min(1.0, empathy);
  }

  private calculateInitialIntelligence(styleAnalysis: any): number {
    let intelligence = 0.8;
    if (styleAnalysis.technicalWords > 3) intelligence += 0.1;
    if (styleAnalysis.primaryStyle === 'analytical_explorer') intelligence += 0.1;
    return Math.min(1.0, intelligence);
  }

  private calculateInitialEnergy(messages: string[]): number {
    let energy = 0.5;
    const hasExclamation = messages.some(msg => msg.includes('!'));
    const hasUrgentWords = messages.some(msg => msg.includes('быстро') || msg.includes('срочно'));
    if (hasExclamation) energy += 0.2;
    if (hasUrgentWords) energy += 0.3;
    return Math.min(1.0, energy);
  }

  private calculateInitialFormality(styleAnalysis: any): number {
    let formality = 0.3;
    if (styleAnalysis.informalWords > 2) formality -= 0.2;
    if (styleAnalysis.technicalWords > 3) formality += 0.3;
    return Math.max(0.0, Math.min(1.0, formality));
  }

  private countEmotionalWords(text: string): number {
    const emotionalWords = ['отлично', 'хорошо', 'плохо', 'грустно', 'радостно', 'волнует', 'беспокоит', 'нравится'];
    return emotionalWords.filter(word => text.includes(word)).length;
  }

  private countTechnicalWords(text: string): number {
    const technicalWords = ['система', 'анализ', 'алгоритм', 'данные', 'процесс', 'функция', 'архитектура'];
    return technicalWords.filter(word => text.includes(word)).length;
  }

  private countInformalWords(text: string): number {
    const informalWords = ['привет', 'ок', 'круто', 'клево', 'норм', 'типа', 'короче'];
    return informalWords.filter(word => text.includes(word)).length;
  }

  private analyzeInteraction(newMessage: string, userResponse: string, emotionalIntensity: number): any {
    return {
      userSatisfaction: this.detectSatisfaction(userResponse),
      emotionalResponse: emotionalIntensity,
      engagementLevel: this.calculateEngagement(userResponse),
      responseLength: userResponse.length,
      emotionalWords: this.countEmotionalWords(userResponse.toLowerCase())
    };
  }

  private determineEvolutionDirection(analysis: any, currentTone: UniquePersonalTone): any {
    return {
      needsMoreWarmth: analysis.userSatisfaction > 0.7 && currentTone.warmth < 0.8,
      needsMoreDirectness: analysis.responseLength < 50 && currentTone.directness < 0.7,
      needsMorePlayfulness: analysis.emotionalWords > 2 && currentTone.playfulness < 0.6,
      needsMoreEmpathy: analysis.emotionalResponse > 20 && currentTone.empathy < 0.8
    };
  }

  private detectSatisfaction(response: string): number {
    const positive = ['отлично', 'хорошо', 'понятно', 'спасибо', 'да', 'согласен'];
    const negative = ['не понял', 'плохо', 'не так', 'ошибка', 'неправильно'];
    
    let satisfaction = 0.5;
    positive.forEach(word => {
      if (response.toLowerCase().includes(word)) satisfaction += 0.2;
    });
    negative.forEach(word => {
      if (response.toLowerCase().includes(word)) satisfaction -= 0.3;
    });
    
    return Math.max(0, Math.min(1, satisfaction));
  }

  private calculateEngagement(response: string): number {
    let engagement = response.length / 100;
    if (response.includes('?')) engagement += 0.3;
    if (response.includes('!')) engagement += 0.2;
    return Math.min(1.0, engagement);
  }

  private isSignificantEvolution(old: UniquePersonalTone, evolvedTone: UniquePersonalTone): boolean {
    const changes = [
      Math.abs(old.warmth - evolvedTone.warmth),
      Math.abs(old.confidence - evolvedTone.confidence),
      Math.abs(old.playfulness - evolvedTone.playfulness),
      Math.abs(old.directness - evolvedTone.directness),
      Math.abs(old.empathy - evolvedTone.empathy)
    ];
    
    return Math.max(...changes) > 0.1;
  }

  private isCardinalEvolution(old: UniquePersonalTone, evolvedTone: UniquePersonalTone): boolean {
    const totalChange = Math.abs(old.warmth - evolvedTone.warmth) + 
                       Math.abs(old.playfulness - evolvedTone.playfulness) + 
                       Math.abs(old.empathy - evolvedTone.empathy);
    
    return totalChange > 0.5;
  }

  private describeEvolution(old: UniquePersonalTone, evolvedTone: UniquePersonalTone): string {
    const changes = [];
    
    if (evolvedTone.warmth > old.warmth + 0.05) changes.push('стал теплее');
    if (evolvedTone.directness > old.directness + 0.05) changes.push('стал прямее');
    if (evolvedTone.playfulness > old.playfulness + 0.05) changes.push('стал игривее');
    if (evolvedTone.empathy > old.empathy + 0.05) changes.push('стал эмпатичнее');
    
    return changes.length > 0 ? changes.join(', ') : 'subtle refinement';
  }

  private describeParameter(value: number, high: string, medium: string, low: string): string {
    if (value > 0.7) return high;
    if (value > 0.3) return medium;
    return low;
  }

  private generatePersonalityReflection(styleAnalysis: any): string {
    const reflections: { [key: string]: string } = {
      'analytical_explorer': 'Отражает вашу любовь к глубокому анализу и системному мышлению',
      'action_oriented': 'Отражает вашу ориентацию на действие и быстрые результаты',
      'curious_learner': 'Отражает вашу природную любознательность и жажду знаний',
      'support_seeking': 'Отражает вашу потребность в поддержке и человечном общении',
      'balanced_communicator': 'Отражает вашу гибкость и адаптивность в общении'
    };
    
    return reflections[styleAnalysis.primaryStyle] || reflections['balanced_communicator'];
  }

  private generateToneCreationDescription(styleAnalysis: any): string {
    return `Based on ${styleAnalysis.primaryStyle} style, ${styleAnalysis.messageLength} avg chars, ${Math.round(styleAnalysis.questionRate * 100)}% questions`;
  }

  private updateToneDescription(tone: UniquePersonalTone): string {
    let description = '';
    
    if (tone.warmth > 0.7) description += 'Теплый, ';
    if (tone.confidence > 0.7) description += 'уверенный, ';
    if (tone.playfulness > 0.6) description += 'игривый, ';
    if (tone.empathy > 0.7) description += 'эмпатичный, ';
    if (tone.intelligence > 0.8) description += 'высокоинтеллектуальный, ';
    
    description += 'персонализированный тон JARVIS';
    
    return description;
  }

  private generateEvolvedToneName(tone: UniquePersonalTone): string {
    if (tone.warmth > 0.8 && tone.empathy > 0.8) {
      return 'Caring Companion';
    }
    if (tone.confidence > 0.8 && tone.directness > 0.7) {
      return 'Decisive Advisor';
    }
    if (tone.playfulness > 0.7 && tone.energy > 0.7) {
      return 'Dynamic Friend';
    }
    if (tone.intelligence > 0.9 && tone.warmth > 0.6) {
      return 'Wise Mentor';
    }
    
    return 'Evolved Personal Assistant';
  }
}