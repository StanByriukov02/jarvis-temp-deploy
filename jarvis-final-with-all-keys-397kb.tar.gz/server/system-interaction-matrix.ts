export type SystemIntensity = 'light' | 'medium' | 'heavy';
export type SystemCategory = 'productivity' | 'revenue' | 'content' | 'focus' | 'health' | 'learning';

export interface SystemInteraction {
  systemA: string;
  systemB: string;
  interactionType: 'conflict' | 'synergy' | 'neutral' | 'dependency';
  strength: number; // 0-100
  scheduleImpact: 'none' | 'low' | 'medium' | 'high';
  resourceSharing: string[];
}

export interface ScheduleCoordination {
  systemId: string;
  timeSlots: {
    start: string;
    end: string;
    priority: number;
    flexibility: number; // 0-100, how much this can be moved
  }[];
  dependencies: string[];
  bufferTime: number; // minutes needed between tasks
}

export class SystemInteractionMatrix {
  private interactions: SystemInteraction[] = [
    {
      systemA: 'revenue-acceleration',
      systemB: 'content-creation-intensive',
      interactionType: 'conflict',
      strength: 85,
      scheduleImpact: 'high',
      resourceSharing: ['cognitive-load', 'energy', 'focus-time']
    },
    {
      systemA: 'revenue-acceleration',
      systemB: 'business-optimization',
      interactionType: 'synergy',
      strength: 90,
      scheduleImpact: 'low',
      resourceSharing: ['business-data', 'analytics', 'strategy-time']
    },
    {
      systemA: 'deep-focus-intensive',
      systemB: 'content-creation-intensive',
      interactionType: 'conflict',
      strength: 75,
      scheduleImpact: 'high',
      resourceSharing: ['deep-focus-time', 'creative-energy']
    },
    {
      systemA: 'productivity-enhancement',
      systemB: 'deep-focus-intensive',
      interactionType: 'synergy',
      strength: 70,
      scheduleImpact: 'medium',
      resourceSharing: ['focus-techniques', 'time-management']
    },
    {
      systemA: 'mindfulness',
      systemB: 'deep-focus-intensive',
      interactionType: 'synergy',
      strength: 80,
      scheduleImpact: 'low',
      resourceSharing: ['mental-clarity', 'stress-reduction']
    }
  ];

  private systemProfiles: Record<string, {
    intensity: SystemIntensity;
    category: SystemCategory;
    peakHours: number[];
    minimumSessionTime: number;
    maximumSessionTime: number;
    requiresDeepFocus: boolean;
    energyDrain: number; // 0-100
  }> = {
    'revenue-acceleration': {
      intensity: 'heavy',
      category: 'revenue',
      peakHours: [9, 10, 11, 14, 15],
      minimumSessionTime: 90,
      maximumSessionTime: 180,
      requiresDeepFocus: true,
      energyDrain: 80
    },
    'content-creation-intensive': {
      intensity: 'heavy',
      category: 'content',
      peakHours: [8, 9, 10, 16, 17],
      minimumSessionTime: 120,
      maximumSessionTime: 240,
      requiresDeepFocus: true,
      energyDrain: 85
    },
    'deep-focus-intensive': {
      intensity: 'heavy',
      category: 'focus',
      peakHours: [7, 8, 9, 10, 11],
      minimumSessionTime: 60,
      maximumSessionTime: 180,
      requiresDeepFocus: true,
      energyDrain: 70
    },
    'business-optimization': {
      intensity: 'medium',
      category: 'productivity',
      peakHours: [10, 11, 14, 15, 16],
      minimumSessionTime: 45,
      maximumSessionTime: 120,
      requiresDeepFocus: false,
      energyDrain: 50
    },
    'productivity-enhancement': {
      intensity: 'light',
      category: 'productivity',
      peakHours: [8, 9, 13, 14, 15, 16],
      minimumSessionTime: 30,
      maximumSessionTime: 90,
      requiresDeepFocus: false,
      energyDrain: 30
    },
    'mindfulness': {
      intensity: 'light',
      category: 'health',
      peakHours: [7, 8, 18, 19, 20],
      minimumSessionTime: 15,
      maximumSessionTime: 60,
      requiresDeepFocus: false,
      energyDrain: -20 // Actually restores energy
    }
  };

  calculateSystemInteractions(activeSystems: string[]): {
    conflicts: SystemInteraction[];
    synergies: SystemInteraction[];
    scheduleRecommendations: ScheduleCoordination[];
  } {
    const conflicts: SystemInteraction[] = [];
    const synergies: SystemInteraction[] = [];

    // Find all interactions between active systems
    for (let i = 0; i < activeSystems.length; i++) {
      for (let j = i + 1; j < activeSystems.length; j++) {
        const interaction = this.findInteraction(activeSystems[i], activeSystems[j]);
        if (interaction) {
          if (interaction.interactionType === 'conflict') {
            conflicts.push(interaction);
          } else if (interaction.interactionType === 'synergy') {
            synergies.push(interaction);
          }
        }
      }
    }

    const scheduleRecommendations = this.generateScheduleCoordination(activeSystems, conflicts, synergies);

    return { conflicts, synergies, scheduleRecommendations };
  }

  private findInteraction(systemA: string, systemB: string): SystemInteraction | null {
    return this.interactions.find(interaction =>
      (interaction.systemA === systemA && interaction.systemB === systemB) ||
      (interaction.systemA === systemB && interaction.systemB === systemA)
    ) || null;
  }

  private generateScheduleCoordination(
    activeSystems: string[],
    conflicts: SystemInteraction[],
    synergies: SystemInteraction[]
  ): ScheduleCoordination[] {
    const coordination: ScheduleCoordination[] = [];

    activeSystems.forEach(systemId => {
      const profile = this.systemProfiles[systemId];
      if (!profile) return;

      const systemConflicts = conflicts.filter(c => 
        c.systemA === systemId || c.systemB === systemId
      );

      const timeSlots = this.generateOptimalTimeSlots(systemId, profile, systemConflicts);
      const dependencies = this.calculateDependencies(systemId, synergies);
      const bufferTime = this.calculateBufferTime(systemId, profile, systemConflicts);

      coordination.push({
        systemId,
        timeSlots,
        dependencies,
        bufferTime
      });
    });

    return this.optimizeScheduleCoordination(coordination);
  }

  private generateOptimalTimeSlots(
    systemId: string,
    profile: any,
    conflicts: SystemInteraction[]
  ): any[] {
    const timeSlots = [];
    const highConflictHours = this.getConflictHours(systemId, conflicts);

    // Generate time slots during peak hours, avoiding conflicts
    profile.peakHours.forEach((hour: number, index: number) => {
      if (!highConflictHours.includes(hour)) {
        timeSlots.push({
          start: `${hour.toString().padStart(2, '0')}:00`,
          end: `${(hour + Math.ceil(profile.minimumSessionTime / 60)).toString().padStart(2, '0')}:00`,
          priority: 10 - index, // Higher priority for earlier peak hours
          flexibility: profile.intensity === 'heavy' ? 20 : 60
        });
      }
    });

    // Add backup slots with lower priority
    const backupHours = [13, 14, 15, 16, 17].filter(h => !profile.peakHours.includes(h));
    backupHours.forEach((hour, index) => {
      timeSlots.push({
        start: `${hour.toString().padStart(2, '0')}:00`,
        end: `${(hour + Math.ceil(profile.minimumSessionTime / 60)).toString().padStart(2, '0')}:00`,
        priority: 3 - index,
        flexibility: 80
      });
    });

    return timeSlots;
  }

  private getConflictHours(systemId: string, conflicts: SystemInteraction[]): number[] {
    const conflictHours: number[] = [];
    
    conflicts.forEach(conflict => {
      const otherSystemId = conflict.systemA === systemId ? conflict.systemB : conflict.systemA;
      const otherProfile = this.systemProfiles[otherSystemId];
      
      if (otherProfile && conflict.strength > 70) {
        conflictHours.push(...otherProfile.peakHours);
      }
    });

    return [...new Set(conflictHours)];
  }

  private calculateDependencies(systemId: string, synergies: SystemInteraction[]): string[] {
    const dependencies: string[] = [];
    
    synergies.forEach(synergy => {
      if (synergy.interactionType === 'dependency') {
        if (synergy.systemB === systemId) {
          dependencies.push(synergy.systemA);
        }
      }
    });

    return dependencies;
  }

  private calculateBufferTime(systemId: string, profile: any, conflicts: SystemInteraction[]): number {
    let baseBuffer = 15; // 15 minutes base buffer

    if (profile.intensity === 'heavy') {
      baseBuffer = 30;
    }

    if (profile.requiresDeepFocus) {
      baseBuffer += 15;
    }

    // Add extra buffer for high-conflict systems
    const highConflicts = conflicts.filter(c => c.strength > 80);
    baseBuffer += highConflicts.length * 10;

    return Math.min(baseBuffer, 60); // Cap at 60 minutes
  }

  private optimizeScheduleCoordination(coordination: ScheduleCoordination[]): ScheduleCoordination[] {
    // Sort by system intensity and dependencies
    const sorted = coordination.sort((a, b) => {
      const profileA = this.systemProfiles[a.systemId];
      const profileB = this.systemProfiles[b.systemId];
      
      if (!profileA || !profileB) return 0;

      // Heavy systems get priority
      const intensityOrder = { heavy: 3, medium: 2, light: 1 };
      const intensityDiff = intensityOrder[profileB.intensity] - intensityOrder[profileA.intensity];
      
      if (intensityDiff !== 0) return intensityDiff;

      // Systems with dependencies go after their dependencies
      if (a.dependencies.includes(b.systemId)) return 1;
      if (b.dependencies.includes(a.systemId)) return -1;

      return 0;
    });

    // Adjust time slots to prevent overlaps
    const usedTimeSlots = new Set<string>();
    
    return sorted.map(coord => {
      const adjustedTimeSlots = coord.timeSlots.filter(slot => {
        const slotKey = `${slot.start}-${slot.end}`;
        if (usedTimeSlots.has(slotKey)) {
          return false;
        }
        usedTimeSlots.add(slotKey);
        return true;
      });

      return {
        ...coord,
        timeSlots: adjustedTimeSlots
      };
    });
  }

  generateDailySchedule(
    activeSystems: string[],
    userPreferences: {
      workStartTime: string;
      workEndTime: string;
      breakDuration: number;
      maxSessionsPerDay: number;
    }
  ): {
    schedule: Array<{
      systemId: string;
      startTime: string;
      endTime: string;
      priority: number;
      bufferBefore: number;
      bufferAfter: number;
    }>;
    conflicts: string[];
    optimizationTips: string[];
  } {
    const { conflicts, synergies, scheduleRecommendations } = this.calculateSystemInteractions(activeSystems);
    
    const schedule = [];
    const conflictMessages: string[] = [];
    const optimizationTips: string[] = [];

    // Generate conflicts warnings
    conflicts.forEach(conflict => {
      conflictMessages.push(
        `${conflict.systemA} and ${conflict.systemB} compete for ${conflict.resourceSharing.join(', ')}`
      );
    });

    // Generate optimization tips based on synergies
    synergies.forEach(synergy => {
      optimizationTips.push(
        `Schedule ${synergy.systemA} and ${synergy.systemB} close together to leverage shared ${synergy.resourceSharing.join(', ')}`
      );
    });

    // Build the actual schedule
    let currentTime = this.parseTime(userPreferences.workStartTime);
    const endTime = this.parseTime(userPreferences.workEndTime);

    scheduleRecommendations.forEach(coord => {
      const profile = this.systemProfiles[coord.systemId];
      if (!profile || currentTime >= endTime) return;

      const sessionDuration = profile.minimumSessionTime;
      const sessionEnd = new Date(currentTime.getTime() + sessionDuration * 60000);

      if (sessionEnd <= endTime) {
        schedule.push({
          systemId: coord.systemId,
          startTime: this.formatTime(currentTime),
          endTime: this.formatTime(sessionEnd),
          priority: coord.timeSlots[0]?.priority || 5,
          bufferBefore: coord.bufferTime / 2,
          bufferAfter: coord.bufferTime / 2
        });

        // Add session duration + buffer time
        currentTime = new Date(sessionEnd.getTime() + coord.bufferTime * 60000);
        
        // Add break time
        currentTime = new Date(currentTime.getTime() + userPreferences.breakDuration * 60000);
      }
    });

    return {
      schedule,
      conflicts: conflictMessages,
      optimizationTips
    };
  }

  private parseTime(timeStr: string): Date {
    const [hours, minutes] = timeStr.split(':').map(Number);
    const date = new Date();
    date.setHours(hours, minutes, 0, 0);
    return date;
  }

  private formatTime(date: Date): string {
    return date.toLocaleTimeString('en-US', { 
      hour: '2-digit', 
      minute: '2-digit',
      hour12: false 
    });
  }
}

export const systemInteractionMatrix = new SystemInteractionMatrix();