/**
 * JARVIS VOICE EVOLUTION ENGINE
 * Система непрерывного улучшения качества голоса через биосингулярность
 */

interface VoiceEvolutionData {
  generation: number;
  parameters: {
    stability: number;
    similarity_boost: number;
    style: number;
    use_speaker_boost: boolean;
  };
  feedback: {
    clarity: number; // 1-10
    naturalness: number; // 1-10  
    authenticity: number; // 1-10
    overall: number; // 1-10
  };
  timestamp: Date;
  improvements: string[];
}

class JarvisVoiceEvolution {
  private evolutionHistory: VoiceEvolutionData[] = [];
  private currentGeneration = 1;
  
  /**
   * Инициализация с базовыми параметрами
   */
  constructor() {
    // Базовые параметры от анализа оригинальных записей
    this.evolutionHistory = [{
      generation: 1,
      parameters: {
        stability: 0.9,
        similarity_boost: 0.98,
        style: 0.19,
        use_speaker_boost: true
      },
      feedback: {
        clarity: 6,
        naturalness: 5, 
        authenticity: 7,
        overall: 6
      },
      timestamp: new Date(),
      improvements: ['Initial bio-singularity analysis of Vsevolod Kuznetsov voice patterns']
    }];
  }

  /**
   * Получить текущие оптимальные параметры
   */
  getCurrentParameters() {
    return this.evolutionHistory[this.evolutionHistory.length - 1].parameters;
  }

  /**
   * Добавить обратную связь от пользователя
   */
  addFeedback(feedback: {
    clarity: number;
    naturalness: number; 
    authenticity: number;
    overall: number;
  }, userComment?: string) {
    console.log('🧬 Processing voice evolution feedback...');
    
    const currentParams = this.getCurrentParameters();
    const improvements: string[] = [];
    
    // Анализ обратной связи и корректировка параметров
    const newParams = { ...currentParams };
    
    // Если clarity низкая - увеличиваем stability
    if (feedback.clarity < 7) {
      newParams.stability = Math.min(1.0, newParams.stability + 0.02);
      improvements.push(`Increased stability to ${newParams.stability.toFixed(2)} for better clarity`);
    }
    
    // Если naturalness низкая - корректируем style
    if (feedback.naturalness < 7) {
      newParams.style = Math.max(0.1, newParams.style - 0.01);
      improvements.push(`Adjusted style to ${newParams.style.toFixed(2)} for more natural sound`);
    }
    
    // Если authenticity низкая - увеличиваем similarity
    if (feedback.authenticity < 7) {
      newParams.similarity_boost = Math.min(1.0, newParams.similarity_boost + 0.01);
      improvements.push(`Enhanced similarity to ${newParams.similarity_boost.toFixed(2)} for authenticity`);
    }
    
    // Если общая оценка выше 8 - делаем микро-оптимизации
    if (feedback.overall >= 8) {
      newParams.stability = Math.min(1.0, newParams.stability + 0.001);
      newParams.similarity_boost = Math.min(1.0, newParams.similarity_boost + 0.001);
      improvements.push('Fine-tuning parameters based on positive feedback');
    }
    
    if (userComment) {
      improvements.push(`User feedback: "${userComment}"`);
    }
    
    // Создаем новое поколение только если есть изменения
    const hasChanges = JSON.stringify(newParams) !== JSON.stringify(currentParams);
    
    if (hasChanges || improvements.length > 0) {
      this.currentGeneration++;
      
      this.evolutionHistory.push({
        generation: this.currentGeneration,
        parameters: newParams,
        feedback,
        timestamp: new Date(),
        improvements
      });
      
      console.log(`🧬 Voice evolution generation ${this.currentGeneration} created:`);
      console.log(`   📊 Feedback: clarity=${feedback.clarity}, naturalness=${feedback.naturalness}, authenticity=${feedback.authenticity}, overall=${feedback.overall}`);
      console.log(`   🎛️ New parameters:`, newParams);
      console.log(`   🔄 Improvements: ${improvements.join(', ')}`);
      
      return {
        generation: this.currentGeneration,
        parameters: newParams,
        improvements,
        evolutionProgress: this.getEvolutionProgress()
      };
    }
    
    return {
      generation: this.currentGeneration,
      parameters: currentParams,
      improvements: ['No parameter changes needed'],
      evolutionProgress: this.getEvolutionProgress()
    };
  }

  /**
   * Автоматическая эволюция на основе технических метрик
   */
  autoEvolve(technicalMetrics: {
    audioQuality: number; // 0-1
    processingTime: number; // ms
    fileSize: number; // bytes
    successRate: number; // 0-1
  }) {
    console.log('🤖 Auto-evolution based on technical metrics...');
    
    const currentParams = this.getCurrentParameters();
    const newParams = { ...currentParams };
    const improvements: string[] = [];
    
    // Если качество аудио низкое - корректируем параметры
    if (technicalMetrics.audioQuality < 0.8) {
      newParams.stability += 0.01;
      newParams.similarity_boost += 0.005;
      improvements.push(`Auto-enhanced quality settings based on technical analysis`);
    }
    
    // Если время обработки слишком большое - оптимизируем
    if (technicalMetrics.processingTime > 5000) {
      newParams.use_speaker_boost = false;
      improvements.push('Disabled speaker boost to reduce processing time');
    }
    
    // Если низкий успех - возвращаемся к более консервативным настройкам
    if (technicalMetrics.successRate < 0.9) {
      newParams.stability = Math.min(1.0, newParams.stability + 0.05);
      improvements.push('Applied conservative settings for better reliability');
    }
    
    if (improvements.length > 0) {
      this.currentGeneration++;
      
      this.evolutionHistory.push({
        generation: this.currentGeneration,
        parameters: newParams,
        feedback: {
          clarity: Math.round(technicalMetrics.audioQuality * 10),
          naturalness: Math.round(technicalMetrics.successRate * 10),
          authenticity: Math.round(technicalMetrics.audioQuality * 10),
          overall: Math.round((technicalMetrics.audioQuality + technicalMetrics.successRate) * 5)
        },
        timestamp: new Date(),
        improvements
      });
      
      console.log(`🤖 Auto-evolution generation ${this.currentGeneration} completed`);
    }
    
    return this.getCurrentParameters();
  }

  /**
   * Получить прогресс эволюции
   */
  getEvolutionProgress() {
    if (this.evolutionHistory.length < 2) {
      return {
        totalGenerations: this.currentGeneration,
        overallProgress: 0,
        averageRating: this.evolutionHistory[0]?.feedback.overall || 0,
        trend: 'stable'
      };
    }
    
    const first = this.evolutionHistory[0];
    const latest = this.evolutionHistory[this.evolutionHistory.length - 1];
    const recent = this.evolutionHistory.slice(-3);
    
    const overallProgress = ((latest.feedback.overall - first.feedback.overall) / first.feedback.overall) * 100;
    const averageRating = recent.reduce((sum, gen) => sum + gen.feedback.overall, 0) / recent.length;
    
    let trend = 'stable';
    if (recent.length >= 2) {
      const recentTrend = recent[recent.length - 1].feedback.overall - recent[0].feedback.overall;
      trend = recentTrend > 0.5 ? 'improving' : recentTrend < -0.5 ? 'declining' : 'stable';
    }
    
    return {
      totalGenerations: this.currentGeneration,
      overallProgress: Math.round(overallProgress),
      averageRating: Math.round(averageRating * 10) / 10,
      trend
    };
  }

  /**
   * Получить историю эволюции
   */
  getEvolutionHistory() {
    return this.evolutionHistory.map(gen => ({
      generation: gen.generation,
      timestamp: gen.timestamp,
      feedback: gen.feedback,
      improvements: gen.improvements,
      parameters: gen.parameters
    }));
  }

  /**
   * Сброс эволюции (для экспериментов)
   */
  resetEvolution() {
    console.log('🔄 Resetting voice evolution to generation 1...');
    this.currentGeneration = 1;
    this.evolutionHistory = this.evolutionHistory.slice(0, 1);
  }
}

export const jarvisVoiceEvolution = new JarvisVoiceEvolution();