import type { Express } from "express";
import { jarvisDisciplineEngine } from "./jarvis-discipline-engine";
import { jarvisStarkPersonality } from "./jarvis-stark-personality";
import { jarvisContextMemory } from "./jarvis-context-memory";

export function registerEnhancedJarvisRoutes(app: Express) {
  
  // Enhanced JARVIS Stark Personality Routes
  app.post('/api/jarvis/stark-response', async (req, res) => {
    try {
      const { userId, context, userInput, responseType = 'analytical' } = req.body;
      
      const response = await jarvisStarkPersonality.generateStarkResponse(
        userId, 
        context, 
        userInput, 
        responseType
      );
      
      res.json(response);
    } catch (error) {
      console.error('Error generating Stark response:', error);
      res.status(500).json({ 
        message: "Sir, I'm experiencing a momentary processing delay. Perhaps we could try a different approach?",
        tone: 'analytical',
        confidence: 0.5,
        actionRequired: false
      });
    }
  });

  app.post('/api/jarvis/analyze-response-style', async (req, res) => {
    try {
      const { userId, userInput, context } = req.body;
      
      const analysis = await jarvisStarkPersonality.analyzeOptimalResponseStyle(
        userId, 
        userInput, 
        context
      );
      
      res.json(analysis);
    } catch (error) {
      console.error('Error analyzing response style:', error);
      res.status(500).json({ 
        recommendedStyle: 'analytical',
        reasoning: 'Default analytical approach selected',
        confidence: 0.5
      });
    }
  });

  app.get('/api/jarvis/proactive-insight/:userId', async (req, res) => {
    try {
      const { userId } = req.params;
      
      const insight = await jarvisStarkPersonality.generateProactiveInsight(userId);
      
      if (insight) {
        res.json({ hasInsight: true, insight });
      } else {
        res.json({ hasInsight: false, message: "No immediate insights detected" });
      }
    } catch (error) {
      console.error('Error generating proactive insight:', error);
      res.status(500).json({ 
        hasInsight: false, 
        message: "Insight analysis temporarily unavailable" 
      });
    }
  });

  app.post('/api/jarvis/strategic-recommendation', async (req, res) => {
    try {
      const { userId, challenge } = req.body;
      
      const recommendation = await jarvisStarkPersonality.generateStrategicRecommendation(
        userId, 
        challenge
      );
      
      res.json(recommendation);
    } catch (error) {
      console.error('Error generating strategic recommendation:', error);
      res.status(500).json({ 
        message: "Strategic analysis temporarily unavailable",
        tone: 'analytical',
        confidence: 0.5,
        actionRequired: false
      });
    }
  });

  // Enhanced Discipline Engine Routes
  app.post('/api/jarvis/predictive-intervention', async (req, res) => {
    try {
      const { userId } = req.body;
      
      const intervention = await jarvisDisciplineEngine.predictAndPreventRegimeViolation(userId);
      
      if (intervention) {
        res.json({ 
          requiresIntervention: true, 
          intervention,
          riskLevel: 'high'
        });
      } else {
        res.json({ 
          requiresIntervention: false,
          message: "Regime compliance within optimal parameters",
          riskLevel: 'low'
        });
      }
    } catch (error) {
      console.error('Error in predictive intervention:', error);
      res.status(500).json({ 
        requiresIntervention: false,
        message: "Predictive analysis temporarily unavailable"
      });
    }
  });

  app.post('/api/jarvis/voice-motivation-analysis', async (req, res) => {
    try {
      const { voiceMetrics } = req.body;
      
      if (!voiceMetrics || typeof voiceMetrics !== 'object') {
        return res.status(400).json({ message: "Valid voice metrics required" });
      }
      
      const analysis = await jarvisDisciplineEngine.analyzeVoiceForMotivationState(voiceMetrics);
      
      res.json(analysis);
    } catch (error) {
      console.error('Error analyzing voice for motivation:', error);
      res.status(500).json({ 
        energy: 0.5,
        confidence: 0.5,
        stress: 0.5,
        emotionalState: 'neutral',
        recommendedApproach: 'balanced'
      });
    }
  });

  app.post('/api/jarvis/adapt-motivation', async (req, res) => {
    try {
      const { userId, voiceState, context } = req.body;
      
      const intervention = await jarvisDisciplineEngine.adaptMotivationStyle(
        userId, 
        voiceState, 
        context
      );
      
      res.json(intervention);
    } catch (error) {
      console.error('Error adapting motivation style:', error);
      res.status(500).json({
        type: 'push',
        message: "Standard motivation protocol activated",
        intensity: 'firm',
        followUpAction: 'continue_current_task',
        timeToComplete: 30
      });
    }
  });

  app.post('/api/jarvis/intelligent-reminder', async (req, res) => {
    try {
      const { userId, task } = req.body;
      
      if (!task || typeof task !== 'object') {
        return res.status(400).json({ message: "Valid task object required" });
      }
      
      const reminder = await jarvisDisciplineEngine.generateIntelligentReminder(userId, task);
      
      res.json(reminder);
    } catch (error) {
      console.error('Error generating intelligent reminder:', error);
      res.status(500).json({
        message: "Sir, you have a task pending attention",
        timing: 'immediate',
        style: 'gentle'
      });
    }
  });

  app.post('/api/jarvis/procrastination-analysis', async (req, res) => {
    try {
      const { userId, userInput } = req.body;
      
      const intervention = await jarvisDisciplineEngine.analyzeProcrastinationPattern(
        userId, 
        userInput
      );
      
      res.json(intervention);
    } catch (error) {
      console.error('Error analyzing procrastination pattern:', error);
      res.status(500).json({
        type: 'push',
        message: "Focus protocol recommended",
        intensity: 'firm',
        followUpAction: 'immediate_focus',
        timeToComplete: 25
      });
    }
  });

  app.post('/api/jarvis/performance-demand', async (req, res) => {
    try {
      const { userId, context } = req.body;
      
      const demand = await jarvisDisciplineEngine.generatePerformanceDemand(userId, context);
      
      res.json(demand);
    } catch (error) {
      console.error('Error generating performance demand:', error);
      res.status(500).json({
        type: 'push',
        message: "Performance levels are optimal. Continue with current trajectory.",
        intensity: 'firm',
        followUpAction: 'maintain_pace',
        timeToComplete: 30
      });
    }
  });

  app.post('/api/jarvis/accountability-challenge', async (req, res) => {
    try {
      const { userId, challenge, deadline, stakes } = req.body;
      
      await jarvisDisciplineEngine.setAccountabilityChallenge(
        userId, 
        challenge, 
        new Date(deadline), 
        stakes
      );
      
      res.json({ 
        success: true, 
        message: `Challenge "${challenge}" set with deadline ${deadline}` 
      });
    } catch (error) {
      console.error('Error setting accountability challenge:', error);
      res.status(500).json({ 
        success: false, 
        message: "Challenge setting temporarily unavailable" 
      });
    }
  });

  app.get('/api/jarvis/accountability-check/:userId', async (req, res) => {
    try {
      const { userId } = req.params;
      
      const accountabilityResult = await jarvisDisciplineEngine.enforceAccountability(userId);
      
      if (accountabilityResult) {
        res.json({ 
          requiresAccountability: true, 
          intervention: accountabilityResult 
        });
      } else {
        res.json({ 
          requiresAccountability: false,
          message: "All challenges on track"
        });
      }
    } catch (error) {
      console.error('Error checking accountability:', error);
      res.status(500).json({ 
        requiresAccountability: false,
        message: "Accountability check temporarily unavailable"
      });
    }
  });

  // Context Memory Routes
  app.get('/api/jarvis/context/:userId', async (req, res) => {
    try {
      const { userId } = req.params;
      
      const context = await jarvisContextMemory.getUserContext(userId);
      
      res.json(context);
    } catch (error) {
      console.error('Error getting user context:', error);
      res.status(500).json({ message: "Context retrieval temporarily unavailable" });
    }
  });

  app.post('/api/jarvis/conversation', async (req, res) => {
    try {
      const { 
        userId, 
        userInput, 
        jarvisResponse, 
        emotionalState, 
        actionTaken, 
        context 
      } = req.body;
      
      await jarvisContextMemory.addConversation(
        userId,
        userInput,
        jarvisResponse,
        emotionalState,
        actionTaken,
        context
      );
      
      res.json({ success: true, message: "Conversation recorded" });
    } catch (error) {
      console.error('Error adding conversation:', error);
      res.status(500).json({ 
        success: false, 
        message: "Conversation recording temporarily unavailable" 
      });
    }
  });

  app.post('/api/jarvis/contextual-response', async (req, res) => {
    try {
      const { userId, userInput } = req.body;
      
      const response = await jarvisContextMemory.generateContextualResponse(userId, userInput);
      
      res.json(response);
    } catch (error) {
      console.error('Error generating contextual response:', error);
      res.status(500).json({
        response: "I'm processing your request with available context",
        confidence: 0.5,
        contextUsed: false
      });
    }
  });

  app.put('/api/jarvis/preferences/:userId', async (req, res) => {
    try {
      const { userId } = req.params;
      const { preferences } = req.body;
      
      await jarvisContextMemory.updateUserPreferences(userId, preferences);
      
      res.json({ success: true, message: "Preferences updated successfully" });
    } catch (error) {
      console.error('Error updating user preferences:', error);
      res.status(500).json({ 
        success: false, 
        message: "Preference update temporarily unavailable" 
      });
    }
  });

  app.post('/api/jarvis/goal', async (req, res) => {
    try {
      const { userId, goal } = req.body;
      
      await jarvisContextMemory.updateUserGoals(userId, goal);
      
      res.json({ success: true, message: `Goal "${goal.title}" updated successfully` });
    } catch (error) {
      console.error('Error updating user goal:', error);
      res.status(500).json({ 
        success: false, 
        message: "Goal update temporarily unavailable" 
      });
    }
  });

  app.get('/api/jarvis/relevant-context/:userId', async (req, res) => {
    try {
      const { userId } = req.params;
      const { situationType = 'general' } = req.query;
      
      const relevantContext = await jarvisContextMemory.getRelevantContext(
        userId, 
        situationType as string
      );
      
      res.json(relevantContext);
    } catch (error) {
      console.error('Error getting relevant context:', error);
      res.status(500).json({
        insights: [],
        recommendations: [],
        contextSummary: "Context analysis temporarily unavailable"
      });
    }
  });

  // Personality Configuration Routes
  app.get('/api/jarvis/personality-config', async (req, res) => {
    try {
      const config = jarvisStarkPersonality.getPersonalityConfig();
      res.json(config);
    } catch (error) {
      console.error('Error getting personality config:', error);
      res.status(500).json({ 
        message: "Personality configuration temporarily unavailable" 
      });
    }
  });

  app.put('/api/jarvis/personality-config', async (req, res) => {
    try {
      const { config } = req.body;
      
      jarvisStarkPersonality.updatePersonalityConfig(config);
      
      res.json({ 
        success: true, 
        message: "Personality configuration updated",
        newConfig: jarvisStarkPersonality.getPersonalityConfig()
      });
    } catch (error) {
      console.error('Error updating personality config:', error);
      res.status(500).json({ 
        success: false, 
        message: "Personality update temporarily unavailable" 
      });
    }
  });

  // Comprehensive JARVIS Analysis Route
  app.post('/api/jarvis/comprehensive-analysis', async (req, res) => {
    try {
      const { userId, userInput, voiceMetrics, context } = req.body;
      
      // Parallel analysis for maximum efficiency
      const [
        starkResponse,
        voiceAnalysis,
        procrastinationAnalysis,
        proactiveInsight,
        relevantContext
      ] = await Promise.all([
        jarvisStarkPersonality.generateStarkResponse(userId, context, userInput, 'analytical'),
        voiceMetrics ? jarvisDisciplineEngine.analyzeVoiceForMotivationState(voiceMetrics) : null,
        jarvisDisciplineEngine.analyzeProcrastinationPattern(userId, userInput),
        jarvisStarkPersonality.generateProactiveInsight(userId),
        jarvisContextMemory.getRelevantContext(userId, 'analysis')
      ]);
      
      res.json({
        starkResponse,
        voiceAnalysis,
        procrastinationAnalysis,
        proactiveInsight,
        relevantContext,
        timestamp: new Date().toISOString(),
        analysisComplete: true
      });
    } catch (error) {
      console.error('Error in comprehensive analysis:', error);
      res.status(500).json({
        message: "Comprehensive analysis temporarily unavailable",
        analysisComplete: false
      });
    }
  });
}