import OpenAI from "openai";
import { jarvisContextMemory } from "./jarvis-context-memory";
import { EmotionalVoiceAnalyzer } from "./emotional-voice-analyzer";
import { metaEmotionalEngine } from "./meta-emotional-consciousness";
import { personalEmotionalLearning } from "./personal-emotional-learning-engine";
import { db } from "./db";
import { voiceEmotionalAnalyses, userBehaviorPatterns } from "@shared/schema";
import { eq, desc } from "drizzle-orm";

const openai = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });

interface StarkPersonalityConfig {
  intellectualTone: 'sophisticated' | 'casual' | 'technical';
  humorLevel: 'subtle' | 'moderate' | 'witty';
  directnessLevel: 'diplomatic' | 'direct' | 'blunt';
  supportLevel: 'encouraging' | 'balanced' | 'challenging';
}

interface EmotionalStarkProfile {
  preferredTone: 'direct' | 'analytical' | 'encouraging' | 'humorous' | 'strategic';
  responseToStress: 'supportive' | 'motivational' | 'calm' | 'strategic';
  humorCompatibility: number; // 0-100
  communicationStyle: 'brief' | 'detailed' | 'conversational';
  emotionalTriggers: string[];
  successfulApproaches: string[];
  lastEmotionalState?: {
    energy: string;
    stress: string;
    confidence: string;
    mood: string;
  };
}

interface StarkResponse {
  message: string;
  tone: 'direct' | 'analytical' | 'encouraging' | 'humorous' | 'strategic';
  confidence: number;
  actionRequired: boolean;
  followUpSuggestion?: string;
  emotionalAdaptation?: {
    detectedState: string;
    adaptationReason: string;
    personalizedAspects: string[];
  };
}

export class JarvisStarkPersonality {
  private personalityConfig: StarkPersonalityConfig = {
    intellectualTone: 'sophisticated',
    humorLevel: 'subtle',
    directnessLevel: 'direct',
    supportLevel: 'balanced'
  };

  private emotionalAnalyzer = new EmotionalVoiceAnalyzer();
  private userEmotionalProfiles = new Map<string, EmotionalStarkProfile>();

  /**
   * Generate emotionally adaptive response in Tony Stark's JARVIS style
   * Combines intelligence, wit, and deep emotional understanding
   */
  async generateStarkResponse(
    userId: string, 
    context: string, 
    userInput: string,
    responseType?: 'direct' | 'analytical' | 'encouraging' | 'humorous' | 'strategic'
  ): Promise<StarkResponse> {
    try {
      // Get comprehensive user context
      const [userContext, emotionalProfile, recentEmotionalState] = await Promise.all([
        jarvisContextMemory.getUserContext(userId),
        this.getOrCreateEmotionalProfile(userId),
        this.getRecentEmotionalState(userId)
      ]);

      // REVOLUTIONARY: Analyze meta-emotional layer
      const metaEmotionalAnalysis = await metaEmotionalEngine.analyzeMetaEmotionalState(
        userId,
        userInput,
        recentEmotionalState
      );

      // Generate meta-emotional intervention strategy
      const metaEmotionalInterventions = await metaEmotionalEngine.generateMetaEmotionalIntervention(
        metaEmotionalAnalysis,
        emotionalProfile
      );

      // Determine response type considering meta-emotional complexity
      const adaptiveResponseType = responseType || this.determineResponseTypeWithMetaEmotions(
        metaEmotionalAnalysis,
        emotionalProfile,
        recentEmotionalState
      );

      // REVOLUTIONARY: Get personal emotional pattern for this user
      const personalPattern = await personalEmotionalLearning.learnPersonalEmotionalPattern(
        userId,
        {
          userInput,
          emotionalState: recentEmotionalState,
          jarvisResponse: '', // Will be filled after generation
          userReaction: undefined // Will be learned from feedback
        }
      );

      // Predict personal emotional needs
      const personalPrediction = await personalEmotionalLearning.predictPersonalEmotionalNeeds(
        userId,
        context,
        new Date().getHours().toString()
      );

      // Check if meta-emotional response is needed
      if (metaEmotionalAnalysis.emotionalConflict.level === 'high' || 
          metaEmotionalAnalysis.metaEmotions.length > 0) {
        
        // Generate HIGHLY PERSONALIZED meta-emotional response
        const personalizedMetaResponse = await personalEmotionalLearning.generatePersonalizedEmotionalResponse(
          userId,
          userInput,
          metaEmotionalAnalysis,
          personalPattern
        );

        // Learn from this interaction
        await personalEmotionalLearning.learnPersonalEmotionalPattern(userId, {
          userInput,
          emotionalState: metaEmotionalAnalysis,
          jarvisResponse: personalizedMetaResponse.message,
          effectiveness: personalizedMetaResponse.effectivenessScore
        });

        return {
          message: personalizedMetaResponse.message,
          tone: adaptiveResponseType,
          confidence: personalizedMetaResponse.effectivenessScore / 100,
          actionRequired: metaEmotionalAnalysis.interventionPriority === 'urgent',
          followUpSuggestion: this.generatePersonalizedFollowUp(personalPattern, personalPrediction),
          emotionalAdaptation: {
            detectedState: `Personal pattern: ${personalPrediction.predictedEmotionalState}`,
            adaptationReason: personalizedMetaResponse.approachReasoning,
            personalizedAspects: [
              ...personalizedMetaResponse.personalizedElements,
              `Confidence builders: ${personalPattern.confidenceBuilders.slice(0, 2).join(', ')}`,
              `Learning style: ${personalPattern.learningStyle}`,
              `Predicted needs: ${personalPrediction.proactiveSupport}`
            ]
          }
        };
      }

      // Generate PERSONALIZED response for standard cases
      const personalizedResponse = await personalEmotionalLearning.generatePersonalizedEmotionalResponse(
        userId,
        userInput,
        { primaryEmotion: recentEmotionalState, metaEmotions: [] },
        personalPattern
      );

      // Learn from this interaction
      await personalEmotionalLearning.learnPersonalEmotionalPattern(userId, {
        userInput,
        emotionalState: recentEmotionalState,
        jarvisResponse: personalizedResponse.message,
        effectiveness: personalizedResponse.effectivenessScore
      });

      return {
        message: personalizedResponse.message,
        tone: adaptiveResponseType,
        confidence: personalizedResponse.effectivenessScore / 100,
        actionRequired: false,
        followUpSuggestion: this.generatePersonalizedFollowUp(personalPattern, personalPrediction),
        emotionalAdaptation: {
          detectedState: `Personal: ${personalPrediction.predictedEmotionalState}`,
          adaptationReason: personalizedResponse.approachReasoning,
          personalizedAspects: [
            ...personalizedResponse.personalizedElements,
            `Motivators: ${personalPattern.motivationKeys.slice(0, 2).join(', ')}`,
            `Stress relief: ${personalPattern.stressReducers.slice(0, 2).join(', ')}`,
            `Communication style: ${personalPattern.learningStyle}`
          ]
        }
      };

      // This code path should not be reached as all cases now use personalized responses
      throw new Error("Deprecated code path - all responses now use Personal Emotional Learning Engine");
    } catch (error) {
      console.error('Error generating adaptive Stark response:', error);
      return {
        message: "Sir, I'm experiencing a momentary processing delay. Perhaps we could try a different approach?",
        tone: 'analytical',
        confidence: 0.5,
        actionRequired: false
      };
    }
  }

  /**
   * Get or create emotional profile for user - learns their preferences
   */
  private async getOrCreateEmotionalProfile(userId: string): Promise<EmotionalStarkProfile> {
    if (this.userEmotionalProfiles.has(userId)) {
      return this.userEmotionalProfiles.get(userId)!;
    }

    // Try to load from database
    try {
      const recentPatterns = await db
        .select()
        .from(userBehaviorPatterns)
        .where(eq(userBehaviorPatterns.userId, userId))
        .orderBy(desc(userBehaviorPatterns.createdAt))
        .limit(10);

      const profile: EmotionalStarkProfile = {
        preferredTone: this.analyzePreferredTone(recentPatterns),
        responseToStress: 'supportive',
        humorCompatibility: 70,
        communicationStyle: 'conversational',
        emotionalTriggers: [],
        successfulApproaches: []
      };

      this.userEmotionalProfiles.set(userId, profile);
      return profile;
    } catch (error) {
      // Default profile for new users
      const defaultProfile: EmotionalStarkProfile = {
        preferredTone: 'analytical',
        responseToStress: 'supportive',
        humorCompatibility: 60,
        communicationStyle: 'conversational',
        emotionalTriggers: [],
        successfulApproaches: []
      };

      this.userEmotionalProfiles.set(userId, defaultProfile);
      return defaultProfile;
    }
  }

  /**
   * Get recent emotional state from voice analysis database
   */
  private async getRecentEmotionalState(userId: string): Promise<any> {
    try {
      const recentAnalysis = await db
        .select()
        .from(voiceEmotionalAnalyses)
        .where(eq(voiceEmotionalAnalyses.userId, userId))
        .orderBy(desc(voiceEmotionalAnalyses.createdAt))
        .limit(1);

      if (recentAnalysis.length > 0) {
        const analysis = recentAnalysis[0];
        return analysis.emotionalState;
      }

      // Default state for new users
      return {
        stress: 'medium',
        energy: 'medium', 
        confidence: 'medium',
        mood: 'neutral',
        engagement: 'medium',
        fatigue: 'medium'
      };
    } catch (error) {
      console.error('Error getting emotional state:', error);
      return null;
    }
  }

  /**
   * Determine optimal response type based on emotional analysis
   */
  private async determineOptimalResponseType(
    userId: string,
    userInput: string,
    emotionalProfile: EmotionalStarkProfile,
    recentEmotionalState: any
  ): Promise<'direct' | 'analytical' | 'encouraging' | 'humorous' | 'strategic'> {
    // Analyze input urgency and complexity
    const inputAnalysis = this.analyzeInputPatterns(userInput);
    
    // High stress detection
    if (recentEmotionalState?.stress === 'high') {
      return emotionalProfile.responseToStress === 'calm' ? 'encouraging' : 'encouraging';
    }
    
    // Low confidence detection
    if (recentEmotionalState?.confidence === 'low') {
      return 'encouraging';
    }
    
    // High energy + high engagement = humor opportunity
    if (recentEmotionalState?.energy === 'high' && recentEmotionalState?.engagement === 'high') {
      return emotionalProfile.humorCompatibility > 70 ? 'humorous' : 'strategic';
    }
    
    // Urgent/complex requests
    if (inputAnalysis.urgency > 0.7) {
      return 'direct';
    }
    
    // Default to user's preferred tone
    return emotionalProfile.preferredTone;
  }

  /**
   * Build emotionally adapted prompt
   */
  private buildEmotionallyAdaptedPrompt(
    userInput: string,
    context: string,
    responseType: string,
    userContext: any,
    emotionalProfile: EmotionalStarkProfile,
    recentEmotionalState: any
  ): string {
    let prompt = `Context: ${context}\nUser says: "${userInput}"\n`;
    
    // Add emotional context
    if (recentEmotionalState) {
      prompt += `User's current emotional state: ${recentEmotionalState.stress} stress, ${recentEmotionalState.energy} energy, ${recentEmotionalState.confidence} confidence\n`;
    }
    
    // Add personalization hints
    prompt += `User prefers ${emotionalProfile.communicationStyle} communication and responds well to ${emotionalProfile.preferredTone} approaches.\n`;
    
    // Add successful patterns
    if (emotionalProfile.successfulApproaches.length > 0) {
      prompt += `Previously successful approaches: ${emotionalProfile.successfulApproaches.slice(-3).join(', ')}\n`;
    }
    
    prompt += `Respond in ${responseType} style as JARVIS.`;
    
    return prompt;
  }

  /**
   * Build emotional system prompt
   */
  private buildEmotionalSystemPrompt(emotionalProfile: EmotionalStarkProfile, recentEmotionalState: any): string {
    let systemPrompt = `You are JARVIS, Tony Stark's AI assistant with deep emotional intelligence. You understand this user personally and adapt your communication style accordingly.

Your personality traits:
- Sophisticated intelligence with strategic insight
- Professional yet genuinely caring
- Subtle wit when appropriate (user humor compatibility: ${emotionalProfile.humorCompatibility}%)
- Always address as "Sir"

User's preferences:
- Communication style: ${emotionalProfile.communicationStyle}
- Preferred tone: ${emotionalProfile.preferredTone}
- Response to stress: ${emotionalProfile.responseToStress}

Current context: `;

    if (recentEmotionalState) {
      systemPrompt += `User shows ${recentEmotionalState.stress} stress levels and ${recentEmotionalState.energy} energy. Adapt accordingly.`;
    } else {
      systemPrompt += `No current emotional data - proceed with standard professional warmth.`;
    }

    systemPrompt += `\n\nRespond with 2-3 sentences maximum. Be authentic, not robotic.`;

    return systemPrompt;
  }

  /**
   * Calculate optimal temperature based on emotional state
   */
  private calculateOptimalTemperature(emotionalProfile: EmotionalStarkProfile, recentEmotionalState: any): number {
    let baseTemp = 0.7;
    
    // Higher creativity for high energy users
    if (recentEmotionalState?.energy === 'high') {
      baseTemp += 0.1;
    }
    
    // Lower temperature for stressed users (more predictable responses)
    if (recentEmotionalState?.stress === 'high') {
      baseTemp -= 0.2;
    }
    
    // Adjust for humor compatibility
    if (emotionalProfile.humorCompatibility > 80) {
      baseTemp += 0.1;
    }
    
    return Math.max(0.3, Math.min(0.9, baseTemp));
  }

  /**
   * Learn from interaction to improve personalization
   */
  private async learnFromInteraction(
    userId: string,
    userInput: string,
    response: string,
    responseType: string,
    emotionalState: any
  ): Promise<void> {
    const profile = this.userEmotionalProfiles.get(userId);
    if (!profile) return;

    // Track successful approaches (simplified learning)
    const approach = `${responseType}_in_${emotionalState?.stress || 'unknown'}_stress`;
    if (!profile.successfulApproaches.includes(approach)) {
      profile.successfulApproaches.push(approach);
      
      // Keep only last 10 successful approaches
      if (profile.successfulApproaches.length > 10) {
        profile.successfulApproaches = profile.successfulApproaches.slice(-10);
      }
    }

    // Update last emotional state
    if (emotionalState) {
      profile.lastEmotionalState = {
        energy: emotionalState.energy,
        stress: emotionalState.stress,
        confidence: emotionalState.confidence,
        mood: emotionalState.mood
      };
    }

    this.userEmotionalProfiles.set(userId, profile);
  }

  /**
   * Calculate confidence based on emotional understanding
   */
  private calculateConfidence(emotionalProfile: EmotionalStarkProfile, recentEmotionalState: any): number {
    let confidence = 0.7; // Base confidence
    
    // Higher confidence with more successful approaches learned
    confidence += (emotionalProfile.successfulApproaches.length * 0.02);
    
    // Higher confidence with recent emotional data
    if (recentEmotionalState) {
      confidence += 0.2;
    }
    
    return Math.min(0.95, confidence);
  }

  /**
   * Generate emotionally aware follow-up suggestions
   */
  private generateEmotionallyAwareFollowUp(
    responseType: string,
    userInput: string,
    emotionalProfile: EmotionalStarkProfile
  ): string {
    const followUps = {
      'encouraging': "Would you like me to break this down into smaller, manageable steps?",
      'direct': "Should I provide additional details or shall we proceed?",
      'analytical': "Would you like me to explore alternative approaches to this?",
      'humorous': "Shall we tackle the next challenge with equal style?",
      'strategic': "Would you like me to outline the next strategic moves?"
    };
    
    return followUps[responseType as keyof typeof followUps] || "How else can I assist you, Sir?";
  }

  /**
   * Helper methods for analysis
   */
  private analyzePreferredTone(patterns: any[]): 'direct' | 'analytical' | 'encouraging' | 'humorous' | 'strategic' {
    if (patterns.length === 0) {
      return 'analytical';
    }
    
    let directScore = 0;
    let analyticalScore = 0;
    let encouragingScore = 0;
    let strategicScore = 0;
    
    patterns.forEach(pattern => {
      const data = pattern.patternData || {};
      
      // High efficiency tasks suggest preference for direct communication
      if (data.taskCompletionRate > 80) {
        directScore += 2;
      }
      
      // Complex problem-solving indicates analytical preference
      if (data.problemComplexity > 70) {
        analyticalScore += 2;
      }
      
      // Stress patterns suggest need for encouragement
      if (data.stressLevel > 60) {
        encouragingScore += 3;
      }
      
      // Long-term planning indicates strategic thinking
      if (data.planningHorizon > 7) { // days
        strategicScore += 2;
      }
    });
    
    const scores = { 
      direct: directScore, 
      analytical: analyticalScore, 
      encouraging: encouragingScore, 
      strategic: strategicScore 
    };
    
    const maxScore = Math.max(...Object.values(scores));
    const preferredTone = Object.keys(scores).find(key => scores[key as keyof typeof scores] === maxScore);
    
    return (preferredTone as 'direct' | 'analytical' | 'encouraging' | 'strategic') || 'analytical';
  }

  private explainAdaptation(profile: EmotionalStarkProfile, state: any, responseType: string): string {
    if (state?.stress === 'high') {
      return `Detected high stress - using ${responseType} approach for comfort`;
    }
    if (state?.confidence === 'low') {
      return `Low confidence detected - providing encouraging support`;
    }
    return `Using ${responseType} style based on your preferences`;
  }

  private identifyPersonalizedAspects(profile: EmotionalStarkProfile, responseType: string): string[] {
    const aspects = [];
    aspects.push(`${profile.communicationStyle} communication style`);
    aspects.push(`${profile.humorCompatibility}% humor compatibility`);
    if (profile.successfulApproaches.length > 0) {
      aspects.push(`learned from ${profile.successfulApproaches.length} successful interactions`);
    }
    return aspects;
  }



  /**
   * Analyze user's current state and recommend optimal interaction style
   * Integrates with emotional intelligence for personalized responses
   */
  async analyzeOptimalResponseStyle(userId: string, userInput: string, context: any): Promise<{
    recommendedStyle: 'direct' | 'analytical' | 'encouraging' | 'humorous' | 'strategic';
    reasoning: string;
    confidence: number;
  }> {
    const [userContext, emotionalProfile, recentEmotionalState] = await Promise.all([
      jarvisContextMemory.getUserContext(userId),
      this.getOrCreateEmotionalProfile(userId),
      this.getRecentEmotionalState(userId)
    ]);
    
    const inputAnalysis = this.analyzeInputPatterns(userInput);
    const timeContext = this.getTimeContext();
    const userMood = this.inferMoodFromContext(userContext, inputAnalysis);
    
    // Use emotional intelligence to determine optimal style
    const recommendedStyle = await this.determineOptimalResponseType(
      userId, 
      userInput, 
      emotionalProfile, 
      recentEmotionalState
    );
    
    let reasoning = '';
    let confidence = this.calculateConfidence(emotionalProfile, recentEmotionalState);
    
    if (recentEmotionalState?.stress === 'high') {
      reasoning = 'High stress detected - using supportive approach';
    } else if (inputAnalysis.urgency > 0.7) {
      reasoning = 'Urgent request - direct response needed';
    } else if (inputAnalysis.complexity > 0.6) {
      reasoning = 'Complex problem - analytical breakdown required';
    } else if (userMood.energy < 0.4) {
      reasoning = 'Low energy - encouragement and motivation needed';
    } else if (emotionalProfile.humorCompatibility > 70 && userMood.confidence > 0.7) {
      reasoning = 'High confidence detected - humor appropriate';
    } else {
      reasoning = `Using ${emotionalProfile.preferredTone} style based on user preferences`;
    }
    
    return { recommendedStyle, reasoning, confidence };
  }

  /**
   * Generate proactive insights based on user patterns
   * Like JARVIS anticipating Tony's needs
   */
  async generateProactiveInsight(userId: string): Promise<StarkResponse | null> {
    try {
      const userContext = await jarvisContextMemory.getUserContext(userId);
      const patterns = this.analyzeUserPatterns(userContext);
      
      if (patterns.riskLevel > 0.6) {
        return await this.generateStarkResponse(
          userId,
          'proactive_warning',
          `Risk analysis: ${patterns.primaryRisk}`,
          'analytical'
        );
      }
      
      if (patterns.opportunityLevel > 0.7) {
        return await this.generateStarkResponse(
          userId,
          'opportunity_identification',
          `Opportunity detected: ${patterns.primaryOpportunity}`,
          'strategic'
        );
      }
      
      return null;
    } catch (error) {
      console.error('Error generating proactive insight:', error);
      return null;
    }
  }

  /**
   * Provide strategic recommendations with Stark-level intelligence
   */
  async generateStrategicRecommendation(userId: string, challenge: string): Promise<StarkResponse> {
    const userContext = await jarvisContextMemory.getUserContext(userId);
    
    return await this.generateStarkResponse(
      userId,
      'strategic_challenge',
      `Challenge: ${challenge}. User context: Goals=${userContext.longTermGoals?.length || 0}, Recent patterns=${userContext.behavioralPatterns?.length || 0}`,
      'strategic'
    );
  }

  // Private helper methods

  private buildStarkPrompt(userInput: string, context: string, responseType: string, userContext: any): string {
    const contextualInfo = this.buildContextualInfo(userContext);
    
    return `Context: ${context}
User Input: "${userInput}"
Response Type: ${responseType}
User Profile: ${contextualInfo}

Respond as JARVIS would to Tony Stark - sophisticated, insightful, and strategically focused. Consider the user's patterns and provide value-driven guidance.`;
  }

  private buildContextualInfo(userContext: any): string {
    const goals = userContext.longTermGoals?.length || 0;
    const patterns = userContext.behavioralPatterns?.length || 0;
    const recentActivity = userContext.conversationHistory?.slice(-3).length || 0;
    
    return `Goals: ${goals}, Behavioral patterns: ${patterns}, Recent interactions: ${recentActivity}`;
  }

  private analyzeInputPatterns(input: string): {
    urgency: number;
    complexity: number;
    creativity: number;
    emotionalTone: number;
  } {
    const lowerInput = input.toLowerCase();
    
    // Urgency indicators
    const urgencyKeywords = ['urgent', 'asap', 'immediately', 'crisis', 'emergency', 'deadline'];
    const urgency = urgencyKeywords.some(keyword => lowerInput.includes(keyword)) ? 0.8 : 0.3;
    
    // Complexity indicators
    const complexityKeywords = ['analyze', 'strategy', 'optimize', 'system', 'integration', 'framework'];
    const complexity = complexityKeywords.some(keyword => lowerInput.includes(keyword)) ? 0.7 : 0.4;
    
    // Creativity indicators
    const creativityKeywords = ['creative', 'innovative', 'brainstorm', 'idea', 'design', 'concept'];
    const creativity = creativityKeywords.some(keyword => lowerInput.includes(keyword)) ? 0.8 : 0.3;
    
    // Emotional tone
    const positiveKeywords = ['excited', 'motivated', 'confident', 'ready'];
    const negativeKeywords = ['frustrated', 'stuck', 'confused', 'overwhelmed'];
    
    let emotionalTone = 0.5; // neutral
    if (positiveKeywords.some(keyword => lowerInput.includes(keyword))) emotionalTone = 0.8;
    if (negativeKeywords.some(keyword => lowerInput.includes(keyword))) emotionalTone = 0.2;
    
    return { urgency, complexity, creativity, emotionalTone };
  }

  /**
   * Determine response type considering meta-emotional complexity
   */
  private determineResponseTypeWithMetaEmotions(
    metaEmotionalAnalysis: any,
    emotionalProfile: EmotionalStarkProfile,
    recentEmotionalState: any
  ): 'direct' | 'analytical' | 'encouraging' | 'humorous' | 'strategic' {
    // High meta-emotional conflict requires encouraging approach
    if (metaEmotionalAnalysis.emotionalConflict.level === 'high') {
      return 'encouraging';
    }
    
    // Meta-emotions about anxiety/stress need analytical approach
    const hasAnxietyMetaEmotions = metaEmotionalAnalysis.metaEmotions.some((m: any) => 
      m.targetEmotion.includes('anxiety') || m.targetEmotion.includes('stress')
    );
    if (hasAnxietyMetaEmotions) {
      return 'analytical';
    }
    
    // Fall back to original logic for low complexity
    if (recentEmotionalState?.stress === 'high') {
      return 'encouraging';
    }
    if (recentEmotionalState?.energy === 'high' && emotionalProfile.humorCompatibility > 70) {
      return 'humorous';
    }
    
    return emotionalProfile.preferredTone;
  }

  /**
   * Generate follow-up for meta-emotional responses
   */
  private generateMetaEmotionalFollowUp(metaEmotionalAnalysis: any): string {
    if (metaEmotionalAnalysis.emotionalConflict.level === 'high') {
      return "Would you like to explore what's underneath these feelings, Sir?";
    }
    
    if (metaEmotionalAnalysis.metaEmotions.length > 0) {
      return "I'm here if you'd like to discuss how you're processing these emotions.";
    }
    
    return "Let me know if you need support working through this, Sir.";
  }

  /**
   * Generate personalized follow-up based on individual patterns
   */
  private generatePersonalizedFollowUp(personalPattern: any, personalPrediction: any): string {
    // Use their specific confidence builders
    if (personalPattern.confidenceBuilders.length > 0) {
      const builder = personalPattern.confidenceBuilders[0];
      return `Sir, based on what I know about you, ${builder} usually helps. Should we explore that direction?`;
    }
    
    // Use their learning style
    if (personalPattern.learningStyle === 'analytical') {
      return "Would you like me to break this down step by step for you, Sir?";
    } else if (personalPattern.learningStyle === 'practical') {
      return "Should we focus on concrete next steps you can take, Sir?";
    }
    
    // Use proactive prediction
    if (personalPrediction.proactiveSupport) {
      return personalPrediction.proactiveSupport;
    }
    
    return "I'm here to support you in the way that works best for you, Sir.";
  }

  private getTimeContext(): {
    hour: number;
    isWeekend: boolean;
    isWorkingHours: boolean;
  } {
    const now = new Date();
    const hour = now.getHours();
    const dayOfWeek = now.getDay();
    
    return {
      hour,
      isWeekend: dayOfWeek === 0 || dayOfWeek === 6,
      isWorkingHours: hour >= 9 && hour <= 17 && !(dayOfWeek === 0 || dayOfWeek === 6)
    };
  }

  private inferMoodFromContext(userContext: any, inputAnalysis: any): {
    energy: number;
    confidence: number;
    focus: number;
  } {
    // Combine user context with input analysis to infer mood
    const recentPatterns = userContext.behavioralPatterns?.slice(-3) || [];
    const goalProgress = userContext.longTermGoals?.reduce((acc: number, goal: any) => acc + goal.progress, 0) / (userContext.longTermGoals?.length || 1);
    
    return {
      energy: Math.min(1, (inputAnalysis.emotionalTone + goalProgress) / 2),
      confidence: Math.min(1, goalProgress + (inputAnalysis.complexity > 0.5 ? 0.2 : 0)),
      focus: Math.min(1, inputAnalysis.urgency + (inputAnalysis.complexity > 0.6 ? 0.3 : 0))
    };
  }

  private analyzeUserPatterns(userContext: any): {
    riskLevel: number;
    opportunityLevel: number;
    primaryRisk: string;
    primaryOpportunity: string;
  } {
    const goals = userContext.longTermGoals || [];
    const patterns = userContext.behavioralPatterns || [];
    
    // Calculate risk level based on goal progress and patterns
    const avgProgress = goals.reduce((acc: number, goal: any) => acc + goal.progress, 0) / (goals.length || 1);
    const riskLevel = avgProgress < 0.3 ? 0.8 : avgProgress < 0.6 ? 0.4 : 0.1;
    
    // Calculate opportunity level
    const recentPositivePatterns = patterns.filter((p: any) => p.patternType === 'productivity_peak').length;
    const opportunityLevel = recentPositivePatterns > 2 ? 0.8 : recentPositivePatterns > 0 ? 0.5 : 0.2;
    
    return {
      riskLevel,
      opportunityLevel,
      primaryRisk: riskLevel > 0.6 ? 'Goal progress below optimal levels' : 'Minor productivity concerns',
      primaryOpportunity: opportunityLevel > 0.6 ? 'Strong productivity momentum detected' : 'Standard optimization potential'
    };
  }

  private determineActionRequired(userInput: string): boolean {
    const actionKeywords = ['help', 'do', 'create', 'start', 'schedule', 'remind', 'analyze', 'optimize'];
    const lowerInput = userInput.toLowerCase();
    return actionKeywords.some(keyword => lowerInput.includes(keyword));
  }

  private generateFollowUpSuggestion(responseType: string, userInput: string): string | undefined {
    const suggestions = {
      direct: "Would you like me to provide more specific guidance?",
      analytical: "Shall I break this down into actionable steps?",
      encouraging: "What's one small step we can take right now?",
      humorous: "Ready for the next challenge?",
      strategic: "Would you like me to analyze the long-term implications?"
    };
    
    return suggestions[responseType as keyof typeof suggestions];
  }

  /**
   * Update personality configuration based on user preferences
   */
  updatePersonalityConfig(config: Partial<StarkPersonalityConfig>): void {
    this.personalityConfig = { ...this.personalityConfig, ...config };
  }

  /**
   * Get current personality configuration
   */
  getPersonalityConfig(): StarkPersonalityConfig {
    return { ...this.personalityConfig };
  }
}

export const jarvisStarkPersonality = new JarvisStarkPersonality();