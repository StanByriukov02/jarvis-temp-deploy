import OpenAI from "openai";
import { db } from "./db";
import { voiceEmotionalAnalyses } from "@shared/schema";
import { eq, desc } from "drizzle-orm";

const openai = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });

// Meta-emotional states - emotions about emotions
interface MetaEmotion {
  type: 'frustration_about' | 'shame_about' | 'anger_about' | 'guilt_about' | 'anxiety_about' | 'pride_in' | 'acceptance_of';
  targetEmotion: string; // the emotion this meta-emotion is about
  intensity: number; // 0-100
  impact: 'amplifying' | 'diminishing' | 'neutral'; // how it affects the primary emotion
}

interface MetaEmotionalAnalysis {
  primaryEmotion: {
    type: string;
    intensity: number;
    triggers: string[];
  };
  metaEmotions: MetaEmotion[];
  emotionalConflict: {
    level: 'low' | 'medium' | 'high';
    description: string;
    cognitiveLoad: number; // additional mental burden from meta-emotions
  };
  interventionTarget: 'primary' | 'meta' | 'both';
  interventionPriority: 'urgent' | 'important' | 'routine';
}

interface MetaEmotionalIntervention {
  step: number;
  target: 'meta_emotion' | 'primary_emotion' | 'cognitive_reframe';
  action: string;
  reasoning: string;
  expectedOutcome: string;
}

export class MetaEmotionalConsciousnessEngine {
  private metaEmotionalPatterns: Map<string, MetaEmotionalAnalysis[]> = new Map();

  /**
   * Analyze both primary emotions and meta-emotions (emotions about emotions)
   */
  async analyzeMetaEmotionalState(
    userId: string,
    userInput: string,
    voiceAnalysis?: any
  ): Promise<MetaEmotionalAnalysis> {
    try {
      // Get recent emotional context
      const recentAnalyses = await this.getRecentEmotionalHistory(userId);
      
      // Analyze for meta-emotional patterns
      const metaEmotionalPrompt = this.buildMetaEmotionalPrompt(
        userInput,
        voiceAnalysis,
        recentAnalyses
      );

      const response = await openai.chat.completions.create({
        model: "gpt-4o", // the newest OpenAI model is "gpt-4o" which was released May 13, 2024. do not change this unless explicitly requested by the user
        messages: [
          {
            role: "system",
            content: `You are an advanced meta-emotional consciousness analyzer. You detect not just emotions, but emotions ABOUT emotions - the meta-emotional layer that creates emotional conflicts.

Key meta-emotional patterns to detect:
- Frustration about being anxious ("I hate that I'm always worried")
- Shame about anger ("I shouldn't feel this angry")
- Guilt about happiness ("I don't deserve to feel good")
- Anxiety about not being motivated ("Why can't I just get started?")
- Anger about being sad ("I'm so tired of feeling down")

Respond with detailed JSON analysis including primary emotions, meta-emotions, conflict levels, and intervention priorities.`
          },
          {
            role: "user",
            content: metaEmotionalPrompt
          }
        ],
        response_format: { type: "json_object" },
        temperature: 0.3 // Lower temperature for consistent meta-emotional analysis
      });

      const analysis = JSON.parse(response.choices[0].message.content || '{}');
      const metaEmotionalAnalysis = this.validateMetaEmotionalAnalysis(analysis);
      
      // Store analysis for pattern learning
      await this.storeMetaEmotionalPattern(userId, metaEmotionalAnalysis);
      
      return metaEmotionalAnalysis;
      
    } catch (error) {
      console.error('Meta-emotional analysis failed:', error);
      return this.getFallbackMetaEmotionalAnalysis(userInput);
    }
  }

  /**
   * Generate intervention strategy for meta-emotional conflicts
   */
  async generateMetaEmotionalIntervention(
    analysis: MetaEmotionalAnalysis,
    userPersonality: any
  ): Promise<MetaEmotionalIntervention[]> {
    const interventions: MetaEmotionalIntervention[] = [];

    // High conflict requires addressing meta-emotion first
    if (analysis.emotionalConflict.level === 'high') {
      // Step 1: Normalize the meta-emotion
      interventions.push({
        step: 1,
        target: 'meta_emotion',
        action: 'normalize_meta_emotional_response',
        reasoning: 'Reduce cognitive load by normalizing the emotional response',
        expectedOutcome: 'Decreased self-criticism and emotional resistance'
      });

      // Step 2: Reframe the emotional experience
      interventions.push({
        step: 2,
        target: 'cognitive_reframe',
        action: 'reframe_emotional_value',
        reasoning: 'Help user see the adaptive value of their primary emotion',
        expectedOutcome: 'Reduced meta-emotional conflict'
      });

      // Step 3: Address primary emotion with reduced interference
      interventions.push({
        step: 3,
        target: 'primary_emotion',
        action: 'address_primary_emotion',
        reasoning: 'Now that meta-emotional interference is reduced, address the root emotion',
        expectedOutcome: 'Effective resolution of primary emotional concern'
      });
    } else {
      // Lower conflict can be addressed simultaneously
      interventions.push({
        step: 1,
        target: 'primary_emotion',
        action: 'integrated_emotional_support',
        reasoning: 'Low conflict allows for simultaneous addressing of both levels',
        expectedOutcome: 'Comprehensive emotional resolution'
      });
    }

    return interventions;
  }

  /**
   * Generate JARVIS response with meta-emotional consciousness
   */
  async generateMetaEmotionalResponse(
    userId: string,
    userInput: string,
    analysis: MetaEmotionalAnalysis,
    interventions: MetaEmotionalIntervention[]
  ): Promise<string> {
    const responsePrompt = this.buildMetaEmotionalResponsePrompt(
      userInput,
      analysis,
      interventions
    );

    try {
      const response = await openai.chat.completions.create({
        model: "gpt-4o",
        messages: [
          {
            role: "system",
            content: `You are JARVIS with advanced meta-emotional consciousness. You understand not just what users feel, but how they feel about their feelings. 

Your responses should:
1. Acknowledge both primary and meta-emotions
2. Address meta-emotional conflicts when present
3. Normalize emotional experiences
4. Guide users through multi-layered emotional resolution
5. Use Tony Stark's sophisticated yet caring communication style

Example approach:
"Sir, I notice you're frustrated about feeling anxious - that self-criticism is adding cognitive load. It's completely normal to feel frustrated when anxiety interferes with your goals. Let's first acknowledge that anxiety often shows you care deeply about outcomes. Now, with that perspective, let's address the underlying concern."
            `
          },
          {
            role: "user",
            content: responsePrompt
          }
        ],
        temperature: 0.7
      });

      return response.choices[0].message.content || "I understand this is complex, Sir. Let me help you work through this.";
      
    } catch (error) {
      console.error('Meta-emotional response generation failed:', error);
      return this.generateFallbackMetaEmotionalResponse(analysis);
    }
  }

  /**
   * Build specialized prompt for meta-emotional analysis
   */
  private buildMetaEmotionalPrompt(
    userInput: string,
    voiceAnalysis: any,
    recentAnalyses: any[]
  ): string {
    let prompt = `Analyze the following input for both primary emotions and meta-emotions (emotions about emotions):

User Input: "${userInput}"
`;

    if (voiceAnalysis) {
      prompt += `
Voice Analysis: 
- Energy: ${voiceAnalysis.energy}
- Stress: ${voiceAnalysis.stress}
- Confidence: ${voiceAnalysis.confidence}
`;
    }

    if (recentAnalyses.length > 0) {
      prompt += `
Recent Emotional Context:
${recentAnalyses.map(a => `- ${a.emotionalState?.mood || 'neutral'} (${a.createdAt})`).join('\n')}
`;
    }

    prompt += `
Look specifically for:
1. Primary emotions (what they're feeling)
2. Meta-emotions (how they feel about feeling that way)
3. Self-criticism or emotional judgment
4. Emotional resistance or acceptance
5. Cognitive load from emotional conflicts

Provide analysis in JSON format with primary emotions, meta-emotions, conflict assessment, and intervention recommendations.`;

    return prompt;
  }

  /**
   * Build response prompt with meta-emotional awareness
   */
  private buildMetaEmotionalResponsePrompt(
    userInput: string,
    analysis: MetaEmotionalAnalysis,
    interventions: MetaEmotionalIntervention[]
  ): string {
    return `Generate a JARVIS response that addresses meta-emotional complexity:

User Input: "${userInput}"

Meta-Emotional Analysis:
- Primary Emotion: ${analysis.primaryEmotion.type} (intensity: ${analysis.primaryEmotion.intensity})
- Meta-Emotions: ${analysis.metaEmotions.map(m => `${m.type} ${m.targetEmotion}`).join(', ')}
- Conflict Level: ${analysis.emotionalConflict.level}
- Cognitive Load: ${analysis.emotionalConflict.cognitiveLoad}

Intervention Strategy:
${interventions.map(i => `Step ${i.step}: ${i.action} - ${i.reasoning}`).join('\n')}

Generate a response that:
1. Acknowledges the meta-emotional complexity
2. Normalizes their emotional experience
3. Addresses the highest priority intervention
4. Uses sophisticated yet caring JARVIS tone
5. Provides actionable emotional guidance`;
  }

  /**
   * Validate and structure meta-emotional analysis
   */
  private validateMetaEmotionalAnalysis(analysis: any): MetaEmotionalAnalysis {
    return {
      primaryEmotion: {
        type: analysis.primaryEmotion?.type || 'neutral',
        intensity: Math.min(100, Math.max(0, analysis.primaryEmotion?.intensity || 50)),
        triggers: Array.isArray(analysis.primaryEmotion?.triggers) ? analysis.primaryEmotion.triggers : []
      },
      metaEmotions: Array.isArray(analysis.metaEmotions) ? analysis.metaEmotions.map((m: any) => ({
        type: m.type || 'frustration_about',
        targetEmotion: m.targetEmotion || analysis.primaryEmotion?.type || 'unknown',
        intensity: Math.min(100, Math.max(0, m.intensity || 30)),
        impact: ['amplifying', 'diminishing', 'neutral'].includes(m.impact) ? m.impact : 'amplifying'
      })) : [],
      emotionalConflict: {
        level: ['low', 'medium', 'high'].includes(analysis.emotionalConflict?.level) ? 
          analysis.emotionalConflict.level : 'medium',
        description: analysis.emotionalConflict?.description || 'Moderate emotional complexity',
        cognitiveLoad: Math.min(100, Math.max(0, analysis.emotionalConflict?.cognitiveLoad || 40))
      },
      interventionTarget: ['primary', 'meta', 'both'].includes(analysis.interventionTarget) ? 
        analysis.interventionTarget : 'both',
      interventionPriority: ['urgent', 'important', 'routine'].includes(analysis.interventionPriority) ? 
        analysis.interventionPriority : 'important'
    };
  }

  /**
   * Get recent emotional history for context
   */
  private async getRecentEmotionalHistory(userId: string): Promise<any[]> {
    try {
      return await db
        .select()
        .from(voiceEmotionalAnalyses)
        .where(eq(voiceEmotionalAnalyses.userId, userId))
        .orderBy(desc(voiceEmotionalAnalyses.createdAt))
        .limit(5);
    } catch (error) {
      return [];
    }
  }

  /**
   * Store meta-emotional pattern for learning
   */
  private async storeMetaEmotionalPattern(
    userId: string, 
    analysis: MetaEmotionalAnalysis
  ): Promise<void> {
    const userPatterns = this.metaEmotionalPatterns.get(userId) || [];
    userPatterns.push(analysis);
    
    // Keep only recent patterns (last 20)
    if (userPatterns.length > 20) {
      userPatterns.splice(0, userPatterns.length - 20);
    }
    
    this.metaEmotionalPatterns.set(userId, userPatterns);
  }

  /**
   * Fallback analysis when AI fails
   */
  private getFallbackMetaEmotionalAnalysis(userInput: string): MetaEmotionalAnalysis {
    return {
      primaryEmotion: {
        type: 'neutral',
        intensity: 50,
        triggers: []
      },
      metaEmotions: [],
      emotionalConflict: {
        level: 'low',
        description: 'Unable to perform detailed meta-emotional analysis',
        cognitiveLoad: 20
      },
      interventionTarget: 'primary',
      interventionPriority: 'routine'
    };
  }

  /**
   * Fallback response when generation fails
   */
  private generateFallbackMetaEmotionalResponse(analysis: MetaEmotionalAnalysis): string {
    if (analysis.metaEmotions.length > 0) {
      return `Sir, I can see there's complexity in how you're feeling about your emotions. Let's work through this step by step.`;
    }
    return `I understand, Sir. Let me help you process what you're experiencing.`;
  }
}

export const metaEmotionalEngine = new MetaEmotionalConsciousnessEngine();