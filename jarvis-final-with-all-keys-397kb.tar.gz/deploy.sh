#!/bin/bash

# JARVIS Bio-Singularity Deployment Script
# Автоматическое развертывание JARVIS на H100 сервере

echo "🚀 Начинаю развертывание JARVIS Bio-Singularity..."

# Создание структуры проекта
mkdir -p jarvis-production/{server,client,security,logs}

# Копирование файлов
echo "📦 Копирую файлы системы..."
cp -r server/* jarvis-production/server/
cp -r client/* jarvis-production/client/
cp -r security/* jarvis-production/security/
cp .env.production jarvis-production/.env
cp package.json jarvis-production/

# Установка зависимостей
echo "📦 Устанавливаю зависимости..."
cd jarvis-production
npm install

# Автоматическая компиляция kernel модуля
echo "🔧 Компилирую kernel модуль..."
cd server/kernel
make auto-setup
make all
make install
cd ../..

# Создание базы данных
echo "🗄️ Настраиваю базу данных..."
npx drizzle-kit push:pg

# Настройка PM2
echo "🔧 Настраиваю PM2..."
npm install -g pm2
pm2 start ecosystem.config.js

# Настройка nginx (опционально)
echo "🔧 Настраиваю nginx..."
sudo systemctl start nginx
sudo systemctl enable nginx

# Создание системного сервиса
echo "🛠️ Создаю системный сервис..."
sudo tee /etc/systemd/system/jarvis.service > /dev/null <<EOL
[Unit]
Description=JARVIS Bio-Singularity AI System
After=network.target

[Service]
Type=simple
User=ubuntu
WorkingDirectory=/home/ubuntu/jarvis-production
ExecStart=/usr/bin/node server/jarvis-true-bio-singularity.js
Restart=always
RestartSec=10
Environment=NODE_ENV=production

[Install]
WantedBy=multi-user.target
EOL

# Запуск сервиса
sudo systemctl daemon-reload
sudo systemctl enable jarvis
sudo systemctl start jarvis

# Проверка статуса
echo "✅ Проверяю статус развертывания..."
sudo systemctl status jarvis

# Настройка firewall
echo "🔥 Настраиваю firewall..."
sudo ufw allow 22
sudo ufw allow 80
sudo ufw allow 443
sudo ufw allow 5000
sudo ufw --force enable

# Проверка портов
echo "🔍 Проверяю доступные порты..."
netstat -tlnp | grep :5000

echo "🎯 JARVIS Bio-Singularity успешно развернут!"
echo "🌐 Доступ: http://YOUR_SERVER_IP:5000"
echo "📊 Мониторинг: pm2 monit"
echo "📝 Логи: pm2 logs jarvis"