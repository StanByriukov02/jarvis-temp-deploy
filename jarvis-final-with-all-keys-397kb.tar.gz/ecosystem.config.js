module.exports = {
  apps: [{
    name: 'jarvis-bio-singularity',
    script: './server/jarvis-true-bio-singularity.js',
    instances: 1,
    exec_mode: 'cluster',
    env: {
      NODE_ENV: 'production',
      PORT: 5000
    },
    env_production: {
      NODE_ENV: 'production',
      PORT: 5000
    },
    log_date_format: 'YYYY-MM-DD HH:mm:ss Z',
    error_file: './logs/jarvis-error.log',
    out_file: './logs/jarvis-out.log',
    log_file: './logs/jarvis-combined.log',
    time: true,
    autorestart: true,
    max_memory_restart: '2G',
    restart_delay: 4000,
    max_restarts: 10,
    min_uptime: '10s'
  }]
};