import { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Mic, MicOff, Volume2, Zap, Brain, MessageSquare, Target, Activity, Bell, X } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { useQuery, useMutation } from '@tanstack/react-query';
import { apiRequest } from '@/lib/queryClient';

interface VoiceInterfaceProps {
  isOpen: boolean;
  onClose: () => void;
}

interface VoiceSession {
  sessionId: string;
  context: {
    currentSystem?: string;
    userMood?: string;
    progressToday?: number;
    lastInteraction?: string;
    businessHealth?: string;
    urgentTasks?: number;
  };
}

export default function VoiceInterface({ isOpen, onClose }: VoiceInterfaceProps) {
  const [isListening, setIsListening] = useState(false);
  const [transcript, setTranscript] = useState('');
  const [aiResponse, setAiResponse] = useState('');
  const [connectionStatus, setConnectionStatus] = useState<'connected' | 'connecting' | 'error'>('connected');
  const [recognition, setRecognition] = useState<any>(null);
  const [speechSynthesis, setSpeechSynthesis] = useState<SpeechSynthesis | null>(null);
  const [isWaitingForCommand, setIsWaitingForCommand] = useState(false);

  // Initialize voice session
  const { data: voiceSession } = useQuery<VoiceSession>({
    queryKey: ['/api/voice/session'],
    enabled: isOpen,
  });

  // Initialize speech recognition and synthesis
  useEffect(() => {
    if (typeof window !== 'undefined') {
      // Speech Recognition
      const SpeechRecognition = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;
      if (SpeechRecognition) {
        const recognition = new SpeechRecognition();
        recognition.continuous = true;
        recognition.interimResults = true;
        recognition.lang = 'en-US';
        
        recognition.onresult = (event: any) => {
          const current = event.resultIndex;
          const transcript = event.results[current][0].transcript.toLowerCase();
          setTranscript(transcript);
          
          if (event.results[current].isFinal) {
            // Check for JARVIS activation phrase
            if (transcript.includes('jarvis') || transcript.includes('hey jarvis') || transcript.includes('ok jarvis')) {
              setIsWaitingForCommand(true);
              speakJarvis('Yes sir, how may I assist you?');
              // Continue listening for the actual command
              setTimeout(() => {
                if (recognition && isListening) {
                  recognition.start();
                }
              }, 2000);
            } else if (isWaitingForCommand || transcript.includes('show') || transcript.includes('open') || transcript.includes('start')) {
              setIsWaitingForCommand(false);
              processVoiceCommand(transcript);
              setIsListening(false);
            }
          }
        };

        recognition.onerror = (event: any) => {
          console.error('Speech recognition error:', event.error);
          setConnectionStatus('error');
          setIsListening(false);
        };

        recognition.onend = () => {
          setIsListening(false);
        };

        setRecognition(recognition);
      }

      // Speech Synthesis
      if (window.speechSynthesis) {
        setSpeechSynthesis(window.speechSynthesis);
      }
    }
  }, []);

  // JARVIS voice synthesis with ElevenLabs fallback
  const speakJarvis = async (text: string) => {
    try {
      // Try ElevenLabs first
      const response = await fetch('/api/voice/text-to-speech', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ 
          text,
          voiceId: 'wDsJlOXPqcvIUKdLXjDs' // Official Jarvis voice - British Robotic Monotone
        })
      });

      const data = await response.json();
      
      if (data.useBrowserSynthesis) {
        // Fallback to browser synthesis
        useBrowserSynthesis(text);
      } else if (data.audioData) {
        // Play ElevenLabs audio
        const audio = new Audio(data.audioData);
        audio.play();
      }
    } catch (error) {
      console.error('ElevenLabs TTS error:', error);
      // Fallback to browser synthesis
      useBrowserSynthesis(text);
    }
  };

  // Browser synthesis fallback
  const useBrowserSynthesis = (text: string) => {
    if (speechSynthesis) {
      speechSynthesis.cancel();
      
      const utterance = new SpeechSynthesisUtterance(text);
      utterance.rate = 0.9;
      utterance.pitch = 0.8;
      utterance.volume = 0.9;
      
      const voices = speechSynthesis.getVoices();
      const preferredVoices = voices.filter(voice => 
        voice.lang.includes('en') && 
        (voice.name.includes('Male') || voice.name.includes('Google') || voice.name.includes('Microsoft'))
      );
      
      if (preferredVoices.length > 0) {
        utterance.voice = preferredVoices[0];
      }

      speechSynthesis.speak(utterance);
    }
  };

  // Voice command processing
  const processVoiceCommand = async (command: string) => {
    try {
      setAiResponse('Processing command...');
      speakJarvis('Processing your command, sir.');
      
      const response = await fetch('/api/voice/intelligent-command', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          command,
          sessionId: voiceSession?.sessionId || 'demo-session',
          context: voiceSession?.context || {}
        })
      });

      const data = await response.json();
      const aiResponseText = data.response || 'Command processed successfully, sir.';
      setAiResponse(aiResponseText);
      
      // JARVIS responds with voice
      speakJarvis(aiResponseText);
      
      // Execute any actions returned by AI
      if (data.action) {
        executeVoiceAction(data.action);
      }
    } catch (error) {
      console.error('Voice command processing error:', error);
      const errorMsg = 'I apologize, sir. I encountered a technical difficulty processing that command.';
      setAiResponse(errorMsg);
      speakJarvis(errorMsg);
    }
  };

  const executeVoiceAction = (action: any) => {
    switch (action.type) {
      case 'check_metrics':
        // Could navigate to metrics dashboard
        console.log('Opening metrics dashboard');
        break;
      case 'start_system':
        // Could start a transformation system
        console.log('Starting system:', action.systemId);
        break;
      case 'emergency_focus':
        // Could activate focus mode
        console.log('Activating emergency focus mode');
        break;
      case 'open_control_panel':
        // Could navigate to control panel
        console.log('Opening control panel');
        break;
      default:
        console.log('Unknown action:', action.type);
    }
  };

  const quickCommands = [
    { icon: Target, text: "Show my revenue dashboard" },
    { icon: Zap, text: "Activate Revenue Acceleration system" },
    { icon: Activity, text: "Emergency focus mode now" },
    { icon: Brain, text: "Open business intelligence panel" },
    { icon: Bell, text: "Check urgent notifications" },
    { icon: MessageSquare, text: "Schedule executive session" },
  ];

  if (!isOpen) return null;

  return (
    <AnimatePresence>
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        exit={{ opacity: 0 }}
        className="fixed inset-0 bg-black/80 backdrop-blur-sm z-50 flex items-center justify-center p-4"
        onClick={onClose}
      >
        <motion.div
          initial={{ scale: 0.9, opacity: 0 }}
          animate={{ scale: 1, opacity: 1 }}
          exit={{ scale: 0.9, opacity: 0 }}
          onClick={(e) => e.stopPropagation()}
          className="w-full max-w-2xl bg-gradient-to-br from-gray-900 to-gray-800 rounded-3xl border border-cyan-500/20 overflow-hidden"
        >
          {/* Header */}
          <div className="p-6 border-b border-cyan-500/20 bg-gradient-to-r from-gray-900/50 to-gray-800/50">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-4">
                <div className="relative">
                  <div className="w-4 h-4 rounded-full bg-cyan-400 animate-pulse" />
                  <div className="absolute inset-0 w-4 h-4 rounded-full bg-cyan-400 animate-ping opacity-20" />
                </div>
                <div>
                  <h2 className="text-2xl font-bold text-white">JARVIS Business Command</h2>
                  <p className="text-cyan-300 text-sm">AI-powered hands-free business intelligence</p>
                </div>
              </div>
              <div className="flex items-center gap-3">
                <Badge variant="outline" className="border-green-500 text-green-400 bg-green-500/10">
                  🟢 Live
                </Badge>
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={onClose}
                  className="text-white/60 hover:text-white"
                >
                  <X className="w-4 h-4" />
                </Button>
              </div>
            </div>
          </div>

          {/* Main Content */}
          <div className="p-8 text-center">
            <div className="relative mb-8">
              <motion.div
                className="w-32 h-32 mx-auto rounded-full bg-gradient-to-r from-cyan-500/20 to-blue-500/20 border-2 border-cyan-500/30 flex items-center justify-center"
                animate={{
                  scale: isListening ? 1.1 : 1,
                  boxShadow: isListening 
                    ? '0 0 40px rgba(34, 211, 238, 0.6)'
                    : '0 0 20px rgba(34, 211, 238, 0.3)',
                }}
              >
                {isListening ? (
                  <Mic className="w-8 h-8 text-cyan-400" />
                ) : (
                  <MicOff className="w-8 h-8 text-white/60" />
                )}
              </motion.div>
            </div>

            {/* Status Display */}
            <div className="mb-6">
              {isListening && isWaitingForCommand ? (
                <p className="text-orange-400 font-medium animate-pulse">JARVIS activated - Awaiting your command, sir...</p>
              ) : isListening ? (
                <p className="text-cyan-400 font-medium">Listening for "Hey JARVIS" or direct commands...</p>
              ) : (
                <p className="text-white/60">Ready for voice activation</p>
              )}
            </div>

            {/* Current Business Context */}
            <div className="grid grid-cols-3 gap-4 mb-8">
              <div className="bg-gray-800/50 rounded-xl p-4 border border-cyan-500/20">
                <div className="flex items-center gap-2 mb-2">
                  <Target className="w-4 h-4 text-cyan-400" />
                  <span className="text-sm text-cyan-300">Active System</span>
                </div>
                <p className="text-white font-medium">{voiceSession?.context?.currentSystem || 'Revenue Acceleration'}</p>
              </div>
              <div className="bg-gray-800/50 rounded-xl p-4 border border-cyan-500/20">
                <div className="flex items-center gap-2 mb-2">
                  <Activity className="w-4 h-4 text-green-400" />
                  <span className="text-sm text-green-300">Progress Today</span>
                </div>
                <p className="text-white font-medium">{voiceSession?.context?.progressToday || 78}%</p>
              </div>
              <div className="bg-gray-800/50 rounded-xl p-4 border border-cyan-500/20">
                <div className="flex items-center gap-2 mb-2">
                  <Bell className="w-4 h-4 text-yellow-400" />
                  <span className="text-sm text-yellow-300">Urgent Tasks</span>
                </div>
                <p className="text-white font-medium">{voiceSession?.context?.urgentTasks || 2}</p>
              </div>
            </div>

            {/* Transcript Display */}
            {transcript && (
              <motion.div
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                className="mb-6 p-4 bg-white/5 rounded-lg border border-white/10"
              >
                <p className="text-white/80">You said: "{transcript}"</p>
              </motion.div>
            )}

            {/* AI Response */}
            {aiResponse && (
              <motion.div
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                className="mb-6 p-4 bg-cyan-500/10 rounded-lg border border-cyan-500/20"
              >
                <p className="text-cyan-100">JARVIS: {aiResponse}</p>
              </motion.div>
            )}

            {/* Voice Controls */}
            <div className="flex justify-center gap-4 mb-8">
              <Button
                onClick={() => {
                  if (!isListening && recognition) {
                    setIsListening(true);
                    setTranscript('');
                    setAiResponse('');
                    recognition.start();
                    speakJarvis('Yes sir, I am listening.');
                  } else if (isListening && recognition) {
                    setIsListening(false);
                    recognition.stop();
                    speakJarvis('Voice input stopped, sir.');
                  }
                }}
                size="lg"
                className={`${
                  isListening 
                    ? 'bg-red-500 hover:bg-red-600' 
                    : 'bg-cyan-500 hover:bg-cyan-600'
                } text-white shadow-lg`}
                disabled={!recognition}
              >
                {isListening ? (
                  <>
                    <MicOff className="w-5 h-5 mr-2" />
                    Stop Listening
                  </>
                ) : (
                  <>
                    <Mic className="w-5 h-5 mr-2" />
                    Activate Voice Command
                  </>
                )}
              </Button>
              
              {/* Voice Test Button */}
              <Button
                onClick={() => speakJarvis('Voice synthesis system operational, sir. How may I assist you today?')}
                variant="outline"
                size="lg"
                className="border-cyan-500/50 text-cyan-400 hover:bg-cyan-500/10"
                disabled={!speechSynthesis}
              >
                <Volume2 className="w-5 h-5 mr-2" />
                Test Voice
              </Button>
            </div>

            {/* Quick Commands */}
            <div className="space-y-3">
              <p className="text-white/60 text-sm">Executive Quick Commands:</p>
              <div className="grid gap-2">
                {quickCommands.map((command, index) => (
                  <Button
                    key={index}
                    variant="outline"
                    onClick={() => processVoiceCommand(command.text)}
                    className="justify-start border-white/20 text-white hover:bg-white/10"
                  >
                    <command.icon className="w-4 h-4 mr-3" />
                    "{command.text}"
                  </Button>
                ))}
              </div>
            </div>
          </div>
        </motion.div>
      </motion.div>
    </AnimatePresence>
  );
}