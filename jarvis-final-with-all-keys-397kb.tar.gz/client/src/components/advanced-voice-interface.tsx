import { useState } from 'react';
import { Mic, MicOff, Volume2, VolumeX, Brain, Zap } from 'lucide-react';
import { Button } from '@/components/ui/button';

export function AdvancedVoiceInterface() {
  const [isListening, setIsListening] = useState(false);
  const [isMuted, setIsMuted] = useState(false);
  const [isProcessing, setIsProcessing] = useState(false);

  const toggleListening = () => {
    setIsListening(!isListening);
    if (!isListening) {
      setIsProcessing(true);
      setTimeout(() => setIsProcessing(false), 2000);
    }
  };

  const toggleMute = () => {
    setIsMuted(!isMuted);
  };

  return (
    <div className="fixed bottom-20 right-4 z-50">
      <div className="bg-gray-900 rounded-xl p-4 shadow-xl border border-gray-700">
        <div className="flex items-center space-x-3">
          <Button
            variant="ghost"
            size="icon"
            onClick={toggleListening}
            className={`rounded-full ${isListening ? 'bg-red-500 text-white' : 'text-gray-400'}`}
          >
            {isListening ? <MicOff className="w-5 h-5" /> : <Mic className="w-5 h-5" />}
          </Button>
          
          <Button
            variant="ghost"
            size="icon"
            onClick={toggleMute}
            className={`rounded-full ${isMuted ? 'text-red-400' : 'text-gray-400'}`}
          >
            {isMuted ? <VolumeX className="w-5 h-5" /> : <Volume2 className="w-5 h-5" />}
          </Button>

          <div className="flex items-center space-x-2">
            <Brain className={`w-5 h-5 ${isProcessing ? 'text-orange-400 animate-pulse' : 'text-gray-400'}`} />
            <span className="text-sm text-gray-400">
              {isProcessing ? 'Processing...' : 'Ready'}
            </span>
          </div>
        </div>

        {isListening && (
          <div className="mt-3 flex items-center space-x-2">
            <Zap className="w-4 h-4 text-orange-400" />
            <div className="flex space-x-1">
              {[1, 2, 3, 4, 5].map((i) => (
                <div
                  key={i}
                  className="w-2 h-6 bg-orange-400 rounded-full animate-pulse"
                  style={{ animationDelay: `${i * 0.1}s` }}
                />
              ))}
            </div>
            <span className="text-xs text-gray-400">Listening...</span>
          </div>
        )}
      </div>
    </div>
  );
}