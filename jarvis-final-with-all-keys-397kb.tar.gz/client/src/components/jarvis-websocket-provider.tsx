import React, { createContext, useContext, memo } from 'react';
import { useJarvisWebSocket } from '@/hooks/use-jarvis-websocket';

interface JarvisWebSocketContextType {
  data: any;
  isConnected: boolean;
  error: string | null;
  reconnect: () => void;
}

const JarvisWebSocketContext = createContext<JarvisWebSocketContextType | null>(null);

export const useJarvisWebSocketContext = () => {
  const context = useContext(JarvisWebSocketContext);
  if (!context) {
    throw new Error('useJarvisWebSocketContext must be used within JarvisWebSocketProvider');
  }
  return context;
};

interface JarvisWebSocketProviderProps {
  children: React.ReactNode;
}

export const JarvisWebSocketProvider = memo(({ children }: JarvisWebSocketProviderProps) => {
  const webSocketData = useJarvisWebSocket();
  
  return (
    <JarvisWebSocketContext.Provider value={webSocketData}>
      {children}
    </JarvisWebSocketContext.Provider>
  );
});

JarvisWebSocketProvider.displayName = 'JarvisWebSocketProvider';