import { useEffect, useRef, useState } from 'react';
import { motion } from 'framer-motion';

interface QuantumNeuralGridProps {
  userState?: 'exploring' | 'focused' | 'breakthrough' | 'mastery' | 'new';
  intensity?: number;
  theme?: 'discovery' | 'creation';
  responseLevel?: number;
}

export default function QuantumNeuralGrid({ 
  userState = 'exploring',
  intensity = 0.8,
  theme = 'discovery',
  responseLevel = 0.7
}: QuantumNeuralGridProps) {
  const gridRef = useRef<HTMLDivElement>(null);
  const [mousePos, setMousePos] = useState({ x: 0, y: 0 });
  const [gridNodes, setGridNodes] = useState<Array<{id: number, x: number, y: number, energy: number, connections: number[]}>>([]);

  const baseColor = theme === 'discovery' ? '#00e5ff' : '#ff9500';
  const secondaryColor = theme === 'discovery' ? '#0091ea' : '#ff6d00';

  useEffect(() => {
    // Generate intelligent grid pattern
    const nodes = [];
    const gridSize = userState === 'breakthrough' ? 12 : userState === 'mastery' ? 15 : 10;
    
    for (let i = 0; i < gridSize; i++) {
      for (let j = 0; j < gridSize; j++) {
        const id = i * gridSize + j;
        const x = (i / (gridSize - 1)) * 100;
        const y = (j / (gridSize - 1)) * 100;
        const energy = Math.random() * responseLevel + 0.3;
        
        // Create organic connections based on proximity and energy
        const connections = [];
        const connectionRadius = userState === 'breakthrough' ? 2.5 : 1.8;
        
        for (let k = 0; k < gridSize * gridSize; k++) {
          const kx = Math.floor(k / gridSize);
          const ky = k % gridSize;
          const distance = Math.sqrt((i - kx) ** 2 + (j - ky) ** 2);
          
          if (distance > 0 && distance <= connectionRadius && Math.random() > 0.4) {
            connections.push(k);
          }
        }
        
        nodes.push({ id, x, y, energy, connections });
      }
    }
    
    setGridNodes(nodes);
  }, [userState, responseLevel]);

  useEffect(() => {
    const handleMouseMove = (e: MouseEvent) => {
      if (gridRef.current) {
        const rect = gridRef.current.getBoundingClientRect();
        setMousePos({
          x: ((e.clientX - rect.left) / rect.width) * 100,
          y: ((e.clientY - rect.top) / rect.height) * 100
        });
      }
    };

    window.addEventListener('mousemove', handleMouseMove);
    return () => window.removeEventListener('mousemove', handleMouseMove);
  }, []);

  return (
    <div 
      ref={gridRef}
      className="fixed inset-0 -z-10 pointer-events-none overflow-hidden"
      style={{ opacity: intensity }}
    >
      {/* Dynamic quantum field background */}
      <div className="absolute inset-0">
        <div 
          className={`absolute inset-0 bg-gradient-radial transition-all duration-1000 ${
            theme === 'discovery' 
              ? 'from-cyan-900/20 via-blue-950/10 to-slate-950/30' 
              : 'from-orange-900/20 via-amber-950/10 to-slate-950/30'
          }`}
          style={{
            background: `radial-gradient(circle at ${mousePos.x}% ${mousePos.y}%, ${baseColor}20 0%, transparent 50%)`
          }}
        />
      </div>

      {/* Neural grid nodes */}
      <svg className="absolute inset-0 w-full h-full">
        <defs>
          <filter id="quantum-glow">
            <feGaussianBlur stdDeviation="2" result="coloredBlur"/>
            <feMerge>
              <feMergeNode in="coloredBlur"/>
              <feMergeNode in="SourceGraphic"/>
            </feMerge>
          </filter>
          
          <radialGradient id="nodeGradient" cx="50%" cy="50%" r="50%">
            <stop offset="0%" stopColor={baseColor} stopOpacity="0.8"/>
            <stop offset="100%" stopColor={baseColor} stopOpacity="0"/>
          </radialGradient>
        </defs>

        {/* Connection lines with quantum effects */}
        {gridNodes.map(node => 
          node.connections.map(connectionId => {
            const connectedNode = gridNodes.find(n => n.id === connectionId);
            if (!connectedNode) return null;
            
            const distance = Math.sqrt(
              (node.x - mousePos.x) ** 2 + (node.y - mousePos.y) ** 2
            ) / 100;
            
            const mouseInfluence = Math.max(0, 1 - distance * 2);
            const lineOpacity = (node.energy + connectedNode.energy) / 2 * (0.2 + mouseInfluence * 0.6);
            const lineWidth = 1 + mouseInfluence * 2;
            
            return (
              <line
                key={`${node.id}-${connectionId}`}
                x1={`${node.x}%`}
                y1={`${node.y}%`}
                x2={`${connectedNode.x}%`}
                y2={`${connectedNode.y}%`}
                stroke={baseColor}
                strokeWidth={lineWidth}
                strokeOpacity={lineOpacity}
                filter="url(#quantum-glow)"
              >
                <animate
                  attributeName="stroke-opacity"
                  values={`${lineOpacity};${lineOpacity * 1.5};${lineOpacity}`}
                  dur={`${2 + Math.random() * 2}s`}
                  repeatCount="indefinite"
                />
              </line>
            );
          })
        )}

        {/* Grid nodes with quantum behavior */}
        {gridNodes.map(node => {
          const distance = Math.sqrt(
            (node.x - mousePos.x) ** 2 + (node.y - mousePos.y) ** 2
          ) / 100;
          
          const mouseInfluence = Math.max(0, 1 - distance * 1.5);
          const nodeSize = (3 + mouseInfluence * 5) * node.energy;
          const nodeOpacity = 0.4 + mouseInfluence * 0.6 + node.energy * 0.3;
          
          return (
            <g key={node.id}>
              {/* Outer quantum field */}
              <circle
                cx={`${node.x}%`}
                cy={`${node.y}%`}
                r={nodeSize * 2}
                fill="url(#nodeGradient)"
                opacity={nodeOpacity * 0.3}
              >
                <animate
                  attributeName="r"
                  values={`${nodeSize * 1.5};${nodeSize * 2.5};${nodeSize * 1.5}`}
                  dur={`${3 + Math.random() * 2}s`}
                  repeatCount="indefinite"
                />
              </circle>
              
              {/* Core node */}
              <circle
                cx={`${node.x}%`}
                cy={`${node.y}%`}
                r={nodeSize}
                fill={baseColor}
                opacity={nodeOpacity}
                filter="url(#quantum-glow)"
              >
                <animate
                  attributeName="opacity"
                  values={`${nodeOpacity};${Math.min(nodeOpacity * 1.4, 1)};${nodeOpacity}`}
                  dur={`${1.5 + Math.random()}s`}
                  repeatCount="indefinite"
                />
              </circle>
            </g>
          );
        })}
      </svg>

      {/* Quantum energy streams */}
      <div className="absolute inset-0">
        {userState === 'breakthrough' && (
          <>
            {[...Array(6)].map((_, i) => (
              <motion.div
                key={`stream-${i}`}
                className={`absolute w-px h-full opacity-30 ${
                  theme === 'discovery' ? 'bg-cyan-400' : 'bg-orange-400'
                }`}
                style={{
                  left: `${15 + i * 14}%`,
                  background: `linear-gradient(to bottom, transparent, ${baseColor}, transparent)`
                }}
                animate={{
                  scaleY: [0.5, 1.2, 0.8, 1.1, 0.6],
                  opacity: [0.2, 0.6, 0.3, 0.7, 0.2]
                }}
                transition={{
                  duration: 3 + i * 0.5,
                  repeat: Infinity,
                  ease: "easeInOut"
                }}
              />
            ))}
          </>
        )}
      </div>

      {/* Holographic interference patterns */}
      <div className="absolute inset-0 opacity-20">
        <div 
          className="absolute inset-0"
          style={{
            background: `
              radial-gradient(circle at 20% 30%, ${baseColor}15 1px, transparent 1px),
              radial-gradient(circle at 80% 70%, ${secondaryColor}15 1px, transparent 1px),
              linear-gradient(45deg, transparent 49%, ${baseColor}10 50%, transparent 51%)
            `,
            backgroundSize: '40px 40px, 60px 60px, 80px 80px',
            animation: 'holographic-shift 8s ease-in-out infinite'
          }}
        />
      </div>
    </div>
  );
}