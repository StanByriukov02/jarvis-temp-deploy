import { useState, useEffect } from "react";
import { Smartphone, Zap, Activity, Brain, Wifi, Battery, Signal } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Switch } from "@/components/ui/switch";

// Mobile-specific JARVIS capabilities and PWA features
interface MobileCapabilities {
  deviceMotion: boolean;
  deviceOrientation: boolean;
  geolocation: boolean;
  vibration: boolean;
  notifications: boolean;
  wakeLock: boolean;
  fullscreen: boolean;
  installPrompt: boolean;
}

interface MobileSensorData {
  accelerometer: {
    x: number;
    y: number;
    z: number;
    magnitude: number;
  };
  gyroscope: {
    alpha: number;
    beta: number;
    gamma: number;
  };
  orientation: 'portrait' | 'landscape';
  batteryLevel: number;
  connectionQuality: 'excellent' | 'good' | 'fair' | 'poor';
  ambientLight: number;
}

interface MobileJarvisState {
  isEnabled: boolean;
  capabilities: MobileCapabilities;
  sensorData: MobileSensorData;
  adaptiveFeatures: {
    backgroundAnalysis: boolean;
    contextualNotifications: boolean;
    gestureControls: boolean;
    voiceActivation: boolean;
  };
  optimizations: {
    batteryOptimized: boolean;
    dataEfficient: boolean;
    performanceMode: 'high' | 'balanced' | 'battery_saver';
  };
}

interface MobileJarvisProps {
  userId: string;
  onMobileDataUpdate: (data: MobileSensorData) => void;
  onCapabilityChange: (capability: keyof MobileCapabilities, enabled: boolean) => void;
}

export function MobileJarvisIntegration({ 
  userId, 
  onMobileDataUpdate, 
  onCapabilityChange 
}: MobileJarvisProps) {
  const [mobileState, setMobileState] = useState<MobileJarvisState>({
    isEnabled: false,
    capabilities: {
      deviceMotion: false,
      deviceOrientation: false,
      geolocation: false,
      vibration: false,
      notifications: false,
      wakeLock: false,
      fullscreen: false,
      installPrompt: false
    },
    sensorData: {
      accelerometer: { x: 0, y: 0, z: 0, magnitude: 0 },
      gyroscope: { alpha: 0, beta: 0, gamma: 0 },
      orientation: 'portrait',
      batteryLevel: 100,
      connectionQuality: 'excellent',
      ambientLight: 50
    },
    adaptiveFeatures: {
      backgroundAnalysis: false,
      contextualNotifications: false,
      gestureControls: false,
      voiceActivation: false
    },
    optimizations: {
      batteryOptimized: true,
      dataEfficient: true,
      performanceMode: 'balanced'
    }
  });

  const [isInitializing, setIsInitializing] = useState(false);
  const [installPromptEvent, setInstallPromptEvent] = useState<any>(null);

  // Detect mobile capabilities on component mount
  useEffect(() => {
    detectMobileCapabilities();
    setupPWAInstallPrompt();
    initializeMobileSensors();
  }, []);

  const detectMobileCapabilities = () => {
    const capabilities: MobileCapabilities = {
      deviceMotion: 'DeviceMotionEvent' in window,
      deviceOrientation: 'DeviceOrientationEvent' in window,
      geolocation: 'geolocation' in navigator,
      vibration: 'vibrate' in navigator,
      notifications: 'Notification' in window,
      wakeLock: 'wakeLock' in navigator,
      fullscreen: 'requestFullscreen' in document.documentElement,
      installPrompt: false // Will be set when beforeinstallprompt fires
    };

    setMobileState(prev => ({
      ...prev,
      capabilities
    }));
  };

  const setupPWAInstallPrompt = () => {
    window.addEventListener('beforeinstallprompt', (e) => {
      e.preventDefault();
      setInstallPromptEvent(e);
      setMobileState(prev => ({
        ...prev,
        capabilities: {
          ...prev.capabilities,
          installPrompt: true
        }
      }));
    });
  };

  const initializeMobileSensors = async () => {
    setIsInitializing(true);

    try {
      // Request permissions for motion sensors
      if (mobileState.capabilities.deviceMotion && typeof DeviceMotionEvent !== 'undefined' && 'requestPermission' in DeviceMotionEvent) {
        const permission = await (DeviceMotionEvent as any).requestPermission();
        if (permission === 'granted') {
          setupMotionSensors();
        }
      } else if (mobileState.capabilities.deviceMotion) {
        setupMotionSensors();
      }

      // Setup orientation sensors
      if (mobileState.capabilities.deviceOrientation) {
        setupOrientationSensors();
      }

      // Setup battery monitoring
      if ('getBattery' in navigator) {
        setupBatteryMonitoring();
      }

      // Setup network monitoring
      setupNetworkMonitoring();

    } catch (error) {
      console.error('Mobile sensor initialization failed:', error);
    } finally {
      setIsInitializing(false);
    }
  };

  const setupMotionSensors = () => {
    window.addEventListener('devicemotion', (event) => {
      if (event.accelerationIncludingGravity) {
        const acc = event.accelerationIncludingGravity;
        const magnitude = Math.sqrt(
          (acc.x || 0) ** 2 + (acc.y || 0) ** 2 + (acc.z || 0) ** 2
        );

        const accelerometer = {
          x: acc.x || 0,
          y: acc.y || 0,
          z: acc.z || 0,
          magnitude
        };

        setMobileState(prev => ({
          ...prev,
          sensorData: {
            ...prev.sensorData,
            accelerometer
          }
        }));

        onMobileDataUpdate({
          ...mobileState.sensorData,
          accelerometer
        });
      }
    });
  };

  const setupOrientationSensors = () => {
    window.addEventListener('deviceorientation', (event) => {
      const gyroscope = {
        alpha: event.alpha || 0,
        beta: event.beta || 0,
        gamma: event.gamma || 0
      };

      const orientation = window.innerHeight > window.innerWidth ? 'portrait' : 'landscape';

      setMobileState(prev => ({
        ...prev,
        sensorData: {
          ...prev.sensorData,
          gyroscope,
          orientation
        }
      }));
    });
  };

  const setupBatteryMonitoring = async () => {
    try {
      const battery = await (navigator as any).getBattery();
      
      const updateBatteryInfo = () => {
        setMobileState(prev => ({
          ...prev,
          sensorData: {
            ...prev.sensorData,
            batteryLevel: Math.round(battery.level * 100)
          }
        }));
      };

      battery.addEventListener('levelchange', updateBatteryInfo);
      updateBatteryInfo();
    } catch (error) {
      console.error('Battery monitoring setup failed:', error);
    }
  };

  const setupNetworkMonitoring = () => {
    const updateConnectionQuality = () => {
      const connection = (navigator as any).connection || (navigator as any).mozConnection || (navigator as any).webkitConnection;
      let quality: 'excellent' | 'good' | 'fair' | 'poor' = 'good';

      if (connection) {
        const downlink = connection.downlink;
        if (downlink > 10) quality = 'excellent';
        else if (downlink > 1.5) quality = 'good';
        else if (downlink > 0.5) quality = 'fair';
        else quality = 'poor';
      }

      setMobileState(prev => ({
        ...prev,
        sensorData: {
          ...prev.sensorData,
          connectionQuality: quality
        }
      }));
    };

    window.addEventListener('online', updateConnectionQuality);
    window.addEventListener('offline', () => {
      setMobileState(prev => ({
        ...prev,
        sensorData: {
          ...prev.sensorData,
          connectionQuality: 'poor'
        }
      }));
    });

    updateConnectionQuality();
  };

  const enableMobileJarvis = async () => {
    setIsInitializing(true);

    try {
      // Request notification permission
      if (mobileState.capabilities.notifications) {
        const permission = await Notification.requestPermission();
        setMobileState(prev => ({
          ...prev,
          capabilities: {
            ...prev.capabilities,
            notifications: permission === 'granted'
          }
        }));
      }

      // Request geolocation permission
      if (mobileState.capabilities.geolocation) {
        navigator.geolocation.getCurrentPosition(
          () => {
            setMobileState(prev => ({
              ...prev,
              capabilities: {
                ...prev.capabilities,
                geolocation: true
              }
            }));
          },
          () => {
            setMobileState(prev => ({
              ...prev,
              capabilities: {
                ...prev.capabilities,
                geolocation: false
              }
            }));
          }
        );
      }

      // Enable background analysis through service worker
      if ('serviceWorker' in navigator) {
        await setupServiceWorkerAnalysis();
      }

      // Notify unified JARVIS engine about mobile enablement
      await fetch(`/api/jarvis/enable-mobile-sensors/${userId}`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          capabilities: mobileState.capabilities,
          deviceInfo: {
            userAgent: navigator.userAgent,
            platform: navigator.platform,
            screenSize: {
              width: window.screen.width,
              height: window.screen.height
            }
          }
        })
      });

      setMobileState(prev => ({
        ...prev,
        isEnabled: true
      }));

    } catch (error) {
      console.error('Mobile JARVIS enablement failed:', error);
    } finally {
      setIsInitializing(false);
    }
  };

  const setupServiceWorkerAnalysis = async () => {
    try {
      const registration = await navigator.serviceWorker.register('/mobile-jarvis-worker.js');
      
      // Send configuration to service worker
      if (registration.active) {
        registration.active.postMessage({
          type: 'INIT_MOBILE_ANALYSIS',
          userId,
          config: {
            analysisInterval: mobileState.optimizations.batteryOptimized ? 10000 : 5000,
            backgroundSync: true,
            adaptiveNotifications: mobileState.adaptiveFeatures.contextualNotifications
          }
        });
      }
    } catch (error) {
      console.error('Service worker setup failed:', error);
    }
  };

  const installPWA = async () => {
    if (installPromptEvent) {
      const result = await installPromptEvent.prompt();
      
      if (result.outcome === 'accepted') {
        // PWA installed successfully
        setMobileState(prev => ({
          ...prev,
          capabilities: {
            ...prev.capabilities,
            installPrompt: false
          }
        }));
      }
      
      setInstallPromptEvent(null);
    }
  };

  const toggleAdaptiveFeature = (feature: keyof typeof mobileState.adaptiveFeatures) => {
    setMobileState(prev => ({
      ...prev,
      adaptiveFeatures: {
        ...prev.adaptiveFeatures,
        [feature]: !prev.adaptiveFeatures[feature]
      }
    }));
  };

  const changePerformanceMode = (mode: 'high' | 'balanced' | 'battery_saver') => {
    setMobileState(prev => ({
      ...prev,
      optimizations: {
        ...prev.optimizations,
        performanceMode: mode,
        batteryOptimized: mode === 'battery_saver',
        dataEfficient: mode !== 'high'
      }
    }));
  };

  const triggerHapticFeedback = (pattern: 'success' | 'warning' | 'error' = 'success') => {
    if (mobileState.capabilities.vibration) {
      const patterns = {
        success: [50, 50, 50],
        warning: [100, 50, 100],
        error: [200, 100, 200]
      };
      
      navigator.vibrate(patterns[pattern]);
    }
  };

  const getConnectionIcon = () => {
    switch (mobileState.sensorData.connectionQuality) {
      case 'excellent': return <Signal className="w-4 h-4 text-green-400" />;
      case 'good': return <Signal className="w-4 h-4 text-blue-400" />;
      case 'fair': return <Signal className="w-4 h-4 text-yellow-400" />;
      case 'poor': return <Signal className="w-4 h-4 text-red-400" />;
    }
  };

  const getMotionIntensity = () => {
    return Math.min(100, mobileState.sensorData.accelerometer.magnitude * 10);
  };

  return (
    <Card className="w-full">
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Smartphone className="w-5 h-5 text-cyan-500" />
          Mobile JARVIS Integration
          {mobileState.isEnabled && (
            <Badge variant="secondary" className="ml-2">
              <Activity className="w-3 h-3 mr-1" />
              Active
            </Badge>
          )}
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        {!mobileState.isEnabled ? (
          <div className="text-center py-6">
            <Brain className="w-12 h-12 mx-auto mb-3 text-cyan-400" />
            <p className="text-gray-600 dark:text-gray-400 mb-4">
              Enable mobile-optimized JARVIS with sensor integration, PWA features, and contextual intelligence
            </p>
            <Button 
              onClick={enableMobileJarvis} 
              disabled={isInitializing}
              className="bg-cyan-500 hover:bg-cyan-600"
            >
              {isInitializing ? (
                <>
                  <Zap className="w-4 h-4 mr-2 animate-pulse" />
                  Initializing...
                </>
              ) : (
                <>
                  <Smartphone className="w-4 h-4 mr-2" />
                  Enable Mobile JARVIS
                </>
              )}
            </Button>
          </div>
        ) : (
          <>
            {/* PWA Installation Prompt */}
            {mobileState.capabilities.installPrompt && (
              <div className="p-3 bg-gradient-to-r from-cyan-500/10 to-blue-500/10 rounded-lg border border-cyan-500/20">
                <div className="flex items-center justify-between">
                  <div>
                    <h4 className="text-sm font-medium text-cyan-300">Install JARVIS App</h4>
                    <p className="text-xs text-cyan-200">Add to home screen for native experience</p>
                  </div>
                  <Button size="sm" onClick={installPWA} className="bg-cyan-500 hover:bg-cyan-600">
                    Install
                  </Button>
                </div>
              </div>
            )}

            {/* System Status */}
            <div className="grid grid-cols-3 gap-3">
              <div className="text-center p-2 bg-gray-800/50 rounded">
                <Battery className="w-4 h-4 mx-auto mb-1 text-green-400" />
                <div className="text-sm font-medium">{mobileState.sensorData.batteryLevel}%</div>
                <div className="text-xs text-gray-400">Battery</div>
              </div>
              
              <div className="text-center p-2 bg-gray-800/50 rounded">
                {getConnectionIcon()}
                <div className="text-sm font-medium capitalize">{mobileState.sensorData.connectionQuality}</div>
                <div className="text-xs text-gray-400">Connection</div>
              </div>
              
              <div className="text-center p-2 bg-gray-800/50 rounded">
                <Activity className="w-4 h-4 mx-auto mb-1 text-blue-400" />
                <div className="text-sm font-medium">{Math.round(getMotionIntensity())}%</div>
                <div className="text-xs text-gray-400">Motion</div>
              </div>
            </div>

            {/* Sensor Data Visualization */}
            <div className="space-y-3">
              <h4 className="text-sm font-medium text-cyan-300">Live Sensor Data</h4>
              
              <div className="grid grid-cols-2 gap-3 text-xs">
                <div>
                  <div className="flex justify-between mb-1">
                    <span>Acceleration X</span>
                    <span className="text-cyan-400">{mobileState.sensorData.accelerometer.x.toFixed(2)}</span>
                  </div>
                  <Progress value={Math.abs(mobileState.sensorData.accelerometer.x) * 10} className="h-1" />
                </div>
                
                <div>
                  <div className="flex justify-between mb-1">
                    <span>Acceleration Y</span>
                    <span className="text-cyan-400">{mobileState.sensorData.accelerometer.y.toFixed(2)}</span>
                  </div>
                  <Progress value={Math.abs(mobileState.sensorData.accelerometer.y) * 10} className="h-1" />
                </div>
                
                <div>
                  <div className="flex justify-between mb-1">
                    <span>Orientation α</span>
                    <span className="text-cyan-400">{Math.round(mobileState.sensorData.gyroscope.alpha)}°</span>
                  </div>
                  <Progress value={Math.abs(mobileState.sensorData.gyroscope.alpha) / 360 * 100} className="h-1" />
                </div>
                
                <div>
                  <div className="flex justify-between mb-1">
                    <span>Orientation β</span>
                    <span className="text-cyan-400">{Math.round(mobileState.sensorData.gyroscope.beta)}°</span>
                  </div>
                  <Progress value={Math.abs(mobileState.sensorData.gyroscope.beta) / 180 * 100} className="h-1" />
                </div>
              </div>
            </div>

            {/* Adaptive Features */}
            <div className="space-y-3">
              <h4 className="text-sm font-medium text-cyan-300">Adaptive Features</h4>
              
              <div className="space-y-2">
                {Object.entries(mobileState.adaptiveFeatures).map(([feature, enabled]) => (
                  <div key={feature} className="flex items-center justify-between">
                    <span className="text-sm capitalize">{feature.replace(/([A-Z])/g, ' $1')}</span>
                    <Switch 
                      checked={enabled} 
                      onCheckedChange={() => toggleAdaptiveFeature(feature as keyof typeof mobileState.adaptiveFeatures)}
                    />
                  </div>
                ))}
              </div>
            </div>

            {/* Performance Mode */}
            <div className="space-y-3">
              <h4 className="text-sm font-medium text-cyan-300">Performance Mode</h4>
              
              <div className="grid grid-cols-3 gap-2">
                {(['high', 'balanced', 'battery_saver'] as const).map((mode) => (
                  <Button
                    key={mode}
                    size="sm"
                    variant={mobileState.optimizations.performanceMode === mode ? "default" : "outline"}
                    onClick={() => changePerformanceMode(mode)}
                    className="text-xs"
                  >
                    {mode.replace('_', ' ')}
                  </Button>
                ))}
              </div>
            </div>

            {/* Capabilities Status */}
            <div className="space-y-2">
              <h4 className="text-sm font-medium text-cyan-300">Available Capabilities</h4>
              
              <div className="grid grid-cols-2 gap-2 text-xs">
                {Object.entries(mobileState.capabilities).map(([capability, available]) => (
                  <div key={capability} className="flex items-center gap-2">
                    <div className={`w-2 h-2 rounded-full ${available ? 'bg-green-400' : 'bg-red-400'}`} />
                    <span className="capitalize">{capability.replace(/([A-Z])/g, ' $1')}</span>
                  </div>
                ))}
              </div>
            </div>

            {/* Test Haptic Feedback */}
            <div className="flex gap-2">
              <Button size="sm" onClick={() => triggerHapticFeedback('success')} variant="outline">
                Test Haptic
              </Button>
              <Button size="sm" onClick={() => triggerHapticFeedback('warning')} variant="outline">
                Warning
              </Button>
              <Button size="sm" onClick={() => triggerHapticFeedback('error')} variant="outline">
                Error
              </Button>
            </div>
          </>
        )}
      </CardContent>
    </Card>
  );
}