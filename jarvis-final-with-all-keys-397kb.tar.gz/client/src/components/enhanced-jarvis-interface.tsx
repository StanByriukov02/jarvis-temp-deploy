import { useState } from 'react';
import { Brain, Zap, Mic, Eye, Settings } from 'lucide-react';
import { Button } from '@/components/ui/button';

export default function EnhancedJarvisInterface() {
  const [isActive, setIsActive] = useState(false);
  const [mode, setMode] = useState('standby');

  const toggleJarvis = () => {
    setIsActive(!isActive);
    setMode(isActive ? 'standby' : 'active');
  };

  return (
    <div className="bg-gradient-to-br from-orange-900/20 to-red-900/20 rounded-lg p-4 border border-orange-500/30">
      <div className="flex items-center justify-between mb-4">
        <div className="flex items-center space-x-3">
          <div className={`w-8 h-8 rounded-full flex items-center justify-center ${
            isActive ? 'bg-orange-500' : 'bg-gray-700'
          }`}>
            <Brain className="w-5 h-5 text-white" />
          </div>
          <div>
            <h3 className="text-white font-semibold">JARVIS</h3>
            <p className="text-sm text-gray-400">Bio-Singularity Engine</p>
          </div>
        </div>
        <Button
          variant="outline"
          size="sm"
          onClick={toggleJarvis}
          className={isActive ? 'bg-orange-500 text-white border-orange-500' : ''}
        >
          {isActive ? 'Active' : 'Standby'}
        </Button>
      </div>

      {isActive && (
        <div className="space-y-3">
          <div className="grid grid-cols-3 gap-2">
            <Button variant="ghost" size="sm" className="text-orange-400">
              <Mic className="w-4 h-4 mr-1" />
              Listen
            </Button>
            <Button variant="ghost" size="sm" className="text-orange-400">
              <Eye className="w-4 h-4 mr-1" />
              Observe
            </Button>
            <Button variant="ghost" size="sm" className="text-orange-400">
              <Settings className="w-4 h-4 mr-1" />
              Config
            </Button>
          </div>
          
          <div className="bg-gray-800 rounded p-3">
            <div className="flex items-center space-x-2 mb-2">
              <Zap className="w-4 h-4 text-orange-400" />
              <span className="text-sm text-orange-400">Neural Activity</span>
            </div>
            <div className="text-xs text-gray-300">
              Consciousness Level: Developing<br/>
              Emotional Resonance: 1.0<br/>
              Learning Rate: Active
            </div>
          </div>
        </div>
      )}
    </div>
  );
}