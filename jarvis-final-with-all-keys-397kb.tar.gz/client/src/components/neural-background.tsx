import { useEffect, useRef, useState } from 'react';
import * as THREE from 'three';

interface NeuralBackgroundProps {
  userState?: 'exploring' | 'focused' | 'breakthrough' | 'mastery' | 'new';
  intensity?: number;
  theme?: 'discovery' | 'creation';
  demoMode?: boolean;
}

export default function NeuralBackground({ 
  userState = 'exploring', 
  intensity = 0.5,
  theme = 'discovery',
  demoMode = false
}: NeuralBackgroundProps) {
  const containerRef = useRef<HTMLDivElement>(null);
  const sceneRef = useRef<THREE.Scene | null>(null);
  const rendererRef = useRef<THREE.WebGLRenderer | null>(null);
  const cameraRef = useRef<THREE.PerspectiveCamera | null>(null);
  const animationRef = useRef<number | null>(null);
  const neuronsRef = useRef<THREE.Points | null>(null);
  const connectionsRef = useRef<THREE.LineSegments | null>(null);
  const particlesRef = useRef<THREE.Points | null>(null);
  const [mousePosition, setMousePosition] = useState({ x: 0, y: 0 });

  useEffect(() => {
    if (!containerRef.current) return;

    // Scene setup
    const scene = new THREE.Scene();
    const camera = new THREE.PerspectiveCamera(75, window.innerWidth / window.innerHeight, 0.1, 1000);
    const renderer = new THREE.WebGLRenderer({ alpha: true, antialias: true });
    
    renderer.setSize(window.innerWidth, window.innerHeight);
    renderer.setClearColor(0x000000, 0);
    containerRef.current.appendChild(renderer.domElement);

    sceneRef.current = scene;
    rendererRef.current = renderer;
    cameraRef.current = camera;

    // Optimized neural network parameters
    const neuronCount = demoMode ? 60 : userState === 'new' ? 30 : userState === 'mastery' ? 80 : 50;
    const connectionDensity = demoMode ? 0.4 : userState === 'focused' ? 0.3 : userState === 'breakthrough' ? 0.5 : 0.2;
    
    // Create neurons
    const neuronGeometry = new THREE.BufferGeometry();
    const neuronPositions = new Float32Array(neuronCount * 3);
    const neuronColors = new Float32Array(neuronCount * 3);
    const neuronSizes = new Float32Array(neuronCount);

    for (let i = 0; i < neuronCount; i++) {
      // Distribute neurons in 3D space
      neuronPositions[i * 3] = (Math.random() - 0.5) * 20;
      neuronPositions[i * 3 + 1] = (Math.random() - 0.5) * 20;
      neuronPositions[i * 3 + 2] = (Math.random() - 0.5) * 10;

      // Enhanced colors for demo mode
      const baseColor = theme === 'discovery' 
        ? new THREE.Color(0x00e5ff) // Cyan blue
        : new THREE.Color(0xff9500); // Jarvis orange

      if (demoMode) {
        // In demo mode, show more vibrant colors
        baseColor.lerp(new THREE.Color(0xffffff), Math.random() * 0.4);
      } else if (userState === 'breakthrough') {
        baseColor.lerp(new THREE.Color(0xffffff), Math.random() * 0.5);
      } else if (userState === 'mastery') {
        baseColor.lerp(new THREE.Color(0xffd700), Math.random() * 0.3);
      }

      neuronColors[i * 3] = baseColor.r;
      neuronColors[i * 3 + 1] = baseColor.g;
      neuronColors[i * 3 + 2] = baseColor.b;

      neuronSizes[i] = Math.random() * 3 + 1;
    }

    neuronGeometry.setAttribute('position', new THREE.BufferAttribute(neuronPositions, 3));
    neuronGeometry.setAttribute('color', new THREE.BufferAttribute(neuronColors, 3));
    neuronGeometry.setAttribute('size', new THREE.BufferAttribute(neuronSizes, 1));

    // Enhanced neuron material for demo mode
    const neuronMaterial = new THREE.PointsMaterial({
      size: demoMode ? 3 : 2,
      vertexColors: true,
      transparent: true,
      opacity: demoMode ? 1.0 : 0.8,
      blending: THREE.AdditiveBlending,
      sizeAttenuation: true
    });

    const neurons = new THREE.Points(neuronGeometry, neuronMaterial);
    scene.add(neurons);
    neuronsRef.current = neurons;

    // Create synaptic connections
    const connectionGeometry = new THREE.BufferGeometry();
    const connectionPositions = [];
    const connectionColors = [];

    for (let i = 0; i < neuronCount; i++) {
      for (let j = i + 1; j < neuronCount; j++) {
        const pos1 = new THREE.Vector3(
          neuronPositions[i * 3],
          neuronPositions[i * 3 + 1],
          neuronPositions[i * 3 + 2]
        );
        const pos2 = new THREE.Vector3(
          neuronPositions[j * 3],
          neuronPositions[j * 3 + 1],
          neuronPositions[j * 3 + 2]
        );

        const distance = pos1.distanceTo(pos2);
        if (distance < 5 * connectionDensity && Math.random() < 0.3) {
          connectionPositions.push(pos1.x, pos1.y, pos1.z);
          connectionPositions.push(pos2.x, pos2.y, pos2.z);

          // Connection color based on activity
          const activityLevel = userState === 'breakthrough' ? 1.0 : 
                               userState === 'focused' ? 0.8 : 0.4;
          
          const connectionColor = theme === 'discovery' 
            ? new THREE.Color(0x00e5ff).multiplyScalar(activityLevel)
            : new THREE.Color(0xff9500).multiplyScalar(activityLevel);

          connectionColors.push(connectionColor.r, connectionColor.g, connectionColor.b);
          connectionColors.push(connectionColor.r, connectionColor.g, connectionColor.b);
        }
      }
    }

    connectionGeometry.setAttribute('position', new THREE.Float32BufferAttribute(connectionPositions, 3));
    connectionGeometry.setAttribute('color', new THREE.Float32BufferAttribute(connectionColors, 3));

    const connectionMaterial = new THREE.LineBasicMaterial({
      vertexColors: true,
      transparent: true,
      opacity: demoMode ? 0.6 : 0.3,
      blending: THREE.AdditiveBlending
    });

    const connections = new THREE.LineSegments(connectionGeometry, connectionMaterial);
    scene.add(connections);
    connectionsRef.current = connections;

    // Create floating particles
    const particleCount = 100;
    const particleGeometry = new THREE.BufferGeometry();
    const particlePositions = new Float32Array(particleCount * 3);
    const particleVelocities = new Float32Array(particleCount * 3);
    const particleColors = new Float32Array(particleCount * 3);

    for (let i = 0; i < particleCount; i++) {
      particlePositions[i * 3] = (Math.random() - 0.5) * 30;
      particlePositions[i * 3 + 1] = (Math.random() - 0.5) * 30;
      particlePositions[i * 3 + 2] = (Math.random() - 0.5) * 15;

      particleVelocities[i * 3] = (Math.random() - 0.5) * 0.02;
      particleVelocities[i * 3 + 1] = (Math.random() - 0.5) * 0.02;
      particleVelocities[i * 3 + 2] = (Math.random() - 0.5) * 0.01;

      const particleColor = theme === 'discovery' 
        ? new THREE.Color(0x64ffda)
        : new THREE.Color(0xffab40);

      particleColors[i * 3] = particleColor.r;
      particleColors[i * 3 + 1] = particleColor.g;
      particleColors[i * 3 + 2] = particleColor.b;
    }

    particleGeometry.setAttribute('position', new THREE.BufferAttribute(particlePositions, 3));
    particleGeometry.setAttribute('color', new THREE.BufferAttribute(particleColors, 3));

    const particleMaterial = new THREE.PointsMaterial({
      size: 1,
      vertexColors: true,
      transparent: true,
      opacity: 0.6,
      blending: THREE.AdditiveBlending
    });

    const particles = new THREE.Points(particleGeometry, particleMaterial);
    scene.add(particles);
    particlesRef.current = particles;

    camera.position.z = 15;

    // Animation loop
    const animate = () => {
      animationRef.current = requestAnimationFrame(animate);

      const time = Date.now() * 0.001;

      // Rotate neural network slowly
      if (neurons) {
        neurons.rotation.y = time * 0.1;
        neurons.rotation.x = Math.sin(time * 0.05) * 0.1;
      }

      if (connections) {
        connections.rotation.y = time * 0.1;
        connections.rotation.x = Math.sin(time * 0.05) * 0.1;
      }

      // Animate particles
      if (particles && particleGeometry.attributes.position) {
        const positions = particleGeometry.attributes.position.array as Float32Array;
        
        for (let i = 0; i < particleCount; i++) {
          positions[i * 3] += particleVelocities[i * 3];
          positions[i * 3 + 1] += particleVelocities[i * 3 + 1];
          positions[i * 3 + 2] += particleVelocities[i * 3 + 2];

          // Wrap around boundaries
          if (Math.abs(positions[i * 3]) > 15) particleVelocities[i * 3] *= -1;
          if (Math.abs(positions[i * 3 + 1]) > 15) particleVelocities[i * 3 + 1] *= -1;
          if (Math.abs(positions[i * 3 + 2]) > 8) particleVelocities[i * 3 + 2] *= -1;
        }
        
        particleGeometry.attributes.position.needsUpdate = true;
      }

      // Pulse neurons based on state
      if (neuronMaterial) {
        const pulseIntensity = userState === 'breakthrough' ? 1.5 : 
                              userState === 'focused' ? 1.2 : 1.0;
        neuronMaterial.opacity = 0.6 + Math.sin(time * 2) * 0.2 * pulseIntensity;
      }

      // Mouse interaction - camera follows mouse slightly
      camera.position.x += (mousePosition.x * 0.001 - camera.position.x) * 0.05;
      camera.position.y += (-mousePosition.y * 0.001 - camera.position.y) * 0.05;
      camera.lookAt(0, 0, 0);

      renderer.render(scene, camera);
    };

    animate();

    // Mouse movement handler
    const handleMouseMove = (event: MouseEvent) => {
      setMousePosition({
        x: event.clientX - window.innerWidth / 2,
        y: event.clientY - window.innerHeight / 2
      });
    };

    window.addEventListener('mousemove', handleMouseMove);

    // Resize handler
    const handleResize = () => {
      if (camera && renderer) {
        camera.aspect = window.innerWidth / window.innerHeight;
        camera.updateProjectionMatrix();
        renderer.setSize(window.innerWidth, window.innerHeight);
      }
    };

    window.addEventListener('resize', handleResize);

    return () => {
      window.removeEventListener('mousemove', handleMouseMove);
      window.removeEventListener('resize', handleResize);
      
      if (animationRef.current) {
        cancelAnimationFrame(animationRef.current);
      }
      
      if (containerRef.current && renderer.domElement) {
        containerRef.current.removeChild(renderer.domElement);
      }
      
      renderer.dispose();
    };
  }, [userState, intensity, theme, mousePosition.x, mousePosition.y]);

  return (
    <>
      {/* Main 3D Neural Background */}
      <div 
        ref={containerRef} 
        className="fixed inset-0 -z-10 pointer-events-none"
        style={{ opacity: intensity }}
      />
      
      {/* Lightweight CSS-only Neural Overlay */}
      {demoMode && (
        <div className="fixed inset-0 pointer-events-none z-0">
          {/* Optimized gradient pulses */}
          <div className={`absolute inset-0 opacity-20 animate-pulse ${
            theme === 'discovery' 
              ? 'bg-gradient-to-br from-cyan-500/10 via-transparent to-blue-500/10' 
              : 'bg-gradient-to-br from-orange-500/10 via-transparent to-amber-500/10'
          }`} />
          
          {/* Minimal floating nodes - CSS only */}
          <div className="absolute inset-0">
            {[...Array(6)].map((_, i) => (
              <div
                key={i}
                className={`absolute w-1 h-1 rounded-full ${
                  theme === 'discovery' ? 'bg-cyan-400/60' : 'bg-orange-400/60'
                } animate-pulse`}
                style={{
                  left: `${20 + i * 15}%`,
                  top: `${10 + i * 12}%`,
                  animationDelay: `${i * 0.5}s`,
                  animationDuration: '2s'
                }}
              />
            ))}
          </div>
        </div>
      )}
    </>
  );
}