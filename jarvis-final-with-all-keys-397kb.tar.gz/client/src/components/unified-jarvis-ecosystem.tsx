import { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Brain, Activity, Zap, Mic, Camera, Smartphone, Calendar, Target, TrendingUp, Eye, Heart, Cpu, Globe, MessageSquare, Settings, BarChart3, Users, Shield, Clock, CheckCircle, ChevronRight } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { Switch } from '@/components/ui/switch';
import { useQuery } from '@tanstack/react-query';
import { PsychologicalStateMonitor } from './psychological-intervention-panel';

interface UnifiedJarvisEcosystemProps {
  userId: string;
  isVisible: boolean;
}

interface JarvisCapability {
  id: string;
  name: string;
  status: 'active' | 'initializing' | 'ready' | 'offline';
  confidence: number;
  icon: any;
  description: string;
  insights: string[];
  metrics?: Record<string, any>;
}

export function UnifiedJarvisEcosystem({ userId, isVisible }: UnifiedJarvisEcosystemProps) {
  const [selectedCapability, setSelectedCapability] = useState<string | null>('overview');
  const [realTimeInsights, setRealTimeInsights] = useState<string[]>([]);
  const [expandedSetting, setExpandedSetting] = useState<string | null>(null);

  // Fetch JARVIS system status
  const { data: systemStatus } = useQuery({
    queryKey: ['/api/jarvis/system-status'],
    refetchInterval: 300000, // Reduced from 15s to 5 minutes to prevent memory leaks
    enabled: isVisible
  });

  // Fetch predictive recommendations
  const { data: recommendations } = useQuery({
    queryKey: ['/api/jarvis/predictive-recommendations', userId],
    enabled: isVisible
  });

  // Fetch energy forecast
  const { data: energyForecast } = useQuery({
    queryKey: ['/api/jarvis/energy-forecast', userId],
    enabled: isVisible
  });

  // Define JARVIS capabilities with real-time status
  const capabilities: JarvisCapability[] = [
    {
      id: 'predictive',
      name: 'Predictive Intelligence',
      status: systemStatus?.integrations?.predictiveEngine ? 'active' : 'ready',
      confidence: 92,
      icon: Zap,
      description: 'Advanced pattern analysis and proactive recommendations',
      insights: recommendations?.recommendations?.slice(0, 3).map((r: any) => r.message) || [
        'Peak performance window detected in 2 hours',
        'Optimal work session recommended for complex tasks',
        'Energy levels trending upward - schedule important calls'
      ],
      metrics: {
        predictions: 847,
        accuracy: '94.2%',
        patterns: 156
      }
    },
    {
      id: 'biometric',
      name: 'Performance Monitoring',
      status: systemStatus?.integrations?.faceAnalysis ? 'active' : 'initializing',
      confidence: 88,
      icon: Activity,
      description: 'Real-time cognitive state and breakthrough detection',
      insights: [
        'Focus quality: Excellent (89%)',
        'Stress indicators: Low, optimal for deep work',
        'Breakthrough potential: High - creativity mode detected'
      ],
      metrics: {
        sessions: 234,
        breakthroughs: 18,
        avgFocus: '87%'
      }
    },
    {
      id: 'voice',
      name: 'Voice Intelligence',
      status: systemStatus?.integrations?.voiceEngine ? 'active' : 'ready',
      confidence: 91,
      icon: Mic,
      description: 'Emotional voice analysis and adaptive communication',
      insights: [
        'Communication style: Confident and decisive',
        'Emotional state: Motivated and focused',
        'Voice energy: High - optimal for presentations'
      ],
      metrics: {
        conversations: 156,
        accuracy: '96.1%',
        emotions: 'stable'
      }
    },
    {
      id: 'mobile',
      name: 'Mobile Integration',
      status: systemStatus?.integrations?.mobileSync ? 'active' : 'ready',
      confidence: 85,
      icon: Smartphone,
      description: 'Cross-device synchronization and mobile analytics',
      insights: [
        'Device usage: Optimal productivity pattern',
        'Context switching: Minimal - excellent focus',
        'Mobile performance: 94% efficiency score'
      ],
      metrics: {
        devices: 3,
        sync: '99.7%',
        battery: '89%'
      }
    },
    {
      id: 'adaptive',
      name: 'Adaptive Learning',
      status: systemStatus?.integrations?.adaptiveLearning ? 'active' : 'ready',
      confidence: 89,
      icon: Brain,
      description: 'Continuous learning and pattern optimization',
      insights: [
        'Learning curve: Accelerating rapidly',
        'Adaptation rate: 127% improvement this week',
        'Knowledge synthesis: Advanced pattern recognition'
      ],
      metrics: {
        patterns: 342,
        evolution: '+27%',
        insights: 89
      }
    },
    {
      id: 'calendar',
      name: 'Schedule Intelligence',
      status: systemStatus?.integrations?.calendarSync ? 'active' : 'ready',
      confidence: 93,
      icon: Calendar,
      description: 'AI-powered schedule optimization and planning',
      insights: [
        'Next optimal work block: Tomorrow 9:00 AM',
        'Calendar efficiency: 91% - well optimized',
        'Deep work opportunities: 3 blocks available this week'
      ],
      metrics: {
        meetings: 23,
        efficiency: '91%',
        blocks: 12
      }
    }
  ];

  // Real-time insights simulation
  useEffect(() => {
    if (!isVisible) return;
    
    const updateInsights = () => {
      const newInsights = [
        'Cognitive state optimal - breakthrough window detected',
        'Energy levels 94% - perfect for complex problem solving',
        'Pattern analysis suggests 2.3x productivity increase possible',
        'Stress indicators minimal - ideal for creative work',
        'Focus trajectory ascending - maintain current approach'
      ];
      
      setRealTimeInsights(prev => {
        const shuffled = [...newInsights].sort(() => Math.random() - 0.5);
        return shuffled.slice(0, 3);
      });
    };

    updateInsights();
    const interval = setInterval(updateInsights, 15000);
    return () => clearInterval(interval);
  }, [isVisible]);

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'active': return 'text-green-400 bg-green-500/20';
      case 'initializing': return 'text-yellow-400 bg-yellow-500/20';
      case 'ready': return 'text-blue-400 bg-blue-500/20';
      default: return 'text-gray-400 bg-gray-500/20';
    }
  };

  const selectedCap = (selectedCapability && typeof selectedCapability === 'string' && selectedCapability !== 'overview' && selectedCapability !== 'settings' && selectedCapability !== 'analytics') 
    ? capabilities.find(c => c.id === selectedCapability) 
    : null;

  return (
    <div className="space-y-6">
      {/* JARVIS Overview */}
      <div className="bg-gradient-to-r from-blue-500/20 to-purple-500/20 border border-blue-500/30 rounded-lg p-6">
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center gap-3">
            <Brain className="w-8 h-8 text-blue-400" />
            <div>
              <h3 className="text-xl font-bold text-white">JARVIS Intelligence Ecosystem</h3>
              <p className="text-blue-200 text-sm">Unified AI assistant with predictive analytics, biometric monitoring, and performance optimization</p>
            </div>
          </div>
          <Badge className="bg-green-500/20 text-green-400 border-green-500/30">
            {capabilities.filter(c => c.status === 'active').length} of {capabilities.length} Active
          </Badge>
        </div>

        {/* Real-time Insights Stream */}
        <div className="bg-black/20 rounded-lg p-4 mb-4">
          <div className="flex items-center gap-2 mb-3">
            <div className="w-2 h-2 bg-green-400 rounded-full animate-pulse"></div>
            <span className="text-green-400 text-sm font-medium">Live Intelligence Stream</span>
          </div>
          <AnimatePresence mode="wait">
            <div className="space-y-2">
              {realTimeInsights.map((insight, index) => (
                <motion.div
                  key={insight}
                  initial={{ opacity: 0, x: -20 }}
                  animate={{ opacity: 1, x: 0 }}
                  exit={{ opacity: 0, x: 20 }}
                  transition={{ delay: index * 0.1 }}
                  className="text-white/80 text-sm flex items-center gap-2"
                >
                  <Zap className="w-3 h-3 text-yellow-400" />
                  {insight}
                </motion.div>
              ))}
            </div>
          </AnimatePresence>
        </div>

        {/* System Health */}
        <div className="grid grid-cols-3 gap-4">
          <div className="text-center">
            <div className="text-2xl font-bold text-white mb-1">94.2%</div>
            <div className="text-blue-200 text-sm">System Performance</div>
          </div>
          <div className="text-center">
            <div className="text-2xl font-bold text-white mb-1">1,247</div>
            <div className="text-blue-200 text-sm">Insights Generated</div>
          </div>
          <div className="text-center">
            <div className="text-2xl font-bold text-white mb-1">89%</div>
            <div className="text-blue-200 text-sm">Prediction Accuracy</div>
          </div>
        </div>
      </div>

      {/* Capability Selection */}
      <div className="grid grid-cols-3 lg:grid-cols-6 gap-2">
        <motion.div
          whileHover={{ scale: 1.05 }}
          whileTap={{ scale: 0.95 }}
          transition={{ duration: 0.2, ease: "easeInOut" }}
        >
          <Button
            variant="ghost"
            onClick={() => setSelectedCapability('overview')}
            className={`flex flex-col items-center gap-2 p-4 h-auto transition-all duration-300 ease-in-out ${
              selectedCapability === 'overview'
                ? 'bg-orange-500/20 text-orange-400 border border-orange-500/30'
                : 'text-white/60 hover:text-white hover:bg-white/10'
            }`}
          >
            <Target className="w-5 h-5" />
            <span className="text-xs">Overview</span>
          </Button>
        </motion.div>
        {capabilities.map((cap) => (
          <motion.div
            key={cap.id}
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
            transition={{ duration: 0.2, ease: "easeInOut" }}
          >
            <Button
              variant="ghost"
              onClick={() => setSelectedCapability(cap.id)}
              className={`flex flex-col items-center gap-2 p-4 h-auto transition-all duration-300 ease-in-out ${
                selectedCapability === cap.id
                  ? 'bg-orange-500/20 text-orange-400 border border-orange-500/30'
                  : 'text-white/60 hover:text-white hover:bg-white/10'
              }`}
            >
              <cap.icon className="w-5 h-5" />
              <span className="text-xs">{cap.name.split(' ')[0]}</span>
              <Badge className={`text-xs ${getStatusColor(cap.status)}`}>
                {cap.status}
              </Badge>
            </Button>
          </motion.div>
        ))}
      </div>

      {/* Detailed View */}
      <AnimatePresence mode="wait">
        {selectedCapability === 'overview' ? (
          <motion.div
            key="overview"
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -30 }}
            transition={{ duration: 0.5, ease: "easeInOut" }}
            className="grid grid-cols-1 lg:grid-cols-2 gap-6"
          >
            {capabilities.map((cap) => (
              <div key={cap.id} className="bg-white/5 border border-white/10 rounded-lg p-4">
                <div className="flex items-center justify-between mb-3">
                  <div className="flex items-center gap-3">
                    <cap.icon className="w-6 h-6 text-blue-400" />
                    <div>
                      <h4 className="font-semibold text-white">{cap.name}</h4>
                      <p className="text-white/60 text-sm">{cap.description}</p>
                    </div>
                  </div>
                  <Badge className={getStatusColor(cap.status)}>
                    {cap.confidence}%
                  </Badge>
                </div>
                
                <div className="space-y-2">
                  {cap.insights.slice(0, 2).map((insight, index) => (
                    <div key={index} className="text-white/70 text-sm flex items-start gap-2">
                      <div className="w-1 h-1 bg-orange-400 rounded-full mt-2"></div>
                      {insight}
                    </div>
                  ))}
                </div>

                {cap.metrics && (
                  <div className="flex justify-between mt-3 pt-3 border-t border-white/10">
                    {Object.entries(cap.metrics).map(([key, value]) => (
                      <div key={key} className="text-center">
                        <div className="text-white font-medium">{value}</div>
                        <div className="text-white/40 text-xs capitalize">{key}</div>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            ))}
          </motion.div>
        ) : selectedCapability === 'settings' ? (
          <motion.div
            key="settings"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            className="bg-white/5 border border-white/10 rounded-lg p-6 overflow-hidden"
          >
            <div className="flex items-center justify-between mb-6">
              <div className="flex items-center gap-4">
                <Settings className="w-8 h-8 text-blue-400" />
                <div>
                  <h4 className="text-xl font-semibold text-white">JARVIS Configuration</h4>
                  <p className="text-white/60">Customize your AI assistant behavior and preferences</p>
                </div>
              </div>
              <Button 
                onClick={() => setSelectedCapability(null)}
                variant="ghost" 
                size="sm"
                className="text-white/60 hover:text-white"
              >
                ✕
              </Button>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="space-y-4">
                <h5 className="text-white font-medium">AI Behavior</h5>
                <div className="space-y-3">
                  <div className="flex items-center justify-between">
                    <span className="text-white/70 text-sm">Emotional Analysis</span>
                    <Switch defaultChecked />
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-white/70 text-sm">Adaptive Learning</span>
                    <Switch defaultChecked />
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-white/70 text-sm">Context Memory</span>
                    <Switch defaultChecked />
                  </div>
                </div>
              </div>

              <div className="space-y-4">
                <h5 className="text-white font-medium">Intelligence Systems</h5>
                <div className="space-y-3">
                  <div className="flex items-center justify-between">
                    <span className="text-white/70 text-sm">Predictive Analytics</span>
                    <Switch defaultChecked />
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-white/70 text-sm">Biometric Monitoring</span>
                    <Switch defaultChecked />
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-white/70 text-sm">Calendar Integration</span>
                    <Switch defaultChecked />
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-white/70 text-sm">Mobile Sync</span>
                    <Switch defaultChecked />
                  </div>
                </div>
              </div>

              <div className="space-y-4">
                <h5 className="text-white font-medium">Privacy & Security</h5>
                <div className="space-y-3">
                  <div className="flex items-center justify-between">
                    <span className="text-white/70 text-sm">Data Encryption</span>
                    <Badge className="bg-green-500/20 text-green-400 border-green-500/30">Active</Badge>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-white/70 text-sm">Local Processing</span>
                    <Switch defaultChecked />
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-white/70 text-sm">Analytics Sharing</span>
                    <Switch />
                  </div>
                </div>
              </div>

              <div className="space-y-4">
                <h5 className="text-white font-medium">Performance Tuning</h5>
                <div className="space-y-3">
                  <div className="space-y-2">
                    <div className="flex items-center justify-between">
                      <span className="text-white/70 text-sm">Processing Priority</span>
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => setExpandedSetting(expandedSetting === 'priority' ? null : 'priority')}
                        className="bg-white/10 border-white/20 text-white hover:bg-white/20 px-3 py-1 text-sm flex items-center gap-2"
                      >
                        Balanced
                        <motion.div
                          animate={{ rotate: expandedSetting === 'priority' ? 180 : 0 }}
                          transition={{ duration: 0.2 }}
                        >
                          <ChevronRight className="w-3 h-3" />
                        </motion.div>
                      </Button>
                    </div>
                    
                    <AnimatePresence>
                      {expandedSetting === 'priority' && (
                        <motion.div
                          initial={{ opacity: 0, height: 0, y: -10 }}
                          animate={{ opacity: 1, height: 'auto', y: 0 }}
                          exit={{ opacity: 0, height: 0, y: -10 }}
                          transition={{ duration: 0.4, ease: "easeInOut" }}
                          className="bg-white/5 border border-white/10 rounded-lg overflow-hidden"
                        >
                          <div className="p-3 space-y-2">
                            {[
                              { value: 'balanced', label: 'Balanced', desc: 'Optimal performance and efficiency' },
                              { value: 'performance', label: 'High Performance', desc: 'Maximum processing power' },
                              { value: 'battery', label: 'Battery Saver', desc: 'Extended device battery life' }
                            ].map((option) => (
                              <div
                                key={option.value}
                                className="p-3 rounded-lg bg-white/5 hover:bg-white/10 cursor-pointer transition-colors border border-transparent hover:border-white/20"
                                onClick={() => setExpandedSetting(null)}
                              >
                                <div className="font-medium text-white text-sm">{option.label}</div>
                                <div className="text-white/60 text-xs">{option.desc}</div>
                              </div>
                            ))}
                          </div>
                        </motion.div>
                      )}
                    </AnimatePresence>
                  </div>
                  
                  <div className="flex items-center justify-between">
                    <span className="text-white/70 text-sm">Background Analysis</span>
                    <Switch defaultChecked />
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-white/70 text-sm">Auto-Updates</span>
                    <Switch defaultChecked />
                  </div>
                </div>
              </div>
            </div>

            <div className="mt-6 pt-6 border-t border-white/10">
              <Button className="bg-blue-500 hover:bg-blue-600 text-white">
                Save Configuration
              </Button>
            </div>
          </motion.div>
        ) : selectedCapability === 'analytics' ? (
          <motion.div
            key="analytics"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            className="bg-white/5 border border-white/10 rounded-lg p-6 overflow-hidden"
          >
            <div className="flex items-center justify-between mb-6">
              <div className="flex items-center gap-4">
                <BarChart3 className="w-8 h-8 text-purple-400" />
                <div>
                  <h4 className="text-xl font-semibold text-white">JARVIS Analytics Dashboard</h4>
                  <p className="text-white/60">Comprehensive insights into your AI assistant performance</p>
                </div>
              </div>
              <Button 
                onClick={() => setSelectedCapability(null)}
                variant="ghost" 
                size="sm"
                className="text-white/60 hover:text-white"
              >
                ✕
              </Button>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              <div className="bg-white/5 rounded-lg p-4">
                <div className="flex items-center justify-between mb-3">
                  <h5 className="text-white font-medium">Voice Interactions</h5>
                  <TrendingUp className="w-5 h-5 text-green-400" />
                </div>
                <div className="text-2xl font-bold text-white mb-1">2,847</div>
                <div className="text-green-400 text-sm">+23% this week</div>
                <div className="mt-3 space-y-2">
                  <div className="flex justify-between text-sm">
                    <span className="text-white/60">Successful</span>
                    <span className="text-white">94%</span>
                  </div>
                  <div className="flex justify-between text-sm">
                    <span className="text-white/60">Avg Response Time</span>
                    <span className="text-white">0.3s</span>
                  </div>
                </div>
              </div>

              <div className="bg-white/5 rounded-lg p-4">
                <div className="flex items-center justify-between mb-3">
                  <h5 className="text-white font-medium">Predictive Accuracy</h5>
                  <Brain className="w-5 h-5 text-blue-400" />
                </div>
                <div className="text-2xl font-bold text-white mb-1">91.7%</div>
                <div className="text-blue-400 text-sm">+5.2% this month</div>
                <div className="mt-3 space-y-2">
                  <div className="flex justify-between text-sm">
                    <span className="text-white/60">Calendar Events</span>
                    <span className="text-white">96%</span>
                  </div>
                  <div className="flex justify-between text-sm">
                    <span className="text-white/60">Energy Forecasts</span>
                    <span className="text-white">87%</span>
                  </div>
                </div>
              </div>

              <div className="bg-white/5 rounded-lg p-4">
                <div className="flex items-center justify-between mb-3">
                  <h5 className="text-white font-medium">System Performance</h5>
                  <Activity className="w-5 h-5 text-purple-400" />
                </div>
                <div className="text-2xl font-bold text-white mb-1">98.2%</div>
                <div className="text-purple-400 text-sm">Uptime</div>
                <div className="mt-3 space-y-2">
                  <div className="flex justify-between text-sm">
                    <span className="text-white/60">CPU Usage</span>
                    <span className="text-white">12%</span>
                  </div>
                  <div className="flex justify-between text-sm">
                    <span className="text-white/60">Memory</span>
                    <span className="text-white">340MB</span>
                  </div>
                </div>
              </div>

              <div className="bg-white/5 rounded-lg p-4">
                <div className="flex items-center justify-between mb-3">
                  <h5 className="text-white font-medium">User Engagement</h5>
                  <Users className="w-5 h-5 text-orange-400" />
                </div>
                <div className="text-2xl font-bold text-white mb-1">4.8/5</div>
                <div className="text-orange-400 text-sm">Satisfaction Score</div>
                <div className="mt-3 space-y-2">
                  <div className="flex justify-between text-sm">
                    <span className="text-white/60">Daily Active</span>
                    <span className="text-white">1,247</span>
                  </div>
                  <div className="flex justify-between text-sm">
                    <span className="text-white/60">Avg Session</span>
                    <span className="text-white">24min</span>
                  </div>
                </div>
              </div>

              <div className="bg-white/5 rounded-lg p-4">
                <div className="flex items-center justify-between mb-3">
                  <h5 className="text-white font-medium">Learning Progress</h5>
                  <Zap className="w-5 h-5 text-yellow-400" />
                </div>
                <div className="text-2xl font-bold text-white mb-1">127</div>
                <div className="text-yellow-400 text-sm">New patterns learned</div>
                <div className="mt-3 space-y-2">
                  <div className="flex justify-between text-sm">
                    <span className="text-white/60">Adaptation Rate</span>
                    <span className="text-white">89%</span>
                  </div>
                  <div className="flex justify-between text-sm">
                    <span className="text-white/60">Model Updates</span>
                    <span className="text-white">43</span>
                  </div>
                </div>
              </div>

              <div className="bg-white/5 rounded-lg p-4">
                <div className="flex items-center justify-between mb-3">
                  <h5 className="text-white font-medium">Integration Health</h5>
                  <Shield className="w-5 h-5 text-green-400" />
                </div>
                <div className="text-2xl font-bold text-white mb-1">All Systems</div>
                <div className="text-green-400 text-sm">Operational</div>
                <div className="mt-3 space-y-2">
                  <div className="flex justify-between text-sm">
                    <span className="text-white/60">API Calls</span>
                    <span className="text-white">12.7K</span>
                  </div>
                  <div className="flex justify-between text-sm">
                    <span className="text-white/60">Error Rate</span>
                    <span className="text-white">0.02%</span>
                  </div>
                </div>
              </div>
            </div>

            <div className="mt-6 pt-6 border-t border-white/10">
              <div className="flex gap-3">
                <Button className="bg-purple-500 hover:bg-purple-600 text-white">
                  Generate Report
                </Button>
                <Button variant="outline" className="border-white/20 text-white hover:bg-white/10">
                  Download Data
                </Button>
              </div>
            </div>
          </motion.div>
        ) : (
          selectedCap && (
            <motion.div
              key={selectedCap.id}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              className="bg-white/5 border border-white/10 rounded-lg p-6 overflow-hidden"
            >
              <div className="flex items-center justify-between mb-6">
                <div className="flex items-center gap-4">
                  <selectedCap.icon className="w-8 h-8 text-blue-400" />
                  <div>
                    <h4 className="text-xl font-semibold text-white">{selectedCap.name}</h4>
                    <p className="text-white/60">{selectedCap.description}</p>
                  </div>
                </div>
                <div className="text-right">
                  <Badge className={getStatusColor(selectedCap.status)}>
                    {selectedCap.status.toUpperCase()}
                  </Badge>
                  <div className="text-white/60 text-sm mt-1">{selectedCap.confidence}% Confidence</div>
                </div>
              </div>

              <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                <div>
                  <h5 className="font-semibold text-white mb-3">Real-time Insights</h5>
                  <div className="space-y-3">
                    {selectedCap.insights.map((insight, index) => (
                      <div key={index} className="flex items-start gap-3 p-3 bg-black/20 rounded-lg">
                        <div className="w-2 h-2 bg-green-400 rounded-full mt-2"></div>
                        <div className="text-white/80">{insight}</div>
                      </div>
                    ))}
                  </div>
                </div>

                {selectedCap.metrics && (
                  <div>
                    <h5 className="font-semibold text-white mb-3">Performance Metrics</h5>
                    <div className="space-y-4">
                      {Object.entries(selectedCap.metrics).map(([key, value]) => (
                        <div key={key} className="bg-black/20 rounded-lg p-4">
                          <div className="flex justify-between items-center">
                            <span className="text-white/60 capitalize">{key}</span>
                            <span className="text-white font-semibold">{value}</span>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                )}
              </div>

              <div className="mt-6 pt-6 border-t border-white/10">
                <div className="flex flex-col sm:flex-row gap-3">
                  <Button 
                    onClick={() => setSelectedCapability('settings')}
                    className="bg-blue-500 hover:bg-blue-600 text-white flex-1"
                  >
                    Configure Settings
                  </Button>
                  <Button 
                    onClick={() => setSelectedCapability('analytics')}
                    variant="outline" 
                    className="border-white/20 text-white hover:bg-white/10 flex-1"
                  >
                    View Analytics
                  </Button>
                </div>
              </div>
            </motion.div>
          )
        )}
      </AnimatePresence>
      
      {/* Психологический монитор состояния */}
      <PsychologicalStateMonitor />
    </div>
  );
}