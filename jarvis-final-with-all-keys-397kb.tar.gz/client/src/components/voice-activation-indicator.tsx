import { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Mic, MicOff } from 'lucide-react';
import { invisibleJARVIS } from '@/lib/invisible-jarvis';

export default function VoiceActivationIndicator() {
  const [isListening, setIsListening] = useState(false);
  const [isActive, setIsActive] = useState(false);
  const [sessionInfo, setSessionInfo] = useState<any>(null);

  useEffect(() => {
    const checkStatus = () => {
      const session = invisibleJARVIS.getCurrentSession();
      const listening = invisibleJARVIS.isActive();
      
      setIsListening(listening);
      setIsActive(!!session);
      setSessionInfo(session);
    };

    // Check status every second
    const interval = setInterval(checkStatus, 1000);
    
    // Initial check
    checkStatus();

    return () => clearInterval(interval);
  }, []);

  if (!isListening && !isActive) return null;

  return (
    <AnimatePresence>
      <motion.div
        initial={{ opacity: 0, scale: 0.8 }}
        animate={{ opacity: 1, scale: 1 }}
        exit={{ opacity: 0, scale: 0.8 }}
        className="fixed bottom-6 right-6 z-50"
      >
        <div className="flex items-center gap-3 bg-black/90 backdrop-blur-sm border border-orange-500/30 rounded-full px-4 py-3 shadow-lg">
          {/* Microphone Icon */}
          <motion.div
            animate={isListening ? { scale: [1, 1.1, 1] } : {}}
            transition={{ duration: 1.5, repeat: Infinity }}
            className="relative"
          >
            {isListening ? (
              <Mic className="w-5 h-5 text-orange-400" />
            ) : (
              <MicOff className="w-5 h-5 text-gray-400" />
            )}
            
            {/* Listening pulse effect */}
            {isListening && (
              <motion.div
                animate={{ scale: [1, 2], opacity: [0.7, 0] }}
                transition={{ duration: 1.5, repeat: Infinity }}
                className="absolute inset-0 bg-orange-400 rounded-full"
              />
            )}
          </motion.div>

          {/* Status Text */}
          <div className="text-sm">
            {isActive ? (
              <div className="text-orange-400 font-medium">
                JARVIS Active
              </div>
            ) : isListening ? (
              <div className="text-orange-300">
                Listening for wake phrase...
              </div>
            ) : (
              <div className="text-gray-400">
                Voice inactive
              </div>
            )}
            
            {sessionInfo && (
              <div className="text-xs text-gray-500 mt-1">
                Session: {sessionInfo.sessionId?.slice(0, 8)}...
              </div>
            )}
          </div>

          {/* Visual waveform when active */}
          {isActive && (
            <div className="flex items-center gap-1">
              {[...Array(4)].map((_, i) => (
                <motion.div
                  key={i}
                  animate={{ 
                    height: [4, 12, 4],
                    opacity: [0.4, 1, 0.4]
                  }}
                  transition={{ 
                    duration: 1,
                    repeat: Infinity,
                    delay: i * 0.1
                  }}
                  className="w-1 bg-orange-400 rounded-full"
                />
              ))}
            </div>
          )}
        </div>

        {/* Help text */}
        {isListening && !isActive && (
          <motion.div
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            className="mt-2 text-xs text-center text-gray-400 bg-black/60 backdrop-blur-sm rounded-lg px-3 py-2"
          >
            Say "Hey JARVIS - ready to go?" or "Wake up JARVIS"
          </motion.div>
        )}
      </motion.div>
    </AnimatePresence>
  );
}