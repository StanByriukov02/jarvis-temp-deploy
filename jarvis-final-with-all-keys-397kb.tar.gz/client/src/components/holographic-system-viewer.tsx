import { useState, useEffect, useRef } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { Play, Pause, RotateCcw, Maximize, Zap, Brain, Cpu, Radio, Eye, ArrowRight } from 'lucide-react';

interface HolographicSystemProps {
  systemData: {
    title: string;
    category: string;
    steps: number;
    complexity: 'Beginner' | 'Intermediate' | 'Advanced';
    connections: number;
    efficiency: number;
  };
  isPlaying?: boolean;
  onPlay?: () => void;
  className?: string;
}

export default function HolographicSystemViewer({ 
  systemData, 
  isPlaying = false, 
  onPlay,
  className = "w-full h-[400px]"
}: HolographicSystemProps) {
  const [activeStep, setActiveStep] = useState(0);
  const [fullscreen, setFullscreen] = useState(false);
  const [rotation, setRotation] = useState({ x: 0, y: 0, z: 0 });
  const [pulseIntensity, setPulseIntensity] = useState(1);
  const containerRef = useRef<HTMLDivElement>(null);

  // Continuous rotation and pulse effects
  useEffect(() => {
    if (isPlaying) {
      const rotationInterval = setInterval(() => {
        setRotation(prev => ({
          x: prev.x + 0.5,
          y: prev.y + 1,
          z: prev.z + 0.3
        }));
      }, 50);

      const pulseInterval = setInterval(() => {
        setPulseIntensity(prev => prev === 1 ? 1.3 : 1);
      }, 800);

      return () => {
        clearInterval(rotationInterval);
        clearInterval(pulseInterval);
      };
    }
  }, [isPlaying]);

  // Step progression
  useEffect(() => {
    if (isPlaying) {
      const interval = setInterval(() => {
        setActiveStep(prev => (prev + 1) % systemData.steps);
      }, 1200);
      return () => clearInterval(interval);
    }
  }, [isPlaying, systemData.steps]);

  // Generate holographic network structure
  const generateHolographicNodes = () => {
    const nodes = [];
    const layers = systemData.complexity === 'Beginner' ? 2 : 
                   systemData.complexity === 'Intermediate' ? 3 : 4;
    
    for (let layer = 0; layer < layers; layer++) {
      const nodesInLayer = Math.ceil(systemData.steps / layers);
      const radius = 60 + (layer * 40);
      
      for (let i = 0; i < nodesInLayer && nodes.length < systemData.steps; i++) {
        const angle = (i / nodesInLayer) * 360 + (layer * 30);
        const x = Math.cos((angle * Math.PI) / 180) * radius;
        const y = Math.sin((angle * Math.PI) / 180) * radius;
        const z = (layer - layers/2) * 30;
        
        nodes.push({
          id: nodes.length,
          x, y, z,
          layer,
          angle,
          isActive: isPlaying && nodes.length <= activeStep,
          intensity: nodes.length <= activeStep ? 1 : 0.3
        });
      }
    }
    return nodes;
  };

  const nodes = generateHolographicNodes();

  return (
    <>
      <div className={`relative overflow-hidden ${className}`}>
        {/* Holographic background effects */}
        <div className="absolute inset-0 bg-gradient-to-br from-black via-slate-900 to-black">
          {/* Scanning lines effect */}
          <div className="absolute inset-0 opacity-30">
            {Array.from({ length: 20 }).map((_, i) => (
              <motion.div
                key={i}
                className="absolute w-full h-px bg-gradient-to-r from-transparent via-cyan-400 to-transparent"
                style={{ top: `${i * 5}%` }}
                animate={{
                  opacity: [0.1, 0.8, 0.1],
                  scaleX: [0.5, 1, 0.5]
                }}
                transition={{
                  duration: 3,
                  repeat: Infinity,
                  delay: i * 0.1
                }}
              />
            ))}
          </div>

          {/* Grid overlay */}
          <div 
            className="absolute inset-0 opacity-20"
            style={{
              backgroundImage: `
                linear-gradient(rgba(0, 255, 255, 0.1) 1px, transparent 1px),
                linear-gradient(90deg, rgba(0, 255, 255, 0.1) 1px, transparent 1px)
              `,
              backgroundSize: '20px 20px'
            }}
          />
        </div>

        {/* Main holographic display */}
        <div 
          ref={containerRef}
          className="absolute inset-0 perspective-1000"
          style={{
            transform: `rotateX(${rotation.x}deg) rotateY(${rotation.y}deg) rotateZ(${rotation.z}deg)`,
            transformStyle: 'preserve-3d'
          }}
        >
          {/* Central core hologram */}
          <div className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2">
            <motion.div 
              className="relative"
              animate={{
                scale: [1, 1.1, 1],
                rotateY: [0, 360]
              }}
              transition={{
                duration: 4,
                repeat: Infinity,
                ease: "linear"
              }}
            >
              {/* Core sphere */}
              <div className="w-20 h-20 relative">
                {/* Inner core */}
                <div className="absolute inset-2 bg-gradient-to-r from-orange-400 to-orange-600 rounded-full animate-pulse">
                  <div className="absolute inset-0 rounded-full bg-orange-500 animate-ping opacity-75"></div>
                  <div className="absolute inset-0 flex items-center justify-center">
                    <Brain className="w-8 h-8 text-white" />
                  </div>
                </div>
                
                {/* Outer ring */}
                <div className="absolute inset-0 border-2 border-cyan-400 rounded-full animate-spin opacity-60"></div>
                
                {/* Energy particles */}
                {Array.from({ length: 8 }).map((_, i) => (
                  <motion.div
                    key={i}
                    className="absolute w-1 h-1 bg-cyan-400 rounded-full"
                    style={{
                      left: '50%',
                      top: '50%',
                      transform: `rotate(${i * 45}deg) translateY(-40px)`
                    }}
                    animate={{
                      scale: [0, 1, 0],
                      opacity: [0, 1, 0]
                    }}
                    transition={{
                      duration: 2,
                      repeat: Infinity,
                      delay: i * 0.2
                    }}
                  />
                ))}
              </div>
            </motion.div>
          </div>

          {/* Holographic nodes network */}
          {nodes.map((node, index) => (
            <motion.div
              key={node.id}
              className={`absolute w-4 h-4 rounded-full ${
                node.isActive 
                  ? 'bg-gradient-to-r from-orange-400 to-orange-600 shadow-lg shadow-orange-500/50' 
                  : 'bg-gradient-to-r from-cyan-400 to-blue-500'
              }`}
              style={{
                left: `calc(50% + ${node.x}px)`,
                top: `calc(50% + ${node.y}px)`,
                transform: `translate(-50%, -50%) translateZ(${node.z}px) scale(${node.intensity * pulseIntensity})`,
                filter: `brightness(${node.intensity}) blur(${node.isActive ? 0 : 1}px)`,
                boxShadow: node.isActive ? 
                  `0 0 20px ${node.layer % 2 === 0 ? '#ff9500' : '#00ffff'}` : 
                  `0 0 10px ${node.layer % 2 === 0 ? '#ff9500' : '#00ffff'}`
              }}
              animate={{
                rotateY: [0, 360],
                scale: node.isActive ? [1, 1.2, 1] : [1, 1.05, 1]
              }}
              transition={{
                duration: node.isActive ? 1 : 3,
                repeat: Infinity,
                delay: index * 0.1
              }}
            >
              {/* Node pulse effect */}
              {node.isActive && (
                <div className="absolute inset-0 rounded-full bg-orange-500 animate-ping opacity-75"></div>
              )}
              
              {/* Data streams */}
              <div className="absolute inset-0 rounded-full border border-cyan-400 animate-pulse opacity-50"></div>
            </motion.div>
          ))}

          {/* Holographic connections */}
          {nodes.map((node, index) => {
            if (index === nodes.length - 1) return null;
            const nextNode = nodes[index + 1];
            const distance = Math.sqrt(
              Math.pow(nextNode.x - node.x, 2) + 
              Math.pow(nextNode.y - node.y, 2) + 
              Math.pow(nextNode.z - node.z, 2)
            );
            
            return (
              <motion.div
                key={`connection-${index}`}
                className="absolute h-px origin-left"
                style={{
                  left: `calc(50% + ${node.x}px)`,
                  top: `calc(50% + ${node.y}px)`,
                  width: `${distance}px`,
                  background: node.isActive && nextNode.isActive ?
                    'linear-gradient(90deg, #ff9500, #ffb84d, #ff9500)' :
                    'linear-gradient(90deg, #00ffff, #4dd8ff, #00ffff)',
                  opacity: node.isActive && nextNode.isActive ? 0.8 : 0.3,
                  transform: `translateZ(${(node.z + nextNode.z) / 2}px)`,
                  filter: node.isActive && nextNode.isActive ? 'blur(0px)' : 'blur(1px)',
                  boxShadow: node.isActive && nextNode.isActive ?
                    '0 0 4px #ff9500' : '0 0 2px #00ffff'
                }}
                animate={{
                  opacity: [0.3, 0.8, 0.3],
                  scaleX: [0.8, 1, 0.8]
                }}
                transition={{
                  duration: 2,
                  repeat: Infinity,
                  delay: index * 0.1
                }}
              />
            );
          })}

          {/* Data streams flowing through connections */}
          {isPlaying && nodes.map((node, index) => {
            if (!node.isActive || index === nodes.length - 1) return null;
            
            return (
              <motion.div
                key={`stream-${index}`}
                className="absolute w-2 h-2 bg-orange-400 rounded-full"
                style={{
                  left: `calc(50% + ${node.x}px)`,
                  top: `calc(50% + ${node.y}px)`,
                  transform: `translateZ(${node.z}px)`,
                  filter: 'blur(0.5px)',
                  boxShadow: '0 0 8px #ff9500'
                }}
                animate={{
                  x: [0, nodes[index + 1]?.x - node.x || 0],
                  y: [0, nodes[index + 1]?.y - node.y || 0],
                  opacity: [0, 1, 0]
                }}
                transition={{
                  duration: 1.5,
                  repeat: Infinity,
                  delay: index * 0.3
                }}
              />
            );
          })}
        </div>

        {/* Holographic UI overlay */}
        <div className="absolute inset-0 pointer-events-none">
          {/* Corner brackets */}
          <div className="absolute top-4 left-4 w-8 h-8 border-t-2 border-l-2 border-cyan-400 opacity-60"></div>
          <div className="absolute top-4 right-4 w-8 h-8 border-t-2 border-r-2 border-cyan-400 opacity-60"></div>
          <div className="absolute bottom-4 left-4 w-8 h-8 border-b-2 border-l-2 border-cyan-400 opacity-60"></div>
          <div className="absolute bottom-4 right-4 w-8 h-8 border-b-2 border-r-2 border-cyan-400 opacity-60"></div>

          {/* System info hologram */}
          <div className="absolute top-4 left-16">
            <div className="bg-black/70 backdrop-blur-sm rounded border border-cyan-400/30 p-3 text-cyan-100">
              <h3 className="font-bold text-lg mb-1 text-orange-400">{systemData.title}</h3>
              <div className="text-cyan-400 text-sm mb-2">{systemData.category}</div>
              {isPlaying && (
                <motion.div 
                  className="text-orange-500 text-sm flex items-center gap-1"
                  animate={{ opacity: [0.7, 1, 0.7] }}
                  transition={{ duration: 1, repeat: Infinity }}
                >
                  <Zap className="w-3 h-3" />
                  Processing Step {activeStep + 1}/{systemData.steps}
                </motion.div>
              )}
            </div>
          </div>

          {/* System metrics hologram */}
          <div className="absolute top-4 right-16">
            <div className="bg-black/70 backdrop-blur-sm rounded border border-cyan-400/30 p-3 text-cyan-100">
              <div className="grid grid-cols-2 gap-2 text-xs">
                <div className="flex items-center gap-1">
                  <Cpu className="w-3 h-3 text-orange-400" />
                  <span>Steps: {systemData.steps}</span>
                </div>
                <div className="flex items-center gap-1">
                  <Radio className="w-3 h-3 text-cyan-400" />
                  <span>Links: {systemData.connections}</span>
                </div>
                <div className="flex items-center gap-1">
                  <Brain className="w-3 h-3 text-purple-400" />
                  <span>{systemData.complexity}</span>
                </div>
                <div className="flex items-center gap-1">
                  <Eye className="w-3 h-3 text-green-400" />
                  <span>{systemData.efficiency}%</span>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Control interface */}
        <div className="absolute bottom-4 left-4 right-4 flex justify-between items-center pointer-events-auto">
          <div className="flex gap-2">
            <Button
              size="sm"
              variant="ghost"
              onClick={onPlay}
              className="bg-black/50 border border-cyan-400/30 text-cyan-100 hover:bg-cyan-400/10 backdrop-blur-sm"
            >
              {isPlaying ? <Pause className="w-4 h-4 mr-1" /> : <Play className="w-4 h-4 mr-1" />}
              {isPlaying ? 'Pause' : 'Initialize'}
            </Button>
            
            <Button
              size="sm"
              variant="ghost"
              onClick={() => setRotation({ x: 0, y: 0, z: 0 })}
              className="bg-black/50 border border-cyan-400/30 text-cyan-100 hover:bg-cyan-400/10 backdrop-blur-sm"
            >
              <RotateCcw className="w-4 h-4" />
            </Button>
            
            <Button
              size="sm"
              variant="ghost"
              onClick={() => setFullscreen(true)}
              className="bg-black/50 border border-cyan-400/30 text-cyan-100 hover:bg-cyan-400/10 backdrop-blur-sm"
            >
              <Maximize className="w-4 h-4" />
            </Button>
          </div>
          
          <div className="bg-black/50 border border-cyan-400/30 rounded px-3 py-1 backdrop-blur-sm">
            <span className="text-cyan-100 text-sm flex items-center gap-1">
              <Eye className="w-3 h-3 text-orange-400" />
              Holographic Neural Interface
            </span>
          </div>
        </div>
      </div>

      {/* Fullscreen holographic mode */}
      <AnimatePresence>
        {fullscreen && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-50 bg-black"
          >
            <HolographicSystemViewer
              systemData={systemData}
              isPlaying={isPlaying}
              onPlay={onPlay}
              className="w-full h-full"
            />
            <Button
              variant="ghost"
              onClick={() => setFullscreen(false)}
              className="absolute top-4 right-4 text-cyan-100 hover:bg-cyan-400/10 border border-cyan-400/30"
            >
              <ArrowRight className="w-4 h-4 mr-1" />
              Exit Hologram
            </Button>
          </motion.div>
        )}
      </AnimatePresence>
    </>
  );
}