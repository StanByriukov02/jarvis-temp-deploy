/**
 * Invisible JARVIS - Always-on voice assistant service
 * No UI, pure voice interaction with wake word detection
 */

import { apiRequest } from '@/lib/queryClient';

interface VoiceSession {
  sessionId: string;
  isActive: boolean;
  userId: string;
  emotionalState?: string;
  lastInteraction?: Date;
  activationPhrase?: string;
}

interface WakeWordConfig {
  phrases: string[];
  confidence: number;
  enabled: boolean;
}

interface PersonalizedGreeting {
  text: string;
  audioUrl?: string;
  context: {
    timeOfDay: string;
    userMood: string;
    recentActivity: string;
    personalTone: string;
  };
}

class InvisibleJARVIS {
  private recognition: any = null;
  private synthesis: SpeechSynthesis;
  private isListening: boolean = false;
  private currentSession: VoiceSession | null = null;
  private audioContext: AudioContext | null = null;
  
  private wakeWords: WakeWordConfig = {
    phrases: [
      "hey jarvis ready to go",
      "wake up jarvis",
      "джарвис",
      "привет джарвис",
      "эй джарвис",
      "jarvis",
      "hey jarvis",
      "hi jarvis"
    ],
    confidence: 0.6, // Понижен для лучшего распознавания
    enabled: true
  };

  constructor() {
    // Only initialize if we're in a browser environment
    if (typeof window !== 'undefined' && window.speechSynthesis) {
      this.synthesis = window.speechSynthesis;
      
      // Defer initialization to avoid blocking app startup
      setTimeout(() => {
        this.initialize().catch(error => {
          console.error('Failed to initialize JARVIS:', error);
          // Prevent unhandled rejection
        });
      }, 1000);
    }
  }

  /**
   * Initialize always-on listening
   */
  async initialize(): Promise<void> {
    try {
      // Check browser support first
      if (!this.checkBrowserSupport()) {
        console.warn('Speech recognition not supported in this browser');
        return;
      }

      // Setup speech recognition first (doesn't require permissions)
      this.setupSpeechRecognition();
      this.initializeAudioContext();
      
      // Request microphone permission only when starting to listen
      try {
        await navigator.mediaDevices.getUserMedia({ audio: true });
        // Start background listening for wake words
        this.startBackgroundListening();
        console.log('🤖 Invisible JARVIS is now listening for "Hey JARVIS - ready to go?" and "Wake up JARVIS"');
      } catch (micError) {
        console.log('🤖 Invisible JARVIS initialized (microphone permission needed for voice activation)');
      }
      
    } catch (error) {
      console.error('Failed to initialize JARVIS:', error);
      // Don't throw error, just log warning to allow app to continue
      console.warn('Voice assistant unavailable - continuing without voice features');
    }
  }

  /**
   * Check if browser supports speech recognition
   */
  private checkBrowserSupport(): boolean {
    return !!(
      (window as any).SpeechRecognition || 
      (window as any).webkitSpeechRecognition
    );
  }

  /**
   * Setup speech recognition for continuous listening
   */
  private setupSpeechRecognition(): void {
    if (!('webkitSpeechRecognition' in window) && !('SpeechRecognition' in window)) {
      throw new Error('Speech recognition not supported');
    }

    const SpeechRecognition = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;
    this.recognition = new SpeechRecognition();
    
    this.recognition.continuous = true;
    this.recognition.interimResults = true;
    this.recognition.lang = 'en-US';
    
    this.recognition.onstart = () => {
      this.isListening = true;
    };

    this.recognition.onend = () => {
      this.isListening = false;
      // Restart listening automatically for always-on mode
      if (this.wakeWords.enabled) {
        setTimeout(() => this.startBackgroundListening(), 100);
      }
    };

    this.recognition.onresult = (event: any) => {
      this.handleSpeechResult(event);
    };

    this.recognition.onerror = (event: any) => {
      console.error('Speech recognition error:', event.error);
      // Restart on error
      if (this.wakeWords.enabled) {
        setTimeout(() => this.startBackgroundListening(), 1000);
      }
    };
  }

  /**
   * Initialize Web Audio Context for advanced audio processing
   */
  private initializeAudioContext(): void {
    try {
      this.audioContext = new AudioContext();
    } catch (error) {
      console.warn('AudioContext not available:', error);
    }
  }

  /**
   * Start background listening for wake words
   */
  private startBackgroundListening(): void {
    if (!this.recognition || this.isListening) return;
    
    try {
      this.recognition.start();
    } catch (error) {
      console.error('Failed to start listening:', error);
    }
  }

  /**
   * Handle speech recognition results
   */
  private handleSpeechResult(event: any): void {
    let finalTranscript = '';
    let interimTranscript = '';

    for (let i = event.resultIndex; i < event.results.length; i++) {
      const transcript = event.results[i][0].transcript;
      
      if (event.results[i].isFinal) {
        finalTranscript += transcript;
      } else {
        interimTranscript += transcript;
      }
    }

    const fullTranscript = (finalTranscript + interimTranscript).toLowerCase().trim();
    
    // Check for wake words
    if (!this.currentSession?.isActive) {
      if (this.detectWakeWord(fullTranscript)) {
        this.activateJARVIS(fullTranscript);
      }
    } else {
      // Process command when JARVIS is active
      if (finalTranscript.trim()) {
        this.processCommand(finalTranscript.trim());
      }
    }
  }

  /**
   * Detect wake words in speech
   */
  private detectWakeWord(transcript: string): boolean {
    return this.wakeWords.phrases.some(phrase => {
      const similarity = this.calculateSimilarity(transcript, phrase);
      return similarity >= this.wakeWords.confidence;
    });
  }

  /**
   * Calculate similarity between spoken text and wake phrase
   */
  private calculateSimilarity(text1: string, text2: string): number {
    const words1 = text1.split(' ');
    const words2 = text2.split(' ');
    
    let matches = 0;
    words2.forEach(word => {
      if (words1.some(w => w.includes(word) || word.includes(w))) {
        matches++;
      }
    });
    
    return matches / words2.length;
  }

  /**
   * Activate JARVIS with fast response (inspired by external JARVIS speed)
   */
  private async activateJARVIS(wakePhrase: string): Promise<void> {
    try {
      console.log(`🎯 JARVIS активация: "${wakePhrase}"`);
      
      // Мгновенная локальная реакция (как у него)
      const quickResponse = this.getQuickActivationResponse(wakePhrase);
      await this.speakFast(quickResponse); // Быстрый темп речи
      
      // Create new session
      this.currentSession = {
        sessionId: this.generateSessionId(),
        isActive: true,
        userId: 'demo-user',
        lastInteraction: new Date(),
        activationPhrase: wakePhrase
      };

      // Асинхронное получение персонализированного приветствия
      this.getPersonalizedGreeting(wakePhrase).then(greeting => {
        if (this.currentSession?.isActive && greeting.text !== quickResponse) {
          this.speak(greeting.text);
        }
      });
      
      // Auto-deactivate after 30 seconds of silence
      setTimeout(() => {
        if (this.currentSession?.isActive) {
          this.deactivateJARVIS();
        }
      }, 30000);

      console.log('🤖 JARVIS активирован с быстрым откликом');
      
    } catch (error) {
      console.error('Failed to activate JARVIS:', error);
      await this.speak("I'm having trouble right now. Please try again.");
    }
  }

  /**
   * Get personalized greeting based on user context
   */
  private async getPersonalizedGreeting(wakePhrase: string): Promise<PersonalizedGreeting> {
    try {
      const response = await apiRequest('/api/voice/personalized-greeting', {
        method: 'POST',
        body: {
          wakePhrase,
          userId: this.currentSession?.userId,
          sessionId: this.currentSession?.sessionId,
          context: {
            timeOfDay: this.getTimeOfDay(),
            deviceType: 'desktop',
            previousSessions: await this.getRecentSessions()
          }
        }
      });

      return response;
    } catch (error) {
      console.error('Failed to get personalized greeting:', error);
      
      // Fallback greeting
      return {
        text: this.getFallbackGreeting(),
        context: {
          timeOfDay: this.getTimeOfDay(),
          userMood: 'neutral',
          recentActivity: 'unknown',
          personalTone: 'professional'
        }
      };
    }
  }

  /**
   * Get fallback greeting when API fails
   */
  private getFallbackGreeting(): string {
    const timeOfDay = this.getTimeOfDay();
    const greetings = {
      morning: "Good morning! I'm ready to help you tackle your goals today.",
      afternoon: "Good afternoon! How can I assist with your transformation today?",
      evening: "Good evening! Ready to optimize your progress?",
      night: "Working late tonight? I'm here to help you stay focused."
    };
    
    return greetings[timeOfDay as keyof typeof greetings] || "Hello! I'm ready to assist you.";
  }

  /**
   * Process voice command
   */
  private async processCommand(command: string): Promise<void> {
    try {
      // Check if this is a Deep Focus command
      if (command.toLowerCase().includes('deep focus') || command.toLowerCase().includes('глубокий фокус')) {
        await this.processDeepFocusCommand(command);
        return;
      }

      const response = await apiRequest('/api/voice/intelligent-command', {
        method: 'POST',
        body: {
          command,
          sessionId: this.currentSession?.sessionId,
          context: {
            currentTime: new Date().toISOString(),
            userLocation: 'desktop',
            emotionalState: this.currentSession?.emotionalState
          }
        }
      });

      // Speak response
      if (response.response) {
        await this.speak(response.response);
      }

      // Execute action if needed
      if (response.action) {
        await this.executeAction(response.action);
      }

    } catch (error) {
      console.error('Command processing failed:', error);
      await this.speak("I couldn't process that command. Could you try rephrasing it?");
    }
  }

  /**
   * Process Deep Focus voice command
   */
  private async processDeepFocusCommand(command: string): Promise<void> {
    try {
      const response = await fetch('/api/jarvis/deep-focus', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({
          userId: 'demo-user',
          voiceCommand: command
        })
      });

      const data = await response.json();
      
      if (data.success) {
        await this.speak(data.message);
        
        if (data.action === 'activate' && data.sessionData) {
          // Deep Focus activated successfully
          console.log('Deep Focus activated:', data.sessionData);
          
          // Notify the UI to update
          window.dispatchEvent(new CustomEvent('deep-focus-activated', {
            detail: data.sessionData
          }));
        }
      } else {
        await this.speak(data.message);
        
        if (data.suggestions && data.suggestions.length > 0) {
          // Present suggestions
          const suggestionText = data.suggestions.map(s => `${s.systemTitle} на ${s.duration} минут`).join(', ');
          await this.speak(`Доступные варианты: ${suggestionText}`);
        }
      }
    } catch (error) {
      console.error('Deep Focus command failed:', error);
      await this.speak('Не удалось активировать Deep Focus. Попробуйте позже.');
    }
  }

  /**
   * Execute system action
   */
  private async executeAction(action: any): Promise<void> {
    switch (action.type) {
      case 'navigate':
        window.location.hash = action.destination;
        break;
      case 'start_system':
        // Trigger system activation
        window.dispatchEvent(new CustomEvent('jarvis-start-system', { 
          detail: { systemId: action.systemId } 
        }));
        break;
      case 'open_control_panel':
        window.dispatchEvent(new CustomEvent('jarvis-open-control-panel'));
        break;
      default:
        console.log('Unknown action:', action);
    }
  }

  /**
   * Мгновенная локальная реакция на активацию (как у внешнего JARVIS)
   */
  private getQuickActivationResponse(wakePhrase: string): string {
    const responses = {
      "джарвис": "Слушаю.",
      "привет джарвис": "Привет. Готов к работе.",
      "эй джарвис": "Да, сэр?",
      "jarvis": "At your service.",
      "hey jarvis": "Yes, sir?",
      "hi jarvis": "Hello. Ready when you are.",
      "wake up jarvis": "System online. Ready to assist."
    };
    
    // Найти наиболее подходящий ответ
    for (const [wake, response] of Object.entries(responses)) {
      if (wakePhrase.toLowerCase().includes(wake.toLowerCase())) {
        return response;
      }
    }
    
    return "Ready.";
  }

  /**
   * Быстрая речь (как у внешнего JARVIS - ускоренный темп)
   */
  private speakFast(text: string): Promise<void> {
    return new Promise((resolve, reject) => {
      if (!this.synthesis) {
        reject(new Error('Speech synthesis not available'));
        return;
      }

      const utterance = new SpeechSynthesisUtterance(text);
      utterance.rate = 1.3; // Ускоренный темп как у него
      utterance.pitch = 1.1; // Слегка повышенный тон
      utterance.volume = 0.9;
      
      // Быстрый голос для мгновенной реакции
      const voices = this.synthesis.getVoices();
      const fastVoice = voices.find(voice => 
        voice.name.includes('Google') && voice.lang.startsWith('en')
      ) || voices.find(voice => voice.lang.startsWith('en'));
      
      if (fastVoice) {
        utterance.voice = fastVoice;
      }

      utterance.onend = () => resolve();
      utterance.onerror = (error) => reject(error);

      this.synthesis.speak(utterance);
    });
  }

  /**
   * Speak text using Web Speech API
   */
  private speak(text: string): Promise<void> {
    return new Promise((resolve, reject) => {
      if (!this.synthesis) {
        reject(new Error('Speech synthesis not available'));
        return;
      }

      const utterance = new SpeechSynthesisUtterance(text);
      utterance.rate = 0.9;
      utterance.pitch = 1.0;
      utterance.volume = 0.8;
      
      // Use a professional, clear voice
      const voices = this.synthesis.getVoices();
      const preferredVoice = voices.find(voice => 
        voice.name.includes('Google') && voice.lang.startsWith('en')
      ) || voices.find(voice => voice.lang.startsWith('en'));
      
      if (preferredVoice) {
        utterance.voice = preferredVoice;
      }

      utterance.onend = () => resolve();
      utterance.onerror = (error) => reject(error);

      this.synthesis.speak(utterance);
    });
  }

  /**
   * Deactivate JARVIS session
   */
  private deactivateJARVIS(): void {
    if (this.currentSession) {
      this.currentSession.isActive = false;
      this.currentSession = null;
      console.log('🤖 JARVIS session deactivated');
    }
  }

  /**
   * Utility methods
   */
  private generateSessionId(): string {
    return `jarvis-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`;
  }

  private getTimeOfDay(): string {
    const hour = new Date().getHours();
    if (hour < 12) return 'morning';
    if (hour < 17) return 'afternoon';
    if (hour < 21) return 'evening';
    return 'night';
  }

  private async getRecentSessions(): Promise<any[]> {
    try {
      const response = await apiRequest('/api/voice/recent-sessions');
      return response.sessions || [];
    } catch {
      return [];
    }
  }

  /**
   * Public methods
   */
  public stop(): void {
    this.wakeWords.enabled = false;
    if (this.recognition && this.isListening) {
      this.recognition.stop();
    }
    this.deactivateJARVIS();
  }

  public isActive(): boolean {
    return this.currentSession?.isActive || false;
  }

  public getCurrentSession(): VoiceSession | null {
    return this.currentSession;
  }

  // Expose communication interface with context awareness
  async sendMessage(content: string, type: 'voice' | 'text' = 'voice', isAmbientListening: boolean = false): Promise<void> {
    // Send to JARVIS organism with context awareness
    try {
      // Import context awareness module
      const { jarvisContextAware } = await import('./jarvis-context-aware');
      
      const response = await jarvisContextAware.sendMessage(content, isAmbientListening);
      
      if (response.success && response.response) {
        await this.speak(response.response);
      } else if (isAmbientListening && !response.shouldActivate) {
        // JARVIS decided not to respond in ambient mode
        console.log(`🔇 JARVIS ambient silence: ${response.reasoning}`);
      }
    } catch (error) {
      console.error('Context-aware message failed:', error);
      // Fallback to direct JARVIS communication
      await this.sendToJarvis(content);
    }
  }
}

// Export singleton instance
export const invisibleJARVIS = new InvisibleJARVIS();
export default invisibleJARVIS;