import React, { useState, useEffect, useRef } from 'react';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { apiRequest } from '@/lib/queryClient';
import { useToast } from '@/hooks/use-toast';
import { Mic, MicOff, Eye, Hand, Zap, Cpu, Smartphone } from 'lucide-react';

interface HolographicElement {
  id: string;
  type: string;
  level: number;
  position: { x: number; y: number; z: number };
  visualProperties: {
    color: string;
    opacity: number;
    material: string;
    animation: string;
  };
}

interface WorkspaceStatus {
  initialized: boolean;
  workspace?: {
    id: string;
    name: string;
    elementCount: number;
    anchorCount: number;
  };
  capabilities?: {
    arkitVersion: string;
    metalSupport: boolean;
    visionFrameworkVersion: string;
    deviceModel: string;
    supportedFeatures: {
      spatialTracking: boolean;
      handTracking: boolean;
      faceTracking: boolean;
      objectDetection: boolean;
      planeDetection: boolean;
      lightEstimation: boolean;
    };
  };
}

export default function JarvisHolographicV2() {
  const [workspaceStatus, setWorkspaceStatus] = useState<WorkspaceStatus | null>(null);
  const [isInitialized, setIsInitialized] = useState(false);
  const [isListening, setIsListening] = useState(false);
  const [voiceCommand, setVoiceCommand] = useState('');
  const [elements, setElements] = useState<HolographicElement[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const [systemLogs, setSystemLogs] = useState<string[]>([]);
  const { toast } = useToast();
  
  const userId = 'demo-user';

  useEffect(() => {
    checkSystemStatus();
  }, []);

  const addLog = (message: string) => {
    setSystemLogs(prev => [...prev.slice(-4), `${new Date().toLocaleTimeString()}: ${message}`]);
  };

  const checkSystemStatus = async () => {
    try {
      const response = await apiRequest('GET', `/api/jarvis/holographic/status`);
      setWorkspaceStatus(response);
      setIsInitialized(response.success && response.status?.initialized);
      addLog(response.success ? 'System status checked' : 'System not initialized');
    } catch (error) {
      addLog('Failed to check system status');
    }
  };

  const initializeSystem = async () => {
    setIsLoading(true);
    try {
      const response = await apiRequest('POST', `/api/jarvis/holographic/initialize`);
      if (response.success) {
        setWorkspaceStatus(response);
        setIsInitialized(true);
        addLog('Holographic system initialized');
        toast({
          title: "🎭 Holographic System Initialized",
          description: "Native iOS ARKit + Metal integration ready",
        });
      }
    } catch (error) {
      addLog('Failed to initialize system');
      toast({
        title: "Initialization Failed",
        description: "Could not initialize holographic system",
        variant: "destructive"
      });
    } finally {
      setIsLoading(false);
    }
  };

  const createHolographicElement = async () => {
    try {
      const elementData = {
        type: 'project',
        level: 0,
        position: { x: Math.random() * 2 - 1, y: 0.5, z: -0.5 },
        visualProperties: {
          color: '#00ffff',
          opacity: 0.8,
          material: 'holographic',
          animation: 'pulse'
        }
      };

      const response = await apiRequest('POST', '/api/jarvis/holographic/create-hologram', { 
        content: elementData, 
        position: elementData.position,
        properties: elementData.visualProperties
      });
      if (response.success) {
        setElements(prev => [...prev, response.element]);
        addLog(`Created element: ${response.element.id}`);
        toast({
          title: "🎭 Element Created",
          description: `Holographic element ${response.element.id} materialized`,
        });
      }
    } catch (error) {
      addLog('Failed to create element');
    }
  };

  const processVoiceCommand = async () => {
    if (!voiceCommand.trim()) return;

    setIsLoading(true);
    try {
      const response = await apiRequest('POST', '/api/jarvis/holographic/voice-command', {
        command: voiceCommand,
        userId
      });

      if (response.success) {
        addLog(`Voice: "${voiceCommand}" → ${response.response}`);
        toast({
          title: "🎙️ Voice Command Processed",
          description: response.response,
        });
        setVoiceCommand('');
        
        // Refresh status after command
        setTimeout(checkSystemStatus, 500);
      }
    } catch (error) {
      addLog('Voice command failed');
    } finally {
      setIsLoading(false);
    }
  };

  const simulateHandGesture = (gestureType: string) => {
    addLog(`Hand gesture: ${gestureType} detected`);
    toast({
      title: "👋 Hand Gesture Detected",
      description: `${gestureType} gesture processed via Vision Framework`,
    });
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-950 via-gray-900 to-slate-900 text-white">
      <div className="container mx-auto px-4 py-8">
        {/* Header */}
        <div className="text-center mb-8">
          <h1 className="text-4xl font-bold mb-4 bg-gradient-to-r from-cyan-400 to-blue-500 bg-clip-text text-transparent">
            JARVIS Holographic System V2
          </h1>
          <p className="text-gray-400 mb-6">
            Native iOS ARKit + Metal • Vision Framework Hand Tracking • Breakthrough Air Manipulation
          </p>
          
          {!isInitialized && (
            <Button 
              onClick={initializeSystem} 
              disabled={isLoading}
              className="bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-600 hover:to-blue-700 text-white font-semibold px-8 py-3 rounded-lg shadow-lg transition-all duration-300"
            >
              {isLoading ? 'Initializing...' : 'Initialize Holographic System'}
            </Button>
          )}
        </div>

        {isInitialized && workspaceStatus && (
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {/* System Status */}
            <Card className="bg-gray-800/50 border-gray-700 p-6">
              <h2 className="text-xl font-semibold text-cyan-400 mb-4 flex items-center gap-2">
                <Cpu className="w-5 h-5" />
                System Status
              </h2>
              
              <div className="space-y-3">
                <div className="flex justify-between items-center">
                  <span className="text-gray-300">Workspace:</span>
                  <Badge variant="secondary">{workspaceStatus.workspace?.name}</Badge>
                </div>
                
                <div className="flex justify-between items-center">
                  <span className="text-gray-300">Elements:</span>
                  <Badge variant="outline">{workspaceStatus.workspace?.elementCount || 0}</Badge>
                </div>
                
                <div className="flex justify-between items-center">
                  <span className="text-gray-300">Anchors:</span>
                  <Badge variant="outline">{workspaceStatus.workspace?.anchorCount || 0}</Badge>
                </div>

                {workspaceStatus.capabilities && (
                  <div className="mt-4 pt-4 border-t border-gray-600">
                    <h3 className="text-sm font-medium text-cyan-400 mb-2">iOS Capabilities</h3>
                    <div className="grid grid-cols-2 gap-2 text-xs">
                      <div className="flex justify-between">
                        <span>ARKit:</span>
                        <span className="text-green-400">{workspaceStatus.capabilities.arkitVersion}</span>
                      </div>
                      <div className="flex justify-between">
                        <span>Metal:</span>
                        <span className="text-green-400">{workspaceStatus.capabilities.metalSupport ? 'Yes' : 'No'}</span>
                      </div>
                      <div className="flex justify-between">
                        <span>Vision:</span>
                        <span className="text-green-400">{workspaceStatus.capabilities.visionFrameworkVersion}</span>
                      </div>
                      <div className="flex justify-between">
                        <span>Device:</span>
                        <span className="text-green-400">{workspaceStatus.capabilities.deviceModel}</span>
                      </div>
                    </div>
                  </div>
                )}
              </div>
            </Card>

            {/* Voice Commands */}
            <Card className="bg-gray-800/50 border-gray-700 p-6">
              <h2 className="text-xl font-semibold text-cyan-400 mb-4 flex items-center gap-2">
                <Mic className="w-5 h-5" />
                Voice Control
              </h2>
              
              <div className="space-y-4">
                <div className="flex gap-2">
                  <Input
                    value={voiceCommand}
                    onChange={(e) => setVoiceCommand(e.target.value)}
                    placeholder="Say something to JARVIS..."
                    className="bg-gray-700 border-gray-600 text-white"
                    onKeyDown={(e) => e.key === 'Enter' && processVoiceCommand()}
                  />
                  <Button
                    onClick={processVoiceCommand}
                    disabled={isLoading || !voiceCommand.trim()}
                    className="bg-cyan-600 hover:bg-cyan-700"
                  >
                    Send
                  </Button>
                </div>

                <div className="grid grid-cols-2 gap-2">
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => setVoiceCommand('create new project')}
                    className="text-xs"
                  >
                    Create Project
                  </Button>
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => setVoiceCommand('show elements')}
                    className="text-xs"
                  >
                    Show Elements
                  </Button>
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => setVoiceCommand('reset workspace')}
                    className="text-xs"
                  >
                    Reset Workspace
                  </Button>
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => setVoiceCommand('покажи голограммы')}
                    className="text-xs"
                  >
                    Russian Command
                  </Button>
                </div>
              </div>
            </Card>

            {/* Hand Tracking */}
            <Card className="bg-gray-800/50 border-gray-700 p-6">
              <h2 className="text-xl font-semibold text-cyan-400 mb-4 flex items-center gap-2">
                <Hand className="w-5 h-5" />
                Air Manipulation
              </h2>
              
              <div className="space-y-4">
                <p className="text-sm text-gray-400 mb-4">
                  Vision Framework hand tracking with 21-point detection
                </p>

                <div className="grid grid-cols-2 gap-3">
                  <Button
                    variant="outline"
                    onClick={() => simulateHandGesture('Pinch')}
                    className="text-sm hover:bg-cyan-900/20 border-cyan-600"
                  >
                    👌 Pinch
                  </Button>
                  <Button
                    variant="outline"
                    onClick={() => simulateHandGesture('Grab')}
                    className="text-sm hover:bg-cyan-900/20 border-cyan-600"
                  >
                    ✊ Grab
                  </Button>
                  <Button
                    variant="outline"
                    onClick={() => simulateHandGesture('Point')}
                    className="text-sm hover:bg-cyan-900/20 border-cyan-600"
                  >
                    👉 Point
                  </Button>
                  <Button
                    variant="outline"
                    onClick={() => simulateHandGesture('Spread')}
                    className="text-sm hover:bg-cyan-900/20 border-cyan-600"
                  >
                    🖐️ Spread
                  </Button>
                </div>

                <div className="mt-4 p-3 bg-gray-700/30 rounded-lg">
                  <p className="text-xs text-gray-400">
                    <strong>Air Manipulation:</strong> Grab holographic objects with hand gestures, 
                    rotate with wrist motion, scale with pinch distance
                  </p>
                </div>
              </div>
            </Card>

            {/* Holographic Elements */}
            <Card className="bg-gray-800/50 border-gray-700 p-6">
              <h2 className="text-xl font-semibold text-cyan-400 mb-4 flex items-center gap-2">
                <Zap className="w-5 h-5" />
                Holographic Elements
              </h2>
              
              <div className="space-y-4">
                <Button
                  onClick={createHolographicElement}
                  className="w-full bg-gradient-to-r from-purple-600 to-cyan-600 hover:from-purple-700 hover:to-cyan-700"
                >
                  + Create Element
                </Button>

                <div className="space-y-2 max-h-64 overflow-y-auto">
                  {elements.length === 0 ? (
                    <p className="text-gray-400 text-sm text-center py-4">
                      No holographic elements created yet
                    </p>
                  ) : (
                    elements.map((element) => (
                      <div key={element.id} className="bg-gray-700/30 p-3 rounded-lg">
                        <div className="flex justify-between items-center mb-2">
                          <span className="text-sm font-medium text-cyan-400">
                            {element.id}
                          </span>
                          <Badge 
                            variant="outline" 
                            style={{ color: element.visualProperties.color }}
                          >
                            {element.type}
                          </Badge>
                        </div>
                        <div className="text-xs text-gray-400">
                          Position: ({element.position.x.toFixed(2)}, {element.position.y.toFixed(2)}, {element.position.z.toFixed(2)})
                        </div>
                        <div className="text-xs text-gray-400">
                          Material: {element.visualProperties.material} • Animation: {element.visualProperties.animation}
                        </div>
                      </div>
                    ))
                  )}
                </div>
              </div>
            </Card>
          </div>
        )}

        {/* System Logs */}
        {isInitialized && (
          <Card className="bg-gray-800/50 border-gray-700 p-6 mt-6">
            <h2 className="text-xl font-semibold text-cyan-400 mb-4 flex items-center gap-2">
              <Eye className="w-5 h-5" />
              System Logs
            </h2>
            
            <div className="bg-black/50 p-4 rounded-lg font-mono text-sm">
              {systemLogs.length === 0 ? (
                <p className="text-gray-500">No logs yet...</p>
              ) : (
                systemLogs.map((log, index) => (
                  <div key={index} className="text-green-400 mb-1">
                    {log}
                  </div>
                ))
              )}
            </div>
          </Card>
        )}

        {/* iOS Setup Instructions */}
        <Card className="bg-gradient-to-r from-blue-900/20 to-purple-900/20 border-blue-700/50 p-6 mt-6">
          <h2 className="text-xl font-semibold text-blue-400 mb-4 flex items-center gap-2">
            <Smartphone className="w-5 h-5" />
            Native iOS Setup
          </h2>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div>
              <h3 className="text-lg font-medium text-blue-300 mb-3">Required Setup</h3>
              <ul className="space-y-2 text-sm text-gray-300">
                <li>• iPhone 12 Pro or newer (LiDAR required)</li>
                <li>• iOS 16+ with ARKit 6.0</li>
                <li>• Metal Performance Shaders support</li>
                <li>• Vision Framework 3.0+ for hand tracking</li>
                <li>• Optimal distance: 30-40cm from device</li>
                <li>• 45-60° viewing angle for best results</li>
              </ul>
            </div>
            
            <div>
              <h3 className="text-lg font-medium text-blue-300 mb-3">Capabilities</h3>
              <ul className="space-y-2 text-sm text-gray-300">
                <li>• Real spatial anchoring with ARKit</li>
                <li>• 21-point hand tracking precision</li>
                <li>• Metal volumetric rendering</li>
                <li>• Persistent holographic memory</li>
                <li>• Tony Stark-level interactions</li>
                <li>• Bio-singularity adaptive layouts</li>
              </ul>
            </div>
          </div>
        </Card>
      </div>
    </div>
  );
}