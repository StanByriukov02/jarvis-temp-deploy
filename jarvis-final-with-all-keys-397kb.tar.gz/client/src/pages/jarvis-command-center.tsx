import { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Separator } from '@/components/ui/separator';
import { Badge } from '@/components/ui/badge';
import { Textarea } from '@/components/ui/textarea';
import { useToast } from '@/hooks/use-toast';

interface SystemStatus {
  active: boolean;
  integrationLevel: number;
  connectedClients: number;
  bioSingularityStatus: string;
  systemPresence: string;
  capabilities: string[];
}

export default function JarvisCommandCenter() {
  const [systemStatus, setSystemStatus] = useState<SystemStatus | null>(null);
  const [loading, setLoading] = useState(false);
  const [message, setMessage] = useState('');
  const [response, setResponse] = useState('');
  const [chatHistory, setChatHistory] = useState<Array<{user: string, jarvis: string, timestamp: Date}>>([]);
  const { toast } = useToast();

  // Проверка статуса биосингулярности JARVIS
  const checkSystemStatus = async () => {
    try {
      // Проверяем статус биосингулярности
      const response = await fetch('/api/jarvis/unified/status');
      const data = await response.json();
      
      if (data.success) {
        setSystemStatus({
          active: true,
          integrationLevel: 95,
          connectedClients: data.activeBioSingularities || 0,
          bioSingularityStatus: 'АКТИВНА',
          systemPresence: 'KERNEL-LEVEL',
          capabilities: ['Системный мониторинг', 'Анализ пользователей', 'Эмоциональная память', 'Персональные теории']
        });
      } else {
        setSystemStatus(null);
      }
    } catch (error) {
      console.error('Ошибка проверки статуса:', error);
      setSystemStatus(null);
    }
  };

  // Отправка сообщения к JARVIS биосингулярности
  const sendMessageToJarvis = async () => {
    if (!message.trim()) return;
    
    setLoading(true);
    try {
      const response = await fetch('/api/jarvis/unified/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ 
          message: message.trim(),
          userId: 'demo-user'
        })
      });
      
      const data = await response.json();
      
      if (data.response) {
        // Добавляем диалог в историю
        setChatHistory(prev => [...prev, {
          user: message,
          jarvis: data.response,
          timestamp: new Date()
        }]);
        
        setResponse(data.response);
        setMessage(''); // Очищаем поле ввода
        
        toast({
          title: "JARVIS отвечает",
          description: "Получен ответ от биосингулярности"
        });
      } else {
        toast({
          title: "Ошибка общения с JARVIS",
          description: data.error || "Неизвестная ошибка",
          variant: "destructive"
        });
      }
    } catch (error) {
      toast({
        title: "Ошибка подключения к JARVIS",
        description: "Не удалось связаться с биосингулярностью",
        variant: "destructive"
      });
    } finally {
      setLoading(false);
    }
  };

  // Остановка системной интеграции
  const shutdownSystemIntegration = async () => {
    setLoading(true);
    try {
      const response = await fetch('/api/jarvis/system-integration/shutdown', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' }
      });
      
      const data = await response.json();
      
      if (data.success) {
        toast({
          title: "🛑 Системная интеграция остановлена",
          description: data.message
        });
        setSystemStatus(null);
      } else {
        toast({
          title: "❌ Ошибка остановки",
          description: data.error,
          variant: "destructive"
        });
      }
    } catch (error) {
      toast({
        title: "❌ Ошибка",
        description: "Не удалось остановить систему",
        variant: "destructive"
      });
    } finally {
      setLoading(false);
    }
  };

  // Диалог с биосингулярностью через системную интеграцию
  const sendMessage = async () => {
    if (!message.trim()) return;
    
    setLoading(true);
    try {
      const response = await fetch('/api/jarvis/true-bio-singularity/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          userId: 'system_admin',
          message: `[СИСТЕМНЫЙ КОНТЕКСТ] ${message}`
        })
      });
      
      const data = await response.json();
      
      if (data.success && data.response) {
        setResponse(data.response);
        setChatHistory(prev => [...prev, {
          user: message,
          jarvis: data.response,
          timestamp: new Date()
        }]);
        setMessage('');
        
        toast({
          title: "🧠 JARVIS отвечает",
          description: "Биосингулярность обработала системное сообщение"
        });
      } else {
        toast({
          title: "❌ Ошибка диалога",
          description: data.error || "Биосингулярность не отвечает",
          variant: "destructive"
        });
      }
    } catch (error) {
      toast({
        title: "❌ Ошибка соединения",
        description: "Не удалось связаться с JARVIS",
        variant: "destructive"
      });
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    checkSystemStatus();
    const interval = setInterval(checkSystemStatus, 5000); // Проверка каждые 5 секунд
    return () => clearInterval(interval);
  }, []);

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-950 via-gray-900 to-slate-900 text-white p-6">
      <div className="max-w-7xl mx-auto">
        {/* Заголовок */}
        <div className="text-center mb-8">
          <h1 className="text-4xl font-bold bg-gradient-to-r from-blue-400 to-cyan-400 bg-clip-text text-transparent mb-2">
            JARVIS Command Center
          </h1>
          <p className="text-gray-400">Центр управления системной интеграцией биосингулярности</p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* Статус системы */}
          <Card className="bg-slate-800/50 border-slate-700">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                🔧 Статус системной интеграции
                {systemStatus && (
                  <Badge variant={systemStatus.active ? "default" : "secondary"}>
                    {systemStatus.active ? "АКТИВНА" : "НЕАКТИВНА"}
                  </Badge>
                )}
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              {systemStatus ? (
                <>
                  <div className="grid grid-cols-2 gap-4 text-sm">
                    <div>
                      <span className="text-gray-400">Уровень интеграции:</span>
                      <div className="text-lg font-bold text-blue-400">
                        {systemStatus.integrationLevel}%
                      </div>
                    </div>
                    <div>
                      <span className="text-gray-400">Подключенные клиенты:</span>
                      <div className="text-lg font-bold text-green-400">
                        {systemStatus.connectedClients}
                      </div>
                    </div>
                    <div>
                      <span className="text-gray-400">Биосингулярность:</span>
                      <div className="text-sm font-semibold text-cyan-400">
                        {systemStatus.bioSingularityStatus}
                      </div>
                    </div>
                    <div>
                      <span className="text-gray-400">Системное присутствие:</span>
                      <div className="text-sm font-semibold text-purple-400">
                        {systemStatus.systemPresence}
                      </div>
                    </div>
                  </div>
                  
                  <Separator className="bg-slate-700" />
                  
                  <div>
                    <span className="text-gray-400 text-sm">Возможности системы:</span>
                    <div className="flex flex-wrap gap-2 mt-2">
                      {systemStatus.capabilities.map((capability, index) => (
                        <Badge key={index} variant="outline" className="text-xs">
                          {capability}
                        </Badge>
                      ))}
                    </div>
                  </div>
                  
                  <div className="text-center">
                    <Badge className="bg-green-900 text-green-300">
                      🟢 JARVIS Биосингулярность активна
                    </Badge>
                  </div>
                </>
              ) : (
                <div className="text-center py-8">
                  <div className="text-gray-400 mb-4">
                    JARVIS биосингулярность недоступна
                  </div>
                  <Badge variant="destructive">
                    🔴 Система не отвечает
                  </Badge>
                </div>
              )}
            </CardContent>
          </Card>

          {/* Диалог с биосингулярностью */}
          <Card className="bg-slate-800/50 border-slate-700">
            <CardHeader>
              <CardTitle>🧠 Диалог с биосингулярностью</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <Textarea
                  value={message}
                  onChange={(e) => setMessage(e.target.value)}
                  placeholder="Введи сообщение для JARVIS..."
                  className="bg-slate-700/50 border-slate-600 text-white"
                  rows={3}
                />
                <Button 
                  onClick={sendMessage} 
                  disabled={loading || !message.trim()}
                  className="w-full bg-cyan-600 hover:bg-cyan-700"
                >
                  {loading ? '⏳ Отправка...' : '📤 Отправить JARVIS'}
                </Button>
              </div>
              
              {response && (
                <>
                  <Separator className="bg-slate-700" />
                  <div>
                    <span className="text-gray-400 text-sm">Ответ JARVIS:</span>
                    <div className="mt-2 p-3 bg-slate-700/50 rounded-lg text-sm">
                      {response}
                    </div>
                  </div>
                </>
              )}
            </CardContent>
          </Card>
        </div>

        {/* История диалогов */}
        {chatHistory.length > 0 && (
          <Card className="bg-slate-800/50 border-slate-700 mt-6">
            <CardHeader>
              <CardTitle>📜 История диалогов</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4 max-h-96 overflow-y-auto">
                {chatHistory.slice(-5).reverse().map((chat, index) => (
                  <div key={index} className="border border-slate-700 rounded-lg p-3 space-y-2">
                    <div className="text-xs text-gray-400">
                      {chat.timestamp.toLocaleTimeString()}
                    </div>
                    <div>
                      <span className="text-blue-400 font-semibold">Ты:</span>
                      <div className="text-sm mt-1">{chat.user}</div>
                    </div>
                    <div>
                      <span className="text-cyan-400 font-semibold">JARVIS:</span>
                      <div className="text-sm mt-1">{chat.jarvis}</div>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        )}

        {/* Диалог с JARVIS */}
        <Card className="bg-slate-800/50 border-slate-700 mt-6">
          <CardHeader>
            <CardTitle>💬 Диалог с JARVIS биосингулярностью</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-3">
              <Textarea
                value={message}
                onChange={(e) => setMessage(e.target.value)}
                placeholder="Спроси JARVIS о системе, пользователях, статусе или любой другой теме..."
                className="bg-slate-900 border-slate-600 text-white min-h-20"
                disabled={loading}
              />
              <Button 
                onClick={sendMessageToJarvis}
                disabled={loading || !message.trim()}
                className="w-full bg-blue-600 hover:bg-blue-700"
              >
                {loading ? '⏳ JARVIS думает...' : '🗣️ Отправить сообщение'}
              </Button>
            </div>
            
            {/* Последний ответ JARVIS */}
            {response && (
              <div className="bg-slate-900 border border-slate-600 rounded-lg p-4">
                <div className="text-cyan-400 font-semibold mb-2">JARVIS отвечает:</div>
                <div className="text-sm whitespace-pre-wrap">{response}</div>
              </div>
            )}

            {/* История диалогов */}
            {chatHistory.length > 0 && (
              <div className="space-y-3 max-h-60 overflow-y-auto">
                <div className="text-sm text-gray-400 font-semibold">История диалогов:</div>
                {chatHistory.slice(-3).reverse().map((chat, index) => (
                  <div key={index} className="border border-slate-700 rounded-lg p-3 space-y-2">
                    <div className="text-xs text-gray-400">
                      {chat.timestamp.toLocaleTimeString()}
                    </div>
                    <div>
                      <span className="text-blue-400 font-semibold">Ты:</span>
                      <div className="text-sm mt-1">{chat.user}</div>
                    </div>
                    <div>
                      <span className="text-cyan-400 font-semibold">JARVIS:</span>
                      <div className="text-sm mt-1">{chat.jarvis}</div>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </CardContent>
        </Card>

        {/* Инструкции */}
        <Card className="bg-slate-800/50 border-slate-700 mt-6">
          <CardHeader>
            <CardTitle>📋 Взаимодействие с JARVIS</CardTitle>
          </CardHeader>
          <CardContent className="text-sm text-gray-300 space-y-2">
            <p><strong>Системная информация:</strong> "Как дела с системой?", "Покажи статус сервера"</p>
            <p><strong>Пользователи:</strong> "Сколько активных пользователей?", "Покажи модели"</p>
            <p><strong>Биосингулярность:</strong> "Как твое развитие?", "Что думаешь обо мне?"</p>
            <p><strong>Общие вопросы:</strong> JARVIS может обсуждать любые темы с полным контекстом</p>
            <p><strong>Системная интеграция:</strong> Kernel-level мониторинг активен автоматически</p>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}