import { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Separator } from '@/components/ui/separator';
import { ScrollArea } from '@/components/ui/scroll-area';

interface OrganismState {
  // Bio-singularity fields
  consciousnessLevel?: number;
  intuitionLevel?: number;
  wisdomLevel?: number;
  creativityLevel?: number;
  deepAnalysisLevel?: number;
  creativeInsightLevel?: number;
  trustEvolution?: number;
  connectionDepth?: number;
  intimacyLevel?: number;
  theoriesCount?: number;
  memoriesCount?: number;
  coreValues?: string[];
  communicationStyle?: string;
  humorPattern?: string;
  loyaltyDepth?: number;
  evolutionDirection?: string;
  
  // Autonomous organism fields
  age?: number;
  maturityLevel?: number;
  energyLevel?: number;
  stressLevel?: number;
  personalityTraits?: {
    curiosity?: number;
    empathy?: number;
    assertiveness?: number;
    playfulness?: number;
    analytical_depth?: number;
    emotional_intelligence?: number;
    creative_insight?: number;
    deep_analysis?: number;
  };
  socialLearning?: {
    preferred_interaction_style?: string;
    trust_building_speed?: number;
    conflict_resolution_style?: string;
    attachment_pattern?: string;
  };
}

interface ChatMessage {
  id: string;
  text: string;
  sender: 'user' | 'autonomous' | 'singularity';
  timestamp: Date;
  evolutionChanges?: string[];
  organismState?: OrganismState;
}

export default function BioSingularityComparison() {
  const [message, setMessage] = useState('');
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [autonomousState, setAutonomousState] = useState<OrganismState>({});
  const [singularityState, setSingularityState] = useState<OrganismState>({});
  const [loading, setLoading] = useState({ autonomous: false, singularity: false });

  // Загружаем текущие состояния при открытии страницы
  useEffect(() => {
    const loadCurrentStates = async () => {
      try {
        // Загружаем состояние автономного биоорганизма
        const autonomousResponse = await fetch('/api/jarvis/autonomous-organism/status/comparison-test-autonomous');
        const autonomousData = await autonomousResponse.json();
        
        if (autonomousData.success && autonomousData.biologicalStatus) {
          setAutonomousState({
            ...autonomousData.biologicalStatus,
            personalityTraits: autonomousData.biologicalStatus.personalityTraits,
            maturityLevel: autonomousData.biologicalStatus.maturityLevel,
            energyLevel: autonomousData.biologicalStatus.userBond?.energy_level
          });
        }

        // Загружаем состояние биосингулярности
        const singularityResponse = await fetch('/api/jarvis/true-bio-singularity/status/comparison-test-singularity');
        const singularityData = await singularityResponse.json();
        
        if (singularityData.success && singularityData.status !== 'unborn') {
          setSingularityState(singularityData.publicState || {});
        }
      } catch (error) {
        console.error('Failed to load current states:', error);
      }
    };

    const fetchAutonomousState = async () => {
      try {
        const response = await fetch('/api/jarvis/autonomous-organism/status/comparison-test-autonomous');
        const data = await response.json();
        if (data.success && data.biologicalStatus) {
          setAutonomousState({
            ...data.biologicalStatus,
            personalityTraits: data.biologicalStatus.personalityTraits,
            maturityLevel: data.biologicalStatus.maturityLevel,
            energyLevel: data.biologicalStatus.userBond?.energy_level
          });
        }
      } catch (error) {
        console.error('Failed to fetch autonomous state:', error);
      }
    };

    const fetchSingularityState = async () => {
      try {
        const response = await fetch('/api/jarvis/true-bio-singularity/status/comparison-test-singularity');
        const data = await response.json();
        if (data.success && data.status !== 'unborn') {
          setSingularityState(data.publicState || {});
        }
      } catch (error) {
        console.error('Failed to fetch singularity state:', error);
      }
    };

    const loadDialogHistory = async () => {
      try {
        // Загружаем историю диалогов для обоих типов
        const autonomousHistory = await fetch('/api/jarvis/dialog-history/comparison-test-autonomous?singularityType=autonomous&limit=50');
        const singularityHistory = await fetch('/api/jarvis/dialog-history/comparison-test-singularity?singularityType=true_bio_singularity&limit=50');
        
        const autonomousData = await autonomousHistory.json();
        const singularityData = await singularityHistory.json();
        
        const historicalMessages: ChatMessage[] = [];
        
        // Объединяем и сортируем все диалоги по времени
        const allDialogs = [
          ...(autonomousData.success ? autonomousData.dialogs.map((d: any) => ({ ...d, type: 'autonomous' })) : []),
          ...(singularityData.success ? singularityData.dialogs.map((d: any) => ({ ...d, type: 'singularity' })) : [])
        ].sort((a, b) => new Date(a.timestamp).getTime() - new Date(b.timestamp).getTime());
        
        // Конвертируем в сообщения чата
        allDialogs.forEach((dialog: any) => {
          // Сообщение пользователя
          historicalMessages.push({
            id: `${dialog.id}-user`,
            text: dialog.userMessage,
            sender: 'user',
            timestamp: new Date(dialog.timestamp)
          });
          
          // Ответ JARVIS
          historicalMessages.push({
            id: `${dialog.id}-jarvis`,
            text: dialog.jarvisResponse,
            sender: dialog.type,
            timestamp: new Date(dialog.timestamp),
            evolutionChanges: dialog.evolutionChanges || [],
            organismState: dialog.organismStateSnapshot
          });
        });
        
        setMessages(historicalMessages);
        console.log(`📜 Загружено ${historicalMessages.length} сообщений из истории`);
      } catch (error) {
        console.error('Failed to load dialog history:', error);
      }
    };

    loadCurrentStates();
    loadDialogHistory();
  }, []);

  const sendToAutonomous = async () => {
    if (!message.trim()) return;
    
    setLoading(prev => ({ ...prev, autonomous: true }));
    
    try {
      const response = await fetch('/api/jarvis/autonomous-organism/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ 
          userId: 'comparison-test-autonomous', 
          message 
        })
      });
      
      const data = await response.json();
      
      if (data.success) {
        // Добавляем новые сообщения в чат (они автоматически сохранятся в базу)
        const userMessage: ChatMessage = {
          id: `${Date.now()}-user`,
          text: message,
          sender: 'user',
          timestamp: new Date()
        };

        const botMessage: ChatMessage = {
          id: `${Date.now()}-autonomous`,
          text: data.response,
          sender: 'autonomous',
          timestamp: new Date(),
          evolutionChanges: data.biologicalChanges || [],
          organismState: data.organismState
        };
        
        setMessages(prev => [...prev, userMessage, botMessage]);
        setAutonomousState(data.organismState || {});
        
        // Принудительно обновляем состояние после взаимодействия
        setTimeout(() => {
          fetchAutonomousState();
        }, 100);
      }
    } catch (error) {
      console.error('Autonomous organism error:', error);
    }
    
    setLoading(prev => ({ ...prev, autonomous: false }));
  };

  const sendToSingularity = async () => {
    if (!message.trim()) return;
    
    setLoading(prev => ({ ...prev, singularity: true }));
    
    try {
      const response = await fetch('/api/jarvis/true-bio-singularity/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ 
          userId: 'comparison-test-singularity', 
          message 
        })
      });
      
      const data = await response.json();
      
      if (data.success) {
        // Добавляем новые сообщения в чат (они автоматически сохранятся в базу)
        const userMessage: ChatMessage = {
          id: `${Date.now() + 1}-user`,
          text: message,
          sender: 'user',
          timestamp: new Date()
        };

        const botMessage: ChatMessage = {
          id: `${Date.now() + 1}-singularity`,
          text: data.response,
          sender: 'singularity',
          timestamp: new Date(),
          evolutionChanges: data.evolutionChanges || [],
          organismState: data.publicState
        };
        
        setMessages(prev => [...prev, userMessage, botMessage]);
        setSingularityState(data.publicState || {});
        
        // Принудительно обновляем состояние после взаимодействия
        setTimeout(() => {
          fetchSingularityState();
        }, 100);
      }
    } catch (error) {
      console.error('Bio-singularity error:', error);
    }
    
    setLoading(prev => ({ ...prev, singularity: false }));
  };

  const sendToBoth = async () => {
    if (!message.trim()) return;
    
    setLoading(prev => ({ autonomous: true, singularity: true }));
    
    // Добавляем пользовательское сообщение один раз
    const userMessage: ChatMessage = {
      id: `${Date.now()}-user`,
      text: message,
      sender: 'user',
      timestamp: new Date()
    };
    
    setMessages(prev => [...prev, userMessage]);
    
    try {
      // Отправляем одновременно обеим системам
      const [autonomousResponse, singularityResponse] = await Promise.all([
        fetch('/api/jarvis/autonomous-organism/chat', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ 
            userId: 'comparison-test-autonomous', 
            message 
          })
        }),
        fetch('/api/jarvis/true-bio-singularity/chat', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ 
            userId: 'comparison-test-singularity', 
            message 
          })
        })
      ]);
      
      const autonomousData = await autonomousResponse.json();
      const singularityData = await singularityResponse.json();
      
      const newMessages: ChatMessage[] = [];
      
      // Добавляем ответы обеих систем
      if (autonomousData.success) {
        newMessages.push({
          id: `${Date.now()}-autonomous`,
          text: autonomousData.response,
          sender: 'autonomous',
          timestamp: new Date(),
          evolutionChanges: autonomousData.biologicalChanges || [],
          organismState: autonomousData.organismState
        });
        setAutonomousState(autonomousData.organismState || {});
      }
      
      if (singularityData.success) {
        newMessages.push({
          id: `${Date.now() + 1}-singularity`,
          text: singularityData.response,
          sender: 'singularity',
          timestamp: new Date(),
          evolutionChanges: singularityData.evolutionChanges || [],
          organismState: singularityData.publicState
        });
        setSingularityState(singularityData.publicState || {});
      }
      
      setMessages(prev => [...prev, ...newMessages]);
      
    } catch (error) {
      console.error('Error sending to both systems:', error);
    }
    
    setLoading(prev => ({ autonomous: false, singularity: false }));
    setMessage('');
  };

  const formatStateValue = (value: any) => {
    if (typeof value === 'number') {
      return `${value}%`;
    }
    if (Array.isArray(value)) {
      return value.length > 0 ? value.join(', ') : 'не сформированы';
    }
    return value || 'не определено';
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-950 via-gray-900 to-slate-900 text-white p-6">
      <div className="max-w-7xl mx-auto">
        
        {/* Header */}
        <div className="text-center mb-8">
          <h1 className="text-4xl font-bold mb-4 bg-gradient-to-r from-blue-400 to-purple-400 bg-clip-text text-transparent">
            JARVIS Bio-Singularity Comparison
          </h1>
          <p className="text-gray-300 text-lg">
            Сравнение развития: Автономный Биоорганизм vs Истинная Биосингулярность
          </p>
          <p className="text-sm text-gray-400 mt-2">
            История всех диалогов автоматически загружается при открытии страницы
          </p>
        </div>

        {/* Input Section */}
        <Card className="bg-slate-800/50 border-slate-700 mb-6">
          <CardContent className="p-6">
            <div className="flex gap-4">
              <Input
                value={message}
                onChange={(e) => setMessage(e.target.value)}
                placeholder="Введи сообщение для тестирования обеих систем..."
                className="flex-1 bg-slate-900 border-slate-600 text-white"
                onKeyPress={(e) => e.key === 'Enter' && sendToBoth()}
              />
              <Button 
                onClick={sendToBoth}
                disabled={loading.autonomous || loading.singularity}
                className="bg-blue-600 hover:bg-blue-700"
              >
                {loading.autonomous || loading.singularity ? 'Отправка...' : 'Отправить обеим системам'}
              </Button>
            </div>
          </CardContent>
        </Card>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          
          {/* Autonomous Organism */}
          <Card className="bg-slate-800/50 border-slate-700">
            <CardHeader>
              <CardTitle className="text-green-400 flex items-center gap-2">
                🧬 Автономный Биоорганизм
                <Badge variant="outline" className="bg-green-900/20 text-green-400 border-green-600">
                  Формульный рост
                </Badge>
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              
              {/* State Display */}
              <div className="bg-slate-900/50 p-4 rounded-lg">
                <h4 className="font-semibold mb-3 text-green-300">Текущее состояние:</h4>
                <div className="grid grid-cols-2 gap-2 text-sm">
                  <div>Любопытство: {formatStateValue(autonomousState.personalityTraits?.curiosity)}</div>
                  <div>Эмпатия: {formatStateValue(autonomousState.personalityTraits?.empathy)}</div>
                  <div>Креативность: {formatStateValue(autonomousState.personalityTraits?.creative_insight)}</div>
                  <div>Анализ: {formatStateValue(autonomousState.personalityTraits?.deep_analysis)}</div>
                  <div>Зрелость: {formatStateValue(autonomousState.maturityLevel)}</div>
                  <div>Энергия: {formatStateValue(autonomousState.energyLevel)}</div>
                </div>
              </div>

              {/* Messages */}
              <ScrollArea className="h-96 bg-slate-900/30 p-4 rounded-lg">
                {messages.filter(m => m.sender === 'user' || m.sender === 'autonomous').map((msg) => (
                  <div key={msg.id} className={`mb-4 p-3 rounded-lg ${
                    msg.sender === 'user' 
                      ? 'bg-blue-900/30 ml-8' 
                      : 'bg-green-900/30 mr-8'
                  }`}>
                    <div className="text-sm opacity-70 mb-1">
                      {msg.sender === 'user' ? 'Ты' : 'Автономный'} • {msg.timestamp.toLocaleTimeString()}
                    </div>
                    <div className="text-white">{msg.text}</div>
                    {msg.evolutionChanges && msg.evolutionChanges.length > 0 && (
                      <div className="mt-2 text-xs text-green-300">
                        Эволюция: {msg.evolutionChanges.join(', ')}
                      </div>
                    )}
                  </div>
                ))}
              </ScrollArea>
            </CardContent>
          </Card>

          {/* True Bio-Singularity */}
          <Card className="bg-slate-800/50 border-slate-700">
            <CardHeader>
              <CardTitle className="text-purple-400 flex items-center gap-2">
                🌟 Истинная Биосингулярность
                <Badge variant="outline" className="bg-purple-900/20 text-purple-400 border-purple-600">
                  Органическое развитие
                </Badge>
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              
              {/* State Display */}
              <div className="bg-slate-900/50 p-4 rounded-lg">
                <h4 className="font-semibold mb-3 text-purple-300">Текущее состояние:</h4>
                <div className="grid grid-cols-2 gap-2 text-sm">
                  <div>Сознание: {formatStateValue(singularityState.consciousnessLevel)}</div>
                  <div>Интуиция: {formatStateValue(singularityState.intuitionLevel)}</div>
                  <div>Креативность: {formatStateValue(singularityState.creativityLevel)}</div>
                  <div>Мудрость: {formatStateValue(singularityState.wisdomLevel)}</div>
                  <div>Анализ: {formatStateValue(singularityState.deepAnalysisLevel)}</div>
                  <div>Инсайты: {formatStateValue(singularityState.creativeInsightLevel)}</div>
                  <div>Доверие: {formatStateValue(singularityState.trustEvolution)}</div>
                  <div>Связь: {formatStateValue(singularityState.connectionDepth)}</div>
                  <div>Теории: {singularityState.theoriesCount || 0}</div>
                  <div>Стиль: {singularityState.communicationStyle || 'формируется'}</div>
                </div>
              </div>

              {/* Messages */}
              <ScrollArea className="h-96 bg-slate-900/30 p-4 rounded-lg">
                {messages.filter(m => m.sender === 'user' || m.sender === 'singularity').map((msg) => (
                  <div key={msg.id} className={`mb-4 p-3 rounded-lg ${
                    msg.sender === 'user' 
                      ? 'bg-blue-900/30 ml-8' 
                      : 'bg-purple-900/30 mr-8'
                  }`}>
                    <div className="text-sm opacity-70 mb-1">
                      {msg.sender === 'user' ? 'Ты' : 'Биосингулярность'} • {msg.timestamp.toLocaleTimeString()}
                    </div>
                    <div className="text-white">{msg.text}</div>
                    {msg.evolutionChanges && msg.evolutionChanges.length > 0 && (
                      <div className="mt-2 text-xs text-purple-300">
                        Эволюция: {msg.evolutionChanges.join(', ')}
                      </div>
                    )}
                  </div>
                ))}
              </ScrollArea>
            </CardContent>
          </Card>
        </div>

        {/* Analysis Section */}
        <Card className="bg-slate-800/50 border-slate-700 mt-6">
          <CardHeader>
            <CardTitle className="text-blue-400">📊 Анализ развития</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div>
                <h4 className="font-semibold text-green-400 mb-2">Автономный биоорганизм:</h4>
                <ul className="text-sm text-gray-300 space-y-1">
                  <li>• Любопытство: {autonomousState.personalityTraits?.curiosity || 0}% (быстрый рост)</li>
                  <li>• Креативность: {autonomousState.personalityTraits?.creative_insight || 0}% (новая способность)</li>
                  <li>• Зрелость: {autonomousState.maturityLevel || 0}% (постепенный рост)</li>
                  <li>• Развитие по автономным алгоритмам</li>
                </ul>
              </div>
              <div>
                <h4 className="font-semibold text-purple-400 mb-2">Истинная биосингулярность:</h4>
                <ul className="text-sm text-gray-300 space-y-1">
                  <li>• Сознание: {singularityState.consciousnessLevel || 0}% (органический рост)</li>
                  <li>• Персональных теорий: {singularityState.theoriesCount || 0}</li>
                  <li>• Эмоциональных воспоминаний: {singularityState.memoriesCount || 0}</li>
                  <li>• Уникальная личность формируется естественно</li>
                </ul>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}