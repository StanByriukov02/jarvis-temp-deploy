import { useState, useRef } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Mic, MicOff, Volume2 } from 'lucide-react';
import { apiRequest } from '@/lib/queryClient';

export default function VoiceTest() {
  const [isActivated, setIsActivated] = useState(false);
  const [isRecording, setIsRecording] = useState(false);
  const [status, setStatus] = useState('Система не активирована');
  const [response, setResponse] = useState('');
  const mediaRecorderRef = useRef<MediaRecorder | null>(null);
  const audioChunksRef = useRef<Blob[]>([]);

  // Активация JARVIS
  const activateJarvis = async () => {
    try {
      setStatus('Активирую JARVIS...');
      const result = await apiRequest('POST', '/api/jarvis/voice/activate', {
        userId: 'demo-user'
      });
      
      if (result.success) {
        setIsActivated(true);
        setStatus('JARVIS активирован - произнесите фразу "гром начинается"');
        setResponse('JARVIS готов к работе');
      }
    } catch (error) {
      console.error('Voice activation error:', error);
      setStatus('Ошибка активации');
    }
  };

  // Деактивация JARVIS
  const deactivateJarvis = async () => {
    try {
      await apiRequest('POST', '/api/jarvis/voice/deactivate');
      setIsActivated(false);
      setStatus('JARVIS деактивирован');
      setResponse('');
    } catch (error) {
      console.error('Voice deactivation error:', error);
    }
  };

  // Начать запись
  const startRecording = async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      mediaRecorderRef.current = new MediaRecorder(stream);
      audioChunksRef.current = [];

      mediaRecorderRef.current.ondataavailable = (event) => {
        audioChunksRef.current.push(event.data);
      };

      mediaRecorderRef.current.onstop = async () => {
        const audioBlob = new Blob(audioChunksRef.current, { type: 'audio/wav' });
        await processAudio(audioBlob);
      };

      mediaRecorderRef.current.start();
      setIsRecording(true);
      setStatus('Слушаю...');
    } catch (error) {
      console.error('Recording error:', error);
      setStatus('Ошибка записи');
    }
  };

  // Остановить запись
  const stopRecording = () => {
    if (mediaRecorderRef.current && isRecording) {
      mediaRecorderRef.current.stop();
      setIsRecording(false);
      setStatus('Обрабатываю команду...');
      
      // Остановить все аудио треки
      mediaRecorderRef.current.stream?.getTracks().forEach(track => track.stop());
    }
  };

  // Обработка аудио
  const processAudio = async (audioBlob: Blob) => {
    try {
      // Конвертируем в base64
      const arrayBuffer = await audioBlob.arrayBuffer();
      const base64Audio = btoa(String.fromCharCode(...new Uint8Array(arrayBuffer)));

      const result = await apiRequest('POST', '/api/jarvis/voice/command', {
        audioData: base64Audio,
        userId: 'demo-user'
      });

      if (result.success) {
        setResponse(result.result.message);
        setStatus('Команда обработана');
        
        // Воспроизвести аудио ответ если есть
        if (result.result.audio) {
          playAudioResponse(result.result.audio);
        }
      }
    } catch (error) {
      console.error('Audio processing error:', error);
      setStatus('Ошибка обработки команды');
    }
  };

  // Воспроизведение аудио ответа
  const playAudioResponse = (audioBase64: string) => {
    try {
      const audioBlob = new Blob([
        new Uint8Array(atob(audioBase64).split('').map(c => c.charCodeAt(0)))
      ], { type: 'audio/mpeg' });
      
      const audioUrl = URL.createObjectURL(audioBlob);
      const audio = new Audio(audioUrl);
      audio.play();
    } catch (error) {
      console.error('Audio playback error:', error);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-950 via-gray-900 to-slate-900 p-8">
      <div className="max-w-4xl mx-auto">
        <div className="text-center mb-8">
          <h1 className="text-4xl font-bold text-white mb-4">
            JARVIS Voice Activation Test
          </h1>
          <p className="text-gray-300">
            Тестирование голосовой активации с био-сингулярностью
          </p>
        </div>

        <div className="grid gap-6">
          {/* Контроль активации */}
          <Card className="border-blue-500/20 bg-slate-800/50">
            <CardHeader>
              <CardTitle className="text-white flex items-center gap-2">
                <Volume2 className="w-5 h-5" />
                Активация JARVIS
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="flex gap-4">
                <Button
                  onClick={activateJarvis}
                  disabled={isActivated}
                  className="bg-blue-600 hover:bg-blue-700"
                >
                  Активировать JARVIS
                </Button>
                <Button
                  onClick={deactivateJarvis}
                  disabled={!isActivated}
                  variant="destructive"
                >
                  Деактивировать
                </Button>
              </div>
            </CardContent>
          </Card>

          {/* Голосовая запись */}
          <Card className="border-green-500/20 bg-slate-800/50">
            <CardHeader>
              <CardTitle className="text-white flex items-center gap-2">
                <Mic className="w-5 h-5" />
                Голосовые команды
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="flex gap-4">
                <Button
                  onClick={startRecording}
                  disabled={!isActivated || isRecording}
                  className="bg-green-600 hover:bg-green-700"
                >
                  <Mic className="w-4 h-4 mr-2" />
                  Начать запись
                </Button>
                <Button
                  onClick={stopRecording}
                  disabled={!isRecording}
                  variant="destructive"
                >
                  <MicOff className="w-4 h-4 mr-2" />
                  Остановить
                </Button>
              </div>
              
              {isRecording && (
                <div className="mt-4 text-center">
                  <div className="inline-flex items-center gap-2 text-green-500">
                    <div className="w-2 h-2 bg-red-500 rounded-full animate-pulse"></div>
                    Запись активна...
                  </div>
                </div>
              )}
            </CardContent>
          </Card>

          {/* Статус */}
          <Card className="border-yellow-500/20 bg-slate-800/50">
            <CardHeader>
              <CardTitle className="text-white">Статус системы</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-yellow-300">{status}</p>
              {response && (
                <div className="mt-4 p-4 bg-slate-700 rounded-lg">
                  <p className="text-white font-semibold">Ответ JARVIS:</p>
                  <p className="text-gray-300 mt-2">{response}</p>
                </div>
              )}
            </CardContent>
          </Card>

          {/* Инструкции */}
          <Card className="border-purple-500/20 bg-slate-800/50">
            <CardHeader>
              <CardTitle className="text-white">Инструкции</CardTitle>
            </CardHeader>
            <CardContent className="text-gray-300 space-y-2">
              <p>1. Нажмите "Активировать JARVIS" для включения системы</p>
              <p>2. Произнесите фразу "гром начинается" для полной авторизации</p>
              <p>3. После авторизации можете общаться с JARVIS голосом</p>
              <p>4. Для деактивации нажмите соответствующую кнопку</p>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}