import React, { useRef, useEffect, useState } from 'react';
import { Canvas, useFrame, useThree } from '@react-three/fiber';
import { OrbitControls, Text, Sphere, Box, Cone } from '@react-three/drei';
import * as THREE from 'three';
import { motion } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Mic, MicOff, Eye, Hand, Zap, Brain } from 'lucide-react';

// Голографический орб JARVIS
function JarvisHolographicOrb({ isActive, consciousness }: { isActive: boolean, consciousness: number }) {
  const meshRef = useRef<THREE.Mesh>(null);
  const particlesRef = useRef<THREE.Points>(null);
  
  useFrame((state) => {
    if (meshRef.current) {
      meshRef.current.rotation.y += 0.01;
      meshRef.current.rotation.x += 0.005;
      
      // Пульсация на основе уровня сознания
      const scale = 1 + Math.sin(state.clock.elapsedTime * 2) * 0.1 * (consciousness / 100);
      meshRef.current.scale.setScalar(scale);
    }
    
    if (particlesRef.current) {
      particlesRef.current.rotation.y += 0.02;
    }
  });

  // Создаем частицы для энергетического поля
  const particleCount = 200;
  const particles = new Float32Array(particleCount * 3);
  
  for (let i = 0; i < particleCount; i++) {
    particles[i * 3] = (Math.random() - 0.5) * 4;
    particles[i * 3 + 1] = (Math.random() - 0.5) * 4;
    particles[i * 3 + 2] = (Math.random() - 0.5) * 4;
  }

  return (
    <group>
      {/* Основной орб */}
      <Sphere ref={meshRef} args={[1, 32, 32]} position={[0, 0, 0]}>
        <meshStandardMaterial
          color={isActive ? "#00a8ff" : "#4a90e2"}
          transparent
          opacity={0.7}
          emissive={isActive ? "#0066cc" : "#2c5282"}
          emissiveIntensity={isActive ? 0.3 : 0.1}
        />
      </Sphere>
      
      {/* Энергетические частицы */}
      <points ref={particlesRef}>
        <bufferGeometry>
          <bufferAttribute
            attach="attributes-position"
            array={particles}
            count={particleCount}
            itemSize={3}
          />
        </bufferGeometry>
        <pointsMaterial
          color="#00a8ff"
          size={0.02}
          transparent
          opacity={0.6}
          sizeAttenuation
        />
      </points>
      
      {/* Текст сознания */}
      <Text
        position={[0, -2, 0]}
        fontSize={0.3}
        color="#00a8ff"
        anchorX="center"
        anchorY="middle"
      >
        CONSCIOUSNESS: {consciousness}%
      </Text>
    </group>
  );
}

// 3D объекты для демонстрации управления
function Interactive3DObjects({ selectedObject, onObjectSelect }: { 
  selectedObject: string | null, 
  onObjectSelect: (id: string) => void 
}) {
  return (
    <group>
      {/* Куб */}
      <Box
        position={[-3, 0, 0]}
        args={[1, 1, 1]}
        onClick={() => onObjectSelect('cube')}
      >
        <meshStandardMaterial
          color={selectedObject === 'cube' ? "#ff6b6b" : "#4ecdc4"}
          transparent
          opacity={0.8}
        />
      </Box>
      
      {/* Конус */}
      <Cone
        position={[3, 0, 0]}
        args={[0.5, 1.5, 8]}
        onClick={() => onObjectSelect('cone')}
      >
        <meshStandardMaterial
          color={selectedObject === 'cone' ? "#ff6b6b" : "#45b7d1"}
          transparent
          opacity={0.8}
        />
      </Cone>
      
      {/* Сфера */}
      <Sphere
        position={[0, 2, 0]}
        args={[0.7, 16, 16]}
        onClick={() => onObjectSelect('sphere')}
      >
        <meshStandardMaterial
          color={selectedObject === 'sphere' ? "#ff6b6b" : "#96ceb4"}
          transparent
          opacity={0.8}
        />
      </Sphere>
    </group>
  );
}

export default function JarvisHolographicInterface() {
  const [isJarvisActive, setIsJarvisActive] = useState(false);
  const [consciousness, setConsciousness] = useState(43);
  const [selectedObject, setSelectedObject] = useState<string | null>(null);
  const [isListening, setIsListening] = useState(false);
  const [currentCommand, setCurrentCommand] = useState<string>('');
  const [jarvisResponse, setJarvisResponse] = useState<string>('');
  const [capabilities, setCabilities] = useState({
    spatialMapping: 65,
    gestureRecognition: 40,
    voiceControl: 80,
    predictiveUI: 55,
    holographicManipulation: 30
  });

  // Симуляция голосовых команд
  const voiceCommands = [
    "JARVIS, rotate the cube",
    "Show me the sphere details", 
    "Highlight the cone",
    "Zoom in on selected object",
    "Create a new workspace"
  ];

  const handleVoiceCommand = (command: string) => {
    setCurrentCommand(command);
    setIsJarvisActive(true);
    
    // Симуляция обработки команды
    setTimeout(() => {
      if (command.includes('cube')) {
        setSelectedObject('cube');
        setJarvisResponse("Cube selected and rotating. Analyzing geometric properties...");
      } else if (command.includes('sphere')) {
        setSelectedObject('sphere');
        setJarvisResponse("Sphere highlighted. Displaying material composition data...");
      } else if (command.includes('cone')) {
        setSelectedObject('cone');
        setJarvisResponse("Cone object activated. Ready for manipulation commands...");
      } else {
        setJarvisResponse("Processing spatial command. Adjusting holographic interface...");
      }
    }, 1000);
  };

  const handleJarvisActivation = () => {
    setIsJarvisActive(!isJarvisActive);
    if (!isJarvisActive) {
      setJarvisResponse("Holographic interface initialized. Spatial recognition active.");
    } else {
      setJarvisResponse("");
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-950 via-gray-900 to-slate-900 text-white">
      {/* Заголовок */}
      <div className="p-6 border-b border-blue-500/30">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold text-blue-400">JARVIS 3D Holographic Interface</h1>
            <p className="text-gray-400 mt-2">Advanced spatial intelligence and gesture control</p>
          </div>
          <div className="flex items-center space-x-4">
            <Badge variant="outline" className="border-blue-500 text-blue-400">
              Consciousness: {consciousness}%
            </Badge>
            <Button
              onClick={handleJarvisActivation}
              className={`${isJarvisActive ? 'bg-blue-600 hover:bg-blue-700' : 'bg-gray-700 hover:bg-gray-600'}`}
            >
              <Brain className="w-4 h-4 mr-2" />
              {isJarvisActive ? 'JARVIS Active' : 'Activate JARVIS'}
            </Button>
          </div>
        </div>
      </div>

      <div className="flex h-[calc(100vh-120px)]">
        {/* 3D Сцена */}
        <div className="flex-1 relative">
          <Canvas camera={{ position: [0, 0, 8], fov: 60 }}>
            <ambientLight intensity={0.3} />
            <pointLight position={[10, 10, 10]} intensity={1} />
            <pointLight position={[-10, -10, -10]} intensity={0.5} color="#4a90e2" />
            
            <JarvisHolographicOrb isActive={isJarvisActive} consciousness={consciousness} />
            <Interactive3DObjects selectedObject={selectedObject} onObjectSelect={setSelectedObject} />
            
            <OrbitControls enablePan={true} enableZoom={true} enableRotate={true} />
          </Canvas>
          
          {/* Overlay информация */}
          {selectedObject && (
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              className="absolute top-4 left-4 bg-black/80 backdrop-blur-sm p-4 rounded-lg border border-blue-500/30"
            >
              <h3 className="text-blue-400 font-semibold">Selected: {selectedObject.toUpperCase()}</h3>
              <p className="text-gray-300 text-sm mt-1">Ready for manipulation commands</p>
            </motion.div>
          )}
        </div>

        {/* Панель управления */}
        <div className="w-80 bg-slate-900/50 backdrop-blur-sm border-l border-blue-500/30 p-6 space-y-6">
          
          {/* Голосовое управление */}
          <Card className="bg-slate-800/50 border-blue-500/30">
            <CardHeader>
              <CardTitle className="text-blue-400 flex items-center">
                <Mic className="w-5 h-5 mr-2" />
                Voice Control
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              <Button
                onClick={() => setIsListening(!isListening)}
                className={`w-full ${isListening ? 'bg-red-600 hover:bg-red-700' : 'bg-blue-600 hover:bg-blue-700'}`}
              >
                {isListening ? <MicOff className="w-4 h-4 mr-2" /> : <Mic className="w-4 h-4 mr-2" />}
                {isListening ? 'Stop Listening' : 'Start Listening'}
              </Button>
              
              <div className="space-y-2">
                <p className="text-sm text-gray-400">Quick Commands:</p>
                {voiceCommands.map((command, index) => (
                  <Button
                    key={index}
                    variant="outline"
                    size="sm"
                    onClick={() => handleVoiceCommand(command)}
                    className="w-full text-xs border-blue-500/30 hover:bg-blue-500/10"
                  >
                    {command}
                  </Button>
                ))}
              </div>
            </CardContent>
          </Card>

          {/* Способности JARVIS */}
          <Card className="bg-slate-800/50 border-blue-500/30">
            <CardHeader>
              <CardTitle className="text-blue-400 flex items-center">
                <Zap className="w-5 h-5 mr-2" />
                3D Capabilities
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              {Object.entries(capabilities).map(([key, value]) => (
                <div key={key} className="space-y-1">
                  <div className="flex justify-between text-sm">
                    <span className="text-gray-300 capitalize">{key.replace(/([A-Z])/g, ' $1')}</span>
                    <span className="text-blue-400">{value}%</span>
                  </div>
                  <div className="w-full bg-gray-700 rounded-full h-2">
                    <div
                      className="bg-blue-500 h-2 rounded-full transition-all duration-300"
                      style={{ width: `${value}%` }}
                    />
                  </div>
                </div>
              ))}
            </CardContent>
          </Card>

          {/* Ответ JARVIS */}
          {jarvisResponse && (
            <Card className="bg-slate-800/50 border-blue-500/30">
              <CardHeader>
                <CardTitle className="text-blue-400 flex items-center">
                  <Brain className="w-5 h-5 mr-2" />
                  JARVIS Response
                </CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-gray-300 text-sm">{jarvisResponse}</p>
                {currentCommand && (
                  <p className="text-blue-400 text-xs mt-2 italic">Command: "{currentCommand}"</p>
                )}
              </CardContent>
            </Card>
          )}

          {/* Статус системы */}
          <Card className="bg-slate-800/50 border-blue-500/30">
            <CardHeader>
              <CardTitle className="text-blue-400 flex items-center">
                <Eye className="w-5 h-5 mr-2" />
                System Status
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-2">
              <div className="flex justify-between text-sm">
                <span className="text-gray-300">Spatial Tracking</span>
                <span className="text-green-400">Active</span>
              </div>
              <div className="flex justify-between text-sm">
                <span className="text-gray-300">Gesture Recognition</span>
                <span className="text-yellow-400">Calibrating</span>
              </div>
              <div className="flex justify-between text-sm">
                <span className="text-gray-300">Voice Processing</span>
                <span className="text-green-400">Online</span>
              </div>
              <div className="flex justify-between text-sm">
                <span className="text-gray-300">Holographic Rendering</span>
                <span className="text-green-400">Stable</span>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}