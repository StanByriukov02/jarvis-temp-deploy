// JARVIS Device Discovery Dashboard - ЭТАП 4
// Управление автоматическим обнаружением устройств

import React, { useState, useEffect } from 'react';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { 
  Search, 
  Smartphone, 
  Laptop, 
  Monitor, 
  Watch,
  Headphones,
  Speaker,
  TabletSmartphone,
  Wifi,
  Shield,
  RefreshCw,
  Settings,
  Trash2,
  CheckCircle,
  XCircle,
  Clock,
  Zap,
  Network
} from 'lucide-react';
import { useToast } from '@/hooks/use-toast';

interface DeviceInfo {
  id: string;
  name: string;
  type: string;
  ipAddress: string;
  macAddress?: string;
  capabilities: string[];
  permissionLevel: string;
  isOnline: boolean;
  lastSeen: number;
  batteryLevel?: number;
  connectionType: string;
  fingerprint: string;
}

interface SystemStatus {
  isScanning: boolean;
  discoveredDevicesCount: number;
  connectedDevicesCount: number;
  scanResultsCount: number;
  continuousScanning: boolean;
  config: any;
}

const JarvisDeviceDiscovery: React.FC = () => {
  const [devices, setDevices] = useState<DeviceInfo[]>([]);
  const [systemStatus, setSystemStatus] = useState<SystemStatus>({
    isScanning: false,
    discoveredDevicesCount: 0,
    connectedDevicesCount: 0,
    scanResultsCount: 0,
    continuousScanning: false,
    config: {}
  });
  
  const [isLoading, setIsLoading] = useState(false);
  const [scanProgress, setScanProgress] = useState(0);
  const [networkRange, setNetworkRange] = useState('192.168.1.0/24');
  const [scanTimeout, setScanTimeout] = useState(5000);
  const [deviceTypes, setDeviceTypes] = useState<string[]>([]);
  const [permissionLevels, setPermissionLevels] = useState<string[]>([]);
  
  const { toast } = useToast();

  useEffect(() => {
    loadSystemStatus();
    loadDeviceTypes();
    loadPermissionLevels();
    loadDevices();
  }, []);

  const loadSystemStatus = async () => {
    try {
      const response = await fetch('/api/jarvis/device-discovery/status');
      if (response.ok) {
        const data = await response.json();
        setSystemStatus(data.status);
      }
    } catch (error) {
      console.error('Error loading system status:', error);
    }
  };

  const loadDevices = async () => {
    try {
      const response = await fetch('/api/jarvis/device-discovery/devices');
      if (response.ok) {
        const data = await response.json();
        setDevices(data.devices);
      }
    } catch (error) {
      console.error('Error loading devices:', error);
    }
  };

  const loadDeviceTypes = async () => {
    try {
      const response = await fetch('/api/jarvis/device-discovery/device-types');
      if (response.ok) {
        const data = await response.json();
        setDeviceTypes(data.deviceTypes);
      }
    } catch (error) {
      console.error('Error loading device types:', error);
    }
  };

  const loadPermissionLevels = async () => {
    try {
      const response = await fetch('/api/jarvis/device-discovery/permission-levels');
      if (response.ok) {
        const data = await response.json();
        setPermissionLevels(data.permissionLevels);
      }
    } catch (error) {
      console.error('Error loading permission levels:', error);
    }
  };

  const startNetworkScan = async () => {
    setIsLoading(true);
    setScanProgress(0);
    
    try {
      const config = {
        networkRange,
        timeout: scanTimeout,
        maxConcurrentScans: 50,
        enablePortScan: true,
        enableMacDetection: true,
        enableDeviceFingerprinting: true
      };

      const response = await fetch('/api/jarvis/device-discovery/start-scan', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ config })
      });

      if (response.ok) {
        toast({
          title: "Сканирование запущено",
          description: `Сканирование сети ${networkRange} начато`
        });

        // Симуляция прогресса
        const progressInterval = setInterval(() => {
          setScanProgress(prev => {
            if (prev >= 100) {
              clearInterval(progressInterval);
              setIsLoading(false);
              loadSystemStatus();
              loadDevices();
              return 100;
            }
            return prev + 10;
          });
        }, 500);
      }
    } catch (error) {
      console.error('Error starting scan:', error);
      setIsLoading(false);
      toast({
        title: "Ошибка сканирования",
        description: "Не удалось запустить сканирование сети",
        variant: "destructive"
      });
    }
  };

  const startContinuousScanning = async () => {
    try {
      const response = await fetch('/api/jarvis/device-discovery/start-continuous-scan', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ intervalMs: 300000 }) // 5 минут
      });

      if (response.ok) {
        toast({
          title: "Непрерывное сканирование включено",
          description: "Устройства будут сканироваться каждые 5 минут"
        });
        loadSystemStatus();
      }
    } catch (error) {
      console.error('Error starting continuous scan:', error);
    }
  };

  const stopContinuousScanning = async () => {
    try {
      const response = await fetch('/api/jarvis/device-discovery/stop-continuous-scan', {
        method: 'POST'
      });

      if (response.ok) {
        toast({
          title: "Непрерывное сканирование остановлено",
          description: "Автоматическое сканирование отключено"
        });
        loadSystemStatus();
      }
    } catch (error) {
      console.error('Error stopping continuous scan:', error);
    }
  };

  const updateDevicePermissions = async (deviceId: string, permissionLevel: string) => {
    try {
      const response = await fetch(`/api/jarvis/device-discovery/device/${deviceId}/permissions`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ permissionLevel })
      });

      if (response.ok) {
        toast({
          title: "Разрешения обновлены",
          description: `Уровень доступа изменен на ${permissionLevel}`
        });
        loadDevices();
      }
    } catch (error) {
      console.error('Error updating permissions:', error);
    }
  };

  const removeDevice = async (deviceId: string) => {
    try {
      const response = await fetch(`/api/jarvis/device-discovery/device/${deviceId}`, {
        method: 'DELETE'
      });

      if (response.ok) {
        toast({
          title: "Устройство удалено",
          description: "Устройство удалено из списка обнаруженных"
        });
        loadDevices();
        loadSystemStatus();
      }
    } catch (error) {
      console.error('Error removing device:', error);
    }
  };

  const getDeviceIcon = (type: string) => {
    switch (type.toLowerCase()) {
      case 'iphone':
      case 'android_phone':
        return <Smartphone className="w-5 h-5" />;
      case 'ipad':
      case 'android_tablet':
        return <TabletSmartphone className="w-5 h-5" />;
      case 'macbook':
        return <Laptop className="w-5 h-5" />;
      case 'imac':
      case 'windows_pc':
      case 'linux_pc':
        return <Monitor className="w-5 h-5" />;
      case 'apple_watch':
        return <Watch className="w-5 h-5" />;
      case 'airpods':
        return <Headphones className="w-5 h-5" />;
      case 'homepod':
        return <Speaker className="w-5 h-5" />;
      default:
        return <Network className="w-5 h-5" />;
    }
  };

  const getPermissionColor = (level: string) => {
    switch (level.toLowerCase()) {
      case 'full': return 'bg-green-500';
      case 'admin': return 'bg-blue-500';
      case 'advanced': return 'bg-yellow-500';
      case 'standard': return 'bg-orange-500';
      case 'basic': return 'bg-gray-500';
      default: return 'bg-gray-400';
    }
  };

  return (
    <div className="space-y-6">
      {/* Заголовок */}
      <div className="flex items-center justify-between">
        <h1 className="text-2xl font-bold">JARVIS Device Discovery - ЭТАП 4</h1>
        <div className="flex items-center gap-2">
          {systemStatus.isScanning && (
            <Badge variant="secondary" className="animate-pulse">
              <Search className="w-3 h-3 mr-1" />
              Сканирование...
            </Badge>
          )}
          {systemStatus.continuousScanning && (
            <Badge variant="default">
              <RefreshCw className="w-3 h-3 mr-1" />
              Авто-сканирование
            </Badge>
          )}
        </div>
      </div>

      {/* Статистика */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center gap-2">
              <Search className="w-5 h-5 text-blue-500" />
              <div>
                <div className="font-semibold">{systemStatus.discoveredDevicesCount}</div>
                <div className="text-sm text-gray-500">Обнаружено</div>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-4">
            <div className="flex items-center gap-2">
              <Wifi className="w-5 h-5 text-green-500" />
              <div>
                <div className="font-semibold">{systemStatus.connectedDevicesCount}</div>
                <div className="text-sm text-gray-500">Подключено</div>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-4">
            <div className="flex items-center gap-2">
              <Network className="w-5 h-5 text-purple-500" />
              <div>
                <div className="font-semibold">{systemStatus.scanResultsCount}</div>
                <div className="text-sm text-gray-500">Результатов</div>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-4">
            <div className="flex items-center gap-2">
              <Shield className="w-5 h-5 text-orange-500" />
              <div>
                <div className="font-semibold">
                  {devices.filter(d => d.permissionLevel !== 'basic').length}
                </div>
                <div className="text-sm text-gray-500">Доверенных</div>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Управление сканированием */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Search className="w-5 h-5" />
            Сканирование сети
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <Label htmlFor="networkRange">Диапазон сети</Label>
                <Input
                  id="networkRange"
                  value={networkRange}
                  onChange={(e) => setNetworkRange(e.target.value)}
                  placeholder="192.168.1.0/24"
                />
              </div>
              <div>
                <Label htmlFor="timeout">Таймаут (мс)</Label>
                <Input
                  id="timeout"
                  type="number"
                  value={scanTimeout}
                  onChange={(e) => setScanTimeout(Number(e.target.value))}
                  placeholder="5000"
                />
              </div>
            </div>

            {isLoading && (
              <div className="space-y-2">
                <div className="flex items-center justify-between text-sm">
                  <span>Прогресс сканирования</span>
                  <span>{scanProgress}%</span>
                </div>
                <Progress value={scanProgress} className="w-full" />
              </div>
            )}

            <div className="flex gap-2">
              <Button 
                onClick={startNetworkScan}
                disabled={isLoading || systemStatus.isScanning}
                className="flex items-center gap-2"
              >
                <Search className="w-4 h-4" />
                {isLoading ? 'Сканирование...' : 'Запустить сканирование'}
              </Button>
              
              {systemStatus.continuousScanning ? (
                <Button 
                  variant="outline"
                  onClick={stopContinuousScanning}
                  className="flex items-center gap-2"
                >
                  <XCircle className="w-4 h-4" />
                  Остановить авто-сканирование
                </Button>
              ) : (
                <Button 
                  variant="outline"
                  onClick={startContinuousScanning}
                  className="flex items-center gap-2"
                >
                  <RefreshCw className="w-4 h-4" />
                  Включить авто-сканирование
                </Button>
              )}
              
              <Button 
                variant="outline"
                onClick={loadDevices}
                className="flex items-center gap-2"
              >
                <RefreshCw className="w-4 h-4" />
                Обновить
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Список устройств */}
      <Card>
        <CardHeader>
          <CardTitle>Обнаруженные устройства ({devices.length})</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {devices.length === 0 ? (
              <div className="text-center py-8 text-gray-500">
                <Network className="w-12 h-12 mx-auto mb-4 opacity-50" />
                <p>Устройства не обнаружены</p>
                <p className="text-sm">Запустите сканирование для поиска устройств в сети</p>
              </div>
            ) : (
              devices.map((device) => (
                <div key={device.id} className="border rounded-lg p-4 space-y-3">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-3">
                      {getDeviceIcon(device.type)}
                      <div>
                        <div className="font-semibold">{device.name}</div>
                        <div className="text-sm text-gray-500">
                          {device.ipAddress} • {device.type}
                        </div>
                      </div>
                    </div>
                    
                    <div className="flex items-center gap-2">
                      {device.isOnline ? (
                        <CheckCircle className="w-4 h-4 text-green-500" />
                      ) : (
                        <XCircle className="w-4 h-4 text-red-500" />
                      )}
                      <Badge variant={device.isOnline ? "default" : "secondary"}>
                        {device.isOnline ? "Online" : "Offline"}
                      </Badge>
                    </div>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-sm">
                    <div>
                      <Label className="text-xs text-gray-500">MAC адрес</Label>
                      <div>{device.macAddress || 'Неизвестен'}</div>
                    </div>
                    <div>
                      <Label className="text-xs text-gray-500">Подключение</Label>
                      <div className="capitalize">{device.connectionType}</div>
                    </div>
                    <div>
                      <Label className="text-xs text-gray-500">Последний раз онлайн</Label>
                      <div>{new Date(device.lastSeen).toLocaleString()}</div>
                    </div>
                  </div>

                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <Label className="text-sm">Уровень доступа:</Label>
                      <Select
                        value={device.permissionLevel}
                        onValueChange={(value) => updateDevicePermissions(device.id, value)}
                      >
                        <SelectTrigger className="w-32">
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          {permissionLevels.map((level) => (
                            <SelectItem key={level} value={level}>
                              {level}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                      <div className={`w-2 h-2 rounded-full ${getPermissionColor(device.permissionLevel)}`} />
                    </div>

                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => removeDevice(device.id)}
                      className="text-red-600 hover:text-red-700"
                    >
                      <Trash2 className="w-4 h-4" />
                    </Button>
                  </div>

                  {device.capabilities.length > 0 && (
                    <div>
                      <Label className="text-xs text-gray-500">Возможности</Label>
                      <div className="flex flex-wrap gap-1 mt-1">
                        {device.capabilities.map((capability) => (
                          <Badge key={capability} variant="outline" className="text-xs">
                            {capability}
                          </Badge>
                        ))}
                      </div>
                    </div>
                  )}
                </div>
              ))
            )}
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default JarvisDeviceDiscovery;