import { useState } from 'react';
import { useMutation, useQuery } from '@tanstack/react-query';
import { apiRequest } from '@/lib/queryClient';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';

interface PersonalityProfile {
  userId: string;
  layers: {
    core: {
      fundamentalTraits: string[];
      deepMotivations: string[];
      cognitiveStyle: string;
      emotionalPatterns: string[];
    };
    adaptive: {
      currentMood: string;
      stressResponse: string;
      energyLevel: number;
      focusState: string;
    };
    contextual: {
      workingStyle: string;
      communicationPreference: string;
      supportNeeds: string[];
      autonomyLevel: number;
    };
    relational: {
      trustLevel: number;
      intimacyComfort: number;
      feedbackStyle: string;
      relationshipDynamic: string;
    };
  };
  jarvisAdaptation: {
    communicationTone: string;
    responseDepth: string;
    proactivityLevel: number;
    challengeLevel: number;
    intimacyLevel: string;
  };
  adaptationCount: number;
  lastAdaptation?: Date;
}

interface StarkPersonalityResponse {
  adaptedMessage: string;
  personalityInsights: {
    recognizedState: string;
    adaptationsMade: string[];
    relationshipDeepening: boolean;
    trustChange: number;
  };
  proactiveElements: {
    anticipatedNeeds: string[];
    suggestedActions: string[];
    emotionalSupport: string;
  };
  memoryFormation: {
    keyInsights: string[];
    relationshipMilestones: string[];
    personalityEvolution: string;
  };
}

export default function StarkPersonalityTest() {
  const [message, setMessage] = useState('');
  const [userId] = useState('test-user-' + Math.random().toString(36).substr(2, 9));
  const [testResults, setTestResults] = useState<StarkPersonalityResponse | null>(null);

  // Query personality profile
  const { data: profile, refetch: refetchProfile } = useQuery<{ profile: PersonalityProfile }>({
    queryKey: ['stark-personality', userId],
    queryFn: () => apiRequest(`/api/jarvis/stark-personality/${userId}`),
    enabled: false
  });

  // Mutation for personality analysis
  const analyzePersonality = useMutation({
    mutationFn: (data: { userId: string; message: string; voiceAnalysis?: any }) =>
      apiRequest('POST', '/api/jarvis/stark-personality', data),
    onSuccess: (response: StarkPersonalityResponse) => {
      setTestResults(response);
      refetchProfile();
    }
  });

  // Mutation for feedback
  const submitFeedback = useMutation({
    mutationFn: (data: { feedback: 'positive' | 'neutral' | 'negative'; context?: string }) =>
      apiRequest('POST', `/api/jarvis/stark-personality/${userId}/feedback`, data),
    onSuccess: () => {
      refetchProfile();
    }
  });

  const handleAnalyze = () => {
    if (!message.trim()) return;
    
    analyzePersonality.mutate({
      userId,
      message,
      voiceAnalysis: {
        energy: Math.random() * 0.5 + 0.5,
        clarity: Math.random() * 0.3 + 0.7,
        pace: Math.random() * 0.4 + 0.5
      }
    });
  };

  const handleFeedback = (feedback: 'positive' | 'neutral' | 'negative') => {
    submitFeedback.mutate({ 
      feedback, 
      context: `Feedback on response: "${testResults?.adaptedMessage?.substring(0, 100)}..."` 
    });
  };

  return (
    <div className="container mx-auto p-6 space-y-6">
      <div className="text-center space-y-2">
        <h1 className="text-3xl font-bold">Multi-Dimensional Stark Personality Engine</h1>
        <p className="text-muted-foreground">
          Test JARVIS's ability to understand and adapt to your unique personality patterns
        </p>
        <Badge variant="outline" className="text-xs">
          User ID: {userId}
        </Badge>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Input Section */}
        <Card>
          <CardHeader>
            <CardTitle>Communicate with JARVIS</CardTitle>
            <CardDescription>
              Share your thoughts, challenges, or goals. JARVIS will analyze your personality and adapt its response.
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <Textarea
              placeholder="Tell JARVIS about your current situation, challenges, or what you're working on..."
              value={message}
              onChange={(e) => setMessage(e.target.value)}
              rows={6}
              className="resize-none"
            />
            <Button 
              onClick={handleAnalyze} 
              disabled={!message.trim() || analyzePersonality.isPending}
              className="w-full"
            >
              {analyzePersonality.isPending ? 'Analyzing Personality...' : 'Analyze & Respond'}
            </Button>
          </CardContent>
        </Card>

        {/* Results Section */}
        <Card>
          <CardHeader>
            <CardTitle>JARVIS Response</CardTitle>
            <CardDescription>
              Personality-adapted response with insights into adaptation process
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            {analyzePersonality.isPending && (
              <div className="flex items-center space-x-2">
                <div className="animate-spin w-4 h-4 border-2 border-primary border-t-transparent rounded-full" />
                <span className="text-sm text-muted-foreground">
                  Analyzing personality patterns...
                </span>
              </div>
            )}
            
            {testResults && (
              <div className="space-y-4">
                <div className="p-4 bg-muted rounded-lg">
                  <h4 className="font-medium mb-2">Adapted Response:</h4>
                  <p className="text-sm">{testResults.adaptedMessage}</p>
                </div>

                <div className="flex gap-2">
                  <Button
                    size="sm"
                    variant="outline"
                    onClick={() => handleFeedback('positive')}
                    disabled={submitFeedback.isPending}
                  >
                    👍 Helpful
                  </Button>
                  <Button
                    size="sm"
                    variant="outline"
                    onClick={() => handleFeedback('neutral')}
                    disabled={submitFeedback.isPending}
                  >
                    😐 Neutral
                  </Button>
                  <Button
                    size="sm"
                    variant="outline"
                    onClick={() => handleFeedback('negative')}
                    disabled={submitFeedback.isPending}
                  >
                    👎 Not Helpful
                  </Button>
                </div>
              </div>
            )}

            {analyzePersonality.error && (
              <div className="p-4 bg-destructive/10 border border-destructive/20 rounded-lg">
                <p className="text-sm text-destructive">
                  Analysis failed. Please try again.
                </p>
              </div>
            )}
          </CardContent>
        </Card>
      </div>

      {/* Detailed Analysis */}
      {(testResults || profile?.profile) && (
        <Tabs defaultValue="insights" className="w-full">
          <TabsList className="grid w-full grid-cols-3">
            <TabsTrigger value="insights">Personality Insights</TabsTrigger>
            <TabsTrigger value="profile">Full Profile</TabsTrigger>
            <TabsTrigger value="adaptation">JARVIS Adaptation</TabsTrigger>
          </TabsList>

          <TabsContent value="insights" className="space-y-4">
            {testResults && (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                <Card>
                  <CardHeader className="pb-3">
                    <CardTitle className="text-lg">Recognized State</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <p className="text-sm">{testResults.personalityInsights.recognizedState}</p>
                    {testResults.personalityInsights.relationshipDeepening && (
                      <Badge className="mt-2" variant="secondary">
                        Relationship Deepening
                      </Badge>
                    )}
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader className="pb-3">
                    <CardTitle className="text-lg">Adaptations Made</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <ul className="text-sm space-y-1">
                      {testResults.personalityInsights.adaptationsMade.map((adaptation, i) => (
                        <li key={i} className="flex items-center gap-2">
                          <div className="w-1.5 h-1.5 bg-primary rounded-full" />
                          {adaptation}
                        </li>
                      ))}
                    </ul>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader className="pb-3">
                    <CardTitle className="text-lg">Proactive Support</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-2">
                      <div>
                        <h5 className="font-medium text-sm">Anticipated Needs:</h5>
                        <ul className="text-xs space-y-1">
                          {testResults.proactiveElements.anticipatedNeeds.map((need, i) => (
                            <li key={i}>• {need}</li>
                          ))}
                        </ul>
                      </div>
                      <div>
                        <h5 className="font-medium text-sm">Suggested Actions:</h5>
                        <ul className="text-xs space-y-1">
                          {testResults.proactiveElements.suggestedActions.map((action, i) => (
                            <li key={i}>• {action}</li>
                          ))}
                        </ul>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </div>
            )}
          </TabsContent>

          <TabsContent value="profile">
            <Button 
              onClick={() => refetchProfile()} 
              className="mb-4"
              disabled={profile === undefined}
            >
              Load Full Profile
            </Button>
            
            {profile?.profile && (
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <Card>
                  <CardHeader>
                    <CardTitle>Core Personality</CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-3">
                    <div>
                      <h5 className="font-medium text-sm mb-1">Fundamental Traits:</h5>
                      <div className="flex flex-wrap gap-1">
                        {profile.profile.layers.core.fundamentalTraits.map((trait, i) => (
                          <Badge key={i} variant="outline" className="text-xs">
                            {trait}
                          </Badge>
                        ))}
                      </div>
                    </div>
                    <div>
                      <h5 className="font-medium text-sm mb-1">Cognitive Style:</h5>
                      <p className="text-sm text-muted-foreground">
                        {profile.profile.layers.core.cognitiveStyle}
                      </p>
                    </div>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader>
                    <CardTitle>Current State</CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-3">
                    <div className="space-y-2">
                      <div className="flex justify-between items-center">
                        <span className="text-sm">Energy Level:</span>
                        <span className="text-sm font-medium">
                          {profile.profile.layers.adaptive.energyLevel}%
                        </span>
                      </div>
                      <Progress value={profile.profile.layers.adaptive.energyLevel} />
                    </div>
                    <div>
                      <h5 className="font-medium text-sm mb-1">Current Mood:</h5>
                      <p className="text-sm text-muted-foreground">
                        {profile.profile.layers.adaptive.currentMood}
                      </p>
                    </div>
                    <div>
                      <h5 className="font-medium text-sm mb-1">Focus State:</h5>
                      <p className="text-sm text-muted-foreground">
                        {profile.profile.layers.adaptive.focusState}
                      </p>
                    </div>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader>
                    <CardTitle>Relationship Dynamics</CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-3">
                    <div className="space-y-2">
                      <div className="flex justify-between items-center">
                        <span className="text-sm">Trust Level:</span>
                        <span className="text-sm font-medium">
                          {profile.profile.layers.relational.trustLevel}%
                        </span>
                      </div>
                      <Progress value={profile.profile.layers.relational.trustLevel} />
                    </div>
                    <div>
                      <h5 className="font-medium text-sm mb-1">Relationship Dynamic:</h5>
                      <p className="text-sm text-muted-foreground">
                        {profile.profile.layers.relational.relationshipDynamic}
                      </p>
                    </div>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader>
                    <CardTitle>Contextual Preferences</CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-3">
                    <div className="space-y-2">
                      <div className="flex justify-between items-center">
                        <span className="text-sm">Autonomy Level:</span>
                        <span className="text-sm font-medium">
                          {profile.profile.layers.contextual.autonomyLevel}%
                        </span>
                      </div>
                      <Progress value={profile.profile.layers.contextual.autonomyLevel} />
                    </div>
                    <div>
                      <h5 className="font-medium text-sm mb-1">Working Style:</h5>
                      <p className="text-sm text-muted-foreground">
                        {profile.profile.layers.contextual.workingStyle}
                      </p>
                    </div>
                  </CardContent>
                </Card>
              </div>
            )}
          </TabsContent>

          <TabsContent value="adaptation">
            {profile?.profile && (
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <Card>
                  <CardHeader>
                    <CardTitle>JARVIS Adaptation Settings</CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-3">
                    <div>
                      <h5 className="font-medium text-sm mb-1">Communication Tone:</h5>
                      <Badge variant="outline">
                        {profile.profile.jarvisAdaptation.communicationTone}
                      </Badge>
                    </div>
                    <div>
                      <h5 className="font-medium text-sm mb-1">Response Depth:</h5>
                      <Badge variant="outline">
                        {profile.profile.jarvisAdaptation.responseDepth}
                      </Badge>
                    </div>
                    <div>
                      <h5 className="font-medium text-sm mb-1">Intimacy Level:</h5>
                      <Badge variant="outline">
                        {profile.profile.jarvisAdaptation.intimacyLevel}
                      </Badge>
                    </div>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader>
                    <CardTitle>Adaptation Metrics</CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-3">
                    <div className="space-y-2">
                      <div className="flex justify-between items-center">
                        <span className="text-sm">Proactivity Level:</span>
                        <span className="text-sm font-medium">
                          {profile.profile.jarvisAdaptation.proactivityLevel}%
                        </span>
                      </div>
                      <Progress value={profile.profile.jarvisAdaptation.proactivityLevel} />
                    </div>
                    <div className="space-y-2">
                      <div className="flex justify-between items-center">
                        <span className="text-sm">Challenge Level:</span>
                        <span className="text-sm font-medium">
                          {profile.profile.jarvisAdaptation.challengeLevel}%
                        </span>
                      </div>
                      <Progress value={profile.profile.jarvisAdaptation.challengeLevel} />
                    </div>
                    <div>
                      <h5 className="font-medium text-sm mb-1">Total Adaptations:</h5>
                      <p className="text-sm text-muted-foreground">
                        {profile.profile.adaptationCount}
                      </p>
                    </div>
                  </CardContent>
                </Card>
              </div>
            )}
          </TabsContent>
        </Tabs>
      )}
    </div>
  );
}