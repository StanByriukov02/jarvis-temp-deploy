import { useState, useRef, useCallback } from 'react';
import { useMutation, useQuery } from '@tanstack/react-query';
import { apiRequest } from '@/lib/queryClient';

interface VoiceAnalysis {
  volume: number;
  duration: number;
  pace: 'fast' | 'normal' | 'slow';
  emotion: 'excited' | 'calm' | 'urgent' | 'neutral';
}

interface ProcessedCommand {
  intent: string;
  action: string;
  parameters: Record<string, any>;
  requiresConfirmation: boolean;
  response: string;
  emotion: VoiceAnalysis['emotion'];
}

interface VoicePreferences {
  preferredLanguage: 'en' | 'es' | 'de' | 'ko';
  defaultFocusDuration: number;
  voiceResponseStyle: 'concise' | 'balanced' | 'detailed';
  confirmationRequired: string[];
  quickCommands: string[];
}

export function useAdvancedVoice(userId: string = 'demo-user') {
  const [isRecording, setIsRecording] = useState(false);
  const [isTranscribing, setIsTranscribing] = useState(false);
  const [currentTranscription, setCurrentTranscription] = useState('');
  const [lastCommand, setLastCommand] = useState<ProcessedCommand | null>(null);
  const [voiceAnalysis, setVoiceAnalysis] = useState<VoiceAnalysis | null>(null);
  
  const mediaRecorderRef = useRef<MediaRecorder | null>(null);
  const audioChunksRef = useRef<Blob[]>([]);
  const recordingStartTimeRef = useRef<number>(0);

  // Fetch voice preferences
  const { data: preferences } = useQuery({
    queryKey: ['/api/voice/preferences', userId],
    queryFn: () => fetch(`/api/voice/preferences/${userId}`).then(res => res.json()),
  });

  // Fetch supported languages
  const { data: languageSupport } = useQuery({
    queryKey: ['/api/voice/supported-languages'],
    queryFn: () => fetch('/api/voice/supported-languages').then(res => res.json()),
  });

  // Whisper transcription mutation
  const whisperTranscription = useMutation({
    mutationFn: async ({ audioBlob, language, duration }: { 
      audioBlob: Blob; 
      language: string; 
      duration: number;
    }) => {
      const formData = new FormData();
      formData.append('audio', audioBlob, 'voice-command.wav');
      formData.append('language', language);
      formData.append('duration', duration.toString());
      formData.append('userId', userId);

      const response = await fetch('/api/voice/whisper-transcribe-advanced', {
        method: 'POST',
        body: formData,
      });

      if (!response.ok) {
        throw new Error('Transcription failed');
      }

      return response.json();
    },
    onSuccess: (data) => {
      setCurrentTranscription(data.transcription);
      setVoiceAnalysis(data.voiceAnalysis);
      setIsTranscribing(false);
    },
    onError: (error) => {
      console.error('Whisper transcription failed:', error);
      setIsTranscribing(false);
    }
  });

  // Command processing mutation
  const processCommand = useMutation({
    mutationFn: async ({ transcription, voiceAnalysis, language }: {
      transcription: string;
      voiceAnalysis: VoiceAnalysis;
      language: string;
    }) => {
      const response = await fetch('/api/voice/process-advanced-command', {
        method: 'POST',
        body: JSON.stringify({
          transcription,
          voiceAnalysis,
          userId,
          language
        }),
        headers: {
          'Content-Type': 'application/json'
        }
      });
      return response.json();
    },
    onSuccess: (data) => {
      setLastCommand(data.command);
    }
  });

  // Start recording with microphone
  const startRecording = useCallback(async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ 
        audio: {
          sampleRate: 16000,
          channelCount: 1,
          echoCancellation: true,
          noiseSuppression: true
        }
      });

      const mediaRecorder = new MediaRecorder(stream, {
        mimeType: 'audio/webm;codecs=opus'
      });

      audioChunksRef.current = [];
      recordingStartTimeRef.current = Date.now();

      mediaRecorder.ondataavailable = (event) => {
        if (event.data.size > 0) {
          audioChunksRef.current.push(event.data);
        }
      };

      mediaRecorder.onstop = async () => {
        const audioBlob = new Blob(audioChunksRef.current, { type: 'audio/webm' });
        const duration = (Date.now() - recordingStartTimeRef.current) / 1000;
        
        setIsTranscribing(true);
        
        // Convert to WAV for better Whisper compatibility
        const wavBlob = await convertToWav(audioBlob);
        
        whisperTranscription.mutate({
          audioBlob: wavBlob,
          language: (preferences as any)?.preferredLanguage || 'en',
          duration
        });

        // Clean up stream
        stream.getTracks().forEach(track => track.stop());
      };

      mediaRecorderRef.current = mediaRecorder;
      mediaRecorder.start();
      setIsRecording(true);
    } catch (error) {
      console.error('Failed to start recording:', error);
      throw error;
    }
  }, [(preferences as any)?.preferredLanguage, whisperTranscription]);

  // Stop recording
  const stopRecording = useCallback(() => {
    if (mediaRecorderRef.current && isRecording) {
      mediaRecorderRef.current.stop();
      setIsRecording(false);
    }
  }, [isRecording]);

  // Process transcribed command
  const executeCommand = useCallback((transcription?: string) => {
    const textToProcess = transcription || currentTranscription;
    
    if (!textToProcess || !voiceAnalysis) {
      return;
    }

    processCommand.mutate({
      transcription: textToProcess,
      voiceAnalysis,
      language: (preferences as any)?.preferredLanguage || 'en'
    });
  }, [currentTranscription, voiceAnalysis, (preferences as any)?.preferredLanguage, processCommand]);

  // Quick voice command for common actions
  const executeQuickCommand = useCallback(async (command: string) => {
    const mockVoiceAnalysis: VoiceAnalysis = {
      volume: 0.5,
      duration: 2,
      pace: 'normal',
      emotion: 'neutral'
    };

    processCommand.mutate({
      transcription: command,
      voiceAnalysis: mockVoiceAnalysis,
      language: (preferences as any)?.preferredLanguage || 'en'
    });
  }, [(preferences as any)?.preferredLanguage, processCommand]);

  // Convert audio blob to WAV format for better Whisper compatibility
  const convertToWav = async (audioBlob: Blob): Promise<Blob> => {
    // For production, implement proper audio conversion
    // For now, return the original blob
    return audioBlob;
  };

  return {
    // State
    isRecording,
    isTranscribing,
    currentTranscription,
    lastCommand,
    voiceAnalysis,
    preferences: preferences as any,
    languageSupport,
    
    // Actions
    startRecording,
    stopRecording,
    executeCommand,
    executeQuickCommand,
    
    // Mutation states
    isProcessingCommand: processCommand.isPending,
    transcriptionError: whisperTranscription.error,
    commandError: processCommand.error,
    
    // Utils
    clearTranscription: () => setCurrentTranscription(''),
    clearLastCommand: () => setLastCommand(null)
  };
}

// Voice command patterns for DeepFocus activation
export const DEEP_FOCUS_COMMANDS = [
  'jarvis open deep focus',
  'open deep focus',
  'deep focus mode',
  'activate focus',
  'start deep focus',
  'focus mode on',
  'enter deep focus'
];

// Quick action commands
export const QUICK_COMMANDS = {
  NAVIGATION: [
    'show dashboard',
    'open systems', 
    'go to profile',
    'main feed'
  ],
  CALENDAR: [
    'today tasks',
    'what\'s on my calendar',
    'upcoming meetings',
    'schedule today'
  ],
  METRICS: [
    'revenue today',
    'show stats',
    'performance metrics',
    'progress report'
  ],
  SYSTEM_CONTROL: [
    'start system',
    'pause system',
    'system status',
    'show progress'
  ]
};