import { useEffect, useState } from 'react';

export function useVoiceCommands() {
  const [isListening, setIsListening] = useState(false);
  const [lastCommand, setLastCommand] = useState<string | null>(null);

  useEffect(() => {
    // Mock voice recognition
    if (isListening) {
      const timer = setTimeout(() => {
        const mockCommands = ['play', 'pause', 'next', 'back', 'settings'];
        const randomCommand = mockCommands[Math.floor(Math.random() * mockCommands.length)];
        setLastCommand(randomCommand);
        setIsListening(false);
      }, 2000);

      return () => clearTimeout(timer);
    }
  }, [isListening]);

  const startListening = () => {
    setIsListening(true);
    setLastCommand(null);
  };

  const stopListening = () => {
    setIsListening(false);
  };

  return {
    isListening,
    lastCommand,
    startListening,
    stopListening,
  };
}