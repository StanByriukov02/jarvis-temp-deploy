import { useState, useEffect, useCallback, useRef } from 'react';

interface JarvisData {
  deepFocus: {
    status: string;
    focus_level: number;
    session_time: number;
  };
  liveActivity: {
    active_users: number;
    systems_running: number;
    completion_rate: number;
  };
  businessMetrics: {
    revenue: number;
    active_subscriptions: number;
    conversion_rate: number;
  };
}

interface UseJarvisWebSocketReturn {
  data: JarvisData | null;
  isConnected: boolean;
  error: string | null;
  reconnect: () => void;
}

export function useJarvisWebSocket(): UseJarvisWebSocketReturn {
  const [data, setData] = useState<JarvisData | null>(null);
  const [isConnected, setIsConnected] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const wsRef = useRef<WebSocket | null>(null);
  const reconnectTimeoutRef = useRef<NodeJS.Timeout | null>(null);
  const reconnectAttempts = useRef(0);

  const connect = useCallback(() => {
    try {
      const protocol = window.location.protocol === "https:" ? "wss:" : "ws:";
      const wsUrl = `${protocol}//${window.location.host}/jarvis-ws`;
      
      console.log('🧠 Connecting to JARVIS WebSocket:', wsUrl);
      
      wsRef.current = new WebSocket(wsUrl);

      wsRef.current.onopen = () => {
        console.log('🧠 JARVIS WebSocket connected');
        setIsConnected(true);
        setError(null);
        reconnectAttempts.current = 0;
      };

      wsRef.current.onmessage = (event) => {
        try {
          const message = JSON.parse(event.data);
          if (message.type === 'jarvis-update' && message.data) {
            setData(message.data);
          }
        } catch (err) {
          console.error('Error parsing JARVIS WebSocket message:', err);
        }
      };

      wsRef.current.onclose = () => {
        console.log('🧠 JARVIS WebSocket disconnected');
        setIsConnected(false);
        
        // Auto-reconnect with exponential backoff
        if (reconnectAttempts.current < 5) {
          const delay = Math.min(1000 * Math.pow(2, reconnectAttempts.current), 30000);
          reconnectTimeoutRef.current = setTimeout(() => {
            reconnectAttempts.current++;
            connect();
          }, delay);
        } else {
          setError('Connection lost. Please refresh the page.');
        }
      };

      wsRef.current.onerror = (err) => {
        console.error('JARVIS WebSocket error:', err);
        setError('WebSocket connection error');
      };
    } catch (err) {
      console.error('Failed to create JARVIS WebSocket:', err);
      setError('Failed to connect to JARVIS');
    }
  }, []);

  const reconnect = useCallback(() => {
    if (wsRef.current) {
      wsRef.current.close();
    }
    if (reconnectTimeoutRef.current) {
      clearTimeout(reconnectTimeoutRef.current);
    }
    reconnectAttempts.current = 0;
    connect();
  }, [connect]);

  useEffect(() => {
    connect();

    return () => {
      if (wsRef.current) {
        wsRef.current.close();
      }
      if (reconnectTimeoutRef.current) {
        clearTimeout(reconnectTimeoutRef.current);
      }
    };
  }, [connect]);

  return {
    data,
    isConnected,
    error,
    reconnect
  };
}