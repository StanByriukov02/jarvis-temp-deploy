# Connect to H100 server and deploy JARVIS
# Updated script for IP: 185.216.20.194

$keyPath = "C:\Users\dammi\Downloads\Jarvis-biosingularity-live_Hyperstack.txt"
$server = "185.216.20.194"
$token = "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"

Write-Host "=== JARVIS H100 DEPLOYMENT SCRIPT ===" -ForegroundColor Green

# Check if key file exists
if (Test-Path $keyPath) {
    Write-Host "✓ SSH key found at: $keyPath" -ForegroundColor Green
    
    # Set correct permissions on the key file
    Write-Host "Setting correct permissions on SSH key..."
    & icacls $keyPath /reset
    & icacls $keyPath /grant:r "$env:USERNAME:(R)"
    & icacls $keyPath /inheritance:r
    
    # Connect to server and deploy
    Write-Host "Connecting to H100 server and deploying JARVIS..." -ForegroundColor Yellow
    
    & ssh -i $keyPath -o StrictHostKeyChecking=no ubuntu@$server @"
        echo '🚀 Connected to H100 server successfully!'
        echo '📥 Downloading JARVIS production archive...'
        curl -H "Authorization: token $token" -L https://github.com/StanByriukov02/jarvis-deployment/raw/main/jarvis-production-ready.tar.gz -o jarvis.tar.gz
        
        echo '📦 Extracting archive...'
        tar -xzf jarvis.tar.gz
        
        echo '🔧 Setting up deployment...'
        cd jarvis-production-ready
        chmod +x deploy.sh
        
        echo '🎯 Starting JARVIS deployment...'
        ./deploy.sh
"@
    
} else {
    Write-Host "❌ ERROR: SSH key file not found at $keyPath" -ForegroundColor Red
    Write-Host "Please check if the key file exists and the path is correct"
}

Write-Host "=== DEPLOYMENT COMPLETE ===" -ForegroundColor Green