/**
 * WebRTC Audio Streaming for Real-time JARVIS Voice Processing
 * Handles continuous audio streaming, feature extraction, and voice activity detection
 */

interface AudioFeatures {
  pitch: number;
  energy: number;
  tempo: number;
  timestamp: number;
}

interface VoiceActivityResult {
  isSpeaking: boolean;
  confidence: number;
  features: AudioFeatures;
}

export class WebRTCAudioStream {
  private peerConnection: RTCPeerConnection | null = null;
  private localStream: MediaStream | null = null;
  private audioContext: AudioContext | null = null;
  private analyzer: AnalyserNode | null = null;
  private dataArray: Uint8Array | null = null;
  private isStreaming: boolean = false;
  private voiceActivityCallback: ((result: VoiceActivityResult) => void) | null = null;
  private emotionalStateCallback: ((state: any) => void) | null = null;
  private webSocket: WebSocket | null = null;

  constructor() {
    this.setupWebRTCConfiguration();
  }

  /**
   * Initialize WebRTC peer connection
   */
  private setupWebRTCConfiguration(): void {
    const configuration: RTCConfiguration = {
      iceServers: [
        { urls: 'stun:stun.l.google.com:19302' },
        { urls: 'stun:stun1.l.google.com:19302' }
      ]
    };

    this.peerConnection = new RTCPeerConnection(configuration);
    
    this.peerConnection.onicecandidate = (event) => {
      if (event.candidate && this.webSocket) {
        this.webSocket.send(JSON.stringify({
          type: 'ice-candidate',
          candidate: event.candidate
        }));
      }
    };

    this.peerConnection.ontrack = (event) => {
      console.log('Received remote audio stream');
    };
  }

  /**
   * Start audio streaming with real-time analysis
   */
  async startStreaming(): Promise<void> {
    try {
      // Get user media with high-quality audio
      this.localStream = await navigator.mediaDevices.getUserMedia({
        audio: {
          echoCancellation: true,
          noiseSuppression: true,
          autoGainControl: true,
          sampleRate: 48000
        }
      });

      // Setup audio context for feature extraction
      this.setupAudioAnalysis();
      
      // Setup WebSocket for signaling
      this.setupWebSocketSignaling();

      // Add audio track to peer connection
      this.localStream.getAudioTracks().forEach(track => {
        this.peerConnection?.addTrack(track, this.localStream!);
      });

      // Start real-time audio analysis
      this.startRealtimeAnalysis();
      
      this.isStreaming = true;
      console.log('🎙️ WebRTC audio streaming started');

    } catch (error) {
      console.error('Failed to start audio streaming:', error);
      throw error;
    }
  }

  /**
   * Setup audio analysis context
   */
  private setupAudioAnalysis(): void {
    if (!this.localStream) return;

    this.audioContext = new AudioContext({ sampleRate: 48000 });
    const source = this.audioContext.createMediaStreamSource(this.localStream);
    
    this.analyzer = this.audioContext.createAnalyser();
    this.analyzer.fftSize = 2048;
    this.analyzer.smoothingTimeConstant = 0.3;
    
    source.connect(this.analyzer);
    
    this.dataArray = new Uint8Array(this.analyzer.frequencyBinCount);
  }

  /**
   * Setup WebSocket for signaling
   */
  private setupWebSocketSignaling(): void {
    const protocol = window.location.protocol === 'https:' ? 'wss:' : 'ws:';
    const wsUrl = `${protocol}//${window.location.host}/voice-stream`;
    
    this.webSocket = new WebSocket(wsUrl);
    
    this.webSocket.onopen = () => {
      console.log('Voice streaming WebSocket connected');
    };

    this.webSocket.onmessage = async (event) => {
      const message = JSON.parse(event.data);
      await this.handleSignalingMessage(message);
    };

    this.webSocket.onerror = (error) => {
      console.error('WebSocket error:', error);
    };
  }

  /**
   * Handle WebRTC signaling messages
   */
  private async handleSignalingMessage(message: any): Promise<void> {
    if (!this.peerConnection) return;

    switch (message.type) {
      case 'offer':
        await this.peerConnection.setRemoteDescription(message.offer);
        const answer = await this.peerConnection.createAnswer();
        await this.peerConnection.setLocalDescription(answer);
        
        this.webSocket?.send(JSON.stringify({
          type: 'answer',
          answer: answer
        }));
        break;

      case 'answer':
        await this.peerConnection.setRemoteDescription(message.answer);
        break;

      case 'ice-candidate':
        await this.peerConnection.addIceCandidate(message.candidate);
        break;

      case 'emotional-analysis':
        this.emotionalStateCallback?.(message.data);
        break;
    }
  }

  /**
   * Start real-time audio analysis loop
   */
  private startRealtimeAnalysis(): void {
    const analyzeAudio = () => {
      if (!this.isStreaming || !this.analyzer || !this.dataArray) return;

      // Get frequency and time domain data
      this.analyzer.getByteFrequencyData(this.dataArray);
      
      // Extract audio features
      const features = this.extractAudioFeatures();
      
      // Perform voice activity detection
      const voiceActivity = this.detectVoiceActivity(features);
      
      // Send to callbacks
      this.voiceActivityCallback?.(voiceActivity);
      
      // Send features to backend for emotional analysis
      if (this.webSocket && voiceActivity.isSpeaking) {
        this.webSocket.send(JSON.stringify({
          type: 'audio-features',
          features: features,
          timestamp: Date.now()
        }));
      }

      // Continue analysis loop (100ms intervals)
      setTimeout(analyzeAudio, 100);
    };

    analyzeAudio();
  }

  /**
   * Extract audio features (pitch, energy, tempo)
   */
  private extractAudioFeatures(): AudioFeatures {
    if (!this.analyzer || !this.dataArray) {
      return { pitch: 0, energy: 0, tempo: 0, timestamp: Date.now() };
    }

    this.analyzer.getByteFrequencyData(this.dataArray);

    // Calculate energy (RMS)
    let energy = 0;
    for (let i = 0; i < this.dataArray.length; i++) {
      energy += this.dataArray[i] * this.dataArray[i];
    }
    energy = Math.sqrt(energy / this.dataArray.length);

    // Estimate pitch (fundamental frequency)
    const pitch = this.estimatePitch();

    // Simple tempo detection based on energy changes
    const tempo = this.estimateTempo(energy);

    return {
      pitch: pitch,
      energy: energy,
      tempo: tempo,
      timestamp: Date.now()
    };
  }

  /**
   * Estimate pitch using autocorrelation
   */
  private estimatePitch(): number {
    if (!this.analyzer) return 0;

    const bufferLength = this.analyzer.fftSize;
    const timeData = new Float32Array(bufferLength);
    this.analyzer.getFloatTimeDomainData(timeData);

    // Simple autocorrelation for pitch detection
    let maxCorrelation = 0;
    let bestPeriod = 0;

    for (let period = 8; period < bufferLength / 2; period++) {
      let correlation = 0;
      for (let i = 0; i < bufferLength - period; i++) {
        correlation += timeData[i] * timeData[i + period];
      }
      
      if (correlation > maxCorrelation) {
        maxCorrelation = correlation;
        bestPeriod = period;
      }
    }

    return bestPeriod > 0 ? this.audioContext!.sampleRate / bestPeriod : 0;
  }

  /**
   * Estimate tempo based on energy changes
   */
  private estimateTempo(currentEnergy: number): number {
    // Simple tempo estimation - would need more sophisticated algorithm for accuracy
    // This is a placeholder implementation
    return currentEnergy > 50 ? 120 : 80; // BPM estimate
  }

  /**
   * Voice Activity Detection
   */
  private detectVoiceActivity(features: AudioFeatures): VoiceActivityResult {
    // Simple VAD based on energy threshold and frequency analysis
    const energyThreshold = 30;
    const pitchThreshold = 80; // Hz
    
    const isSpeaking = features.energy > energyThreshold && 
                     features.pitch > pitchThreshold && 
                     features.pitch < 800;

    const confidence = Math.min(features.energy / 100, 1.0);

    return {
      isSpeaking,
      confidence,
      features
    };
  }

  /**
   * Set callback for voice activity detection
   */
  onVoiceActivity(callback: (result: VoiceActivityResult) => void): void {
    this.voiceActivityCallback = callback;
  }

  /**
   * Set callback for emotional state updates
   */
  onEmotionalState(callback: (state: any) => void): void {
    this.emotionalStateCallback = callback;
  }

  /**
   * Stop streaming
   */
  stopStreaming(): void {
    this.isStreaming = false;
    
    if (this.localStream) {
      this.localStream.getTracks().forEach(track => track.stop());
    }
    
    if (this.peerConnection) {
      this.peerConnection.close();
    }
    
    if (this.webSocket) {
      this.webSocket.close();
    }
    
    if (this.audioContext) {
      this.audioContext.close();
    }
    
    console.log('🎙️ WebRTC audio streaming stopped');
  }

  /**
   * Create offer for WebRTC connection
   */
  async createOffer(): Promise<void> {
    if (!this.peerConnection) return;

    const offer = await this.peerConnection.createOffer();
    await this.peerConnection.setLocalDescription(offer);
    
    this.webSocket?.send(JSON.stringify({
      type: 'offer',
      offer: offer
    }));
  }

  /**
   * Get current streaming status
   */
  isActive(): boolean {
    return this.isStreaming;
  }
}