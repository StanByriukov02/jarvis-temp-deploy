#!/bin/bash

echo "🔍 JARVIS Kernel Compilation Readiness Check"
echo "============================================="

# Check if we're on Linux
if [[ "$OSTYPE" != "linux-gnu"* ]]; then
    echo "❌ ERROR: This requires Linux system"
    echo "   Current OS: $OSTYPE"
    exit 1
fi

# Check kernel headers
echo "📋 Checking kernel headers..."
if [ -d "/lib/modules/$(uname -r)/build" ]; then
    echo "✅ Kernel headers found: /lib/modules/$(uname -r)/build"
else
    echo "❌ Kernel headers missing"
    echo "   Install with: sudo apt install linux-headers-$(uname -r)"
    exit 1
fi

# Check build tools
echo "📋 Checking build tools..."
if command -v gcc &> /dev/null; then
    echo "✅ GCC found: $(gcc --version | head -1)"
else
    echo "❌ GCC missing"
    echo "   Install with: sudo apt install build-essential"
    exit 1
fi

if command -v make &> /dev/null; then
    echo "✅ Make found: $(make --version | head -1)"
else
    echo "❌ Make missing"
    echo "   Install with: sudo apt install build-essential"
    exit 1
fi

# Check if we have sudo access
echo "📋 Checking sudo access..."
if sudo -n true 2>/dev/null; then
    echo "✅ Sudo access available"
else
    echo "⚠️  Sudo access required for module loading"
    echo "   Run: sudo -v"
fi

# Check current directory
echo "📋 Checking source files..."
if [ -f "jarvis-kernel-module.c" ]; then
    echo "✅ Source file found: jarvis-kernel-module.c"
else
    echo "❌ Source file missing: jarvis-kernel-module.c"
    exit 1
fi

if [ -f "Makefile" ]; then
    echo "✅ Makefile found"
else
    echo "❌ Makefile missing"
    exit 1
fi

echo ""
echo "🚀 READY FOR COMPILATION!"
echo "Next steps:"
echo "1. Run: make clean"
echo "2. Run: make all"
echo "3. Run: sudo insmod jarvis_kernel.ko"
echo "4. Check: lsmod | grep jarvis_kernel"
echo "5. Test: echo 'test' > /proc/jarvis_bio_singularity"