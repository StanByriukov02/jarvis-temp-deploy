import { pgTable, varchar, text, timestamp, integer, boolean, jsonb, uuid } from 'drizzle-orm/pg-core';
import { createInsertSchema } from 'drizzle-zod';
import { z } from 'zod';

/**
 * JARVIS Kernel Security States Table
 * Stores security state transitions and authentication events
 */
export const jarvisSecurityStates = pgTable('jarvis_security_states', {
  id: uuid('id').primaryKey().defaultRandom(),
  userId: varchar('user_id', { length: 255 }).notNull(),
  currentState: integer('current_state').notNull(), // 0=SLEEPING, 1=AWAKENED, 2=AUTHORIZED, 3=EMPOWERED
  previousState: integer('previous_state'),
  
  // Multi-factor authentication status
  faceIdVerified: boolean('face_id_verified').default(false),
  voiceVerified: boolean('voice_verified').default(false),
  contextPhraseVerified: boolean('context_phrase_verified').default(false),
  nfcRingVerified: boolean('nfc_ring_verified').default(false),
  
  // Token management
  sessionToken: varchar('session_token', { length: 64 }),
  deviceToken: varchar('device_token', { length: 64 }),
  tokenExpiryTime: timestamp('token_expiry_time'),
  failedAuthAttempts: integer('failed_auth_attempts').default(0),
  
  // Security metadata
  ipAddress: varchar('ip_address', { length: 45 }),
  userAgent: text('user_agent'),
  geolocation: jsonb('geolocation'),
  
  createdAt: timestamp('created_at').defaultNow(),
  updatedAt: timestamp('updated_at').defaultNow()
});

/**
 * JARVIS WebRTC Connections Table  
 * Tracks iPhone P2P connections and multi-device coordination
 */
export const jarvisWebrtcConnections = pgTable('jarvis_webrtc_connections', {
  id: uuid('id').primaryKey().defaultRandom(),
  userId: varchar('user_id', { length: 255 }).notNull(),
  deviceId: varchar('device_id', { length: 255 }).notNull(),
  deviceType: varchar('device_type', { length: 50 }).notNull(), // 'iPhone', 'iPad', 'Mac', etc.
  
  // Connection details
  channelId: varchar('channel_id', { length: 255 }).notNull(),
  connectionState: integer('connection_state').default(0), // 0=disconnected, 1=connected
  encryptionKey: varchar('encryption_key', { length: 64 }),
  
  // iPhone specific
  iPhoneSessionToken: varchar('iphone_session_token', { length: 64 }),
  lastHeartbeat: timestamp('last_heartbeat'),
  
  // Performance metrics
  latency: integer('latency'), // in milliseconds
  dataTransferred: integer('data_transferred'), // in bytes
  
  // Connection metadata
  ipAddress: varchar('ip_address', { length: 45 }),
  connectionQuality: varchar('connection_quality', { length: 20 }), // 'excellent', 'good', 'poor'
  
  createdAt: timestamp('created_at').defaultNow(),
  updatedAt: timestamp('updated_at').defaultNow()
});

/**
 * JARVIS Kernel Events Table
 * Logs all kernel-level events for bio-singularity learning
 */
export const jarvisKernelEvents = pgTable('jarvis_kernel_events', {
  id: uuid('id').primaryKey().defaultRandom(),
  userId: varchar('user_id', { length: 255 }).notNull(),
  eventType: varchar('event_type', { length: 100 }).notNull(), // 'voice_activation', 'security_event', 'system_monitor', etc.
  eventCategory: varchar('event_category', { length: 50 }).notNull(), // 'security', 'behavioral', 'performance'
  
  // Event data
  eventData: jsonb('event_data').notNull(),
  severity: varchar('severity', { length: 20 }).default('info'), // 'info', 'warning', 'error', 'critical'
  
  // Kernel context
  kernelModule: varchar('kernel_module', { length: 100 }), // which kernel module generated the event
  systemLoad: integer('system_load'), // CPU load at time of event
  memoryUsage: integer('memory_usage'), // Memory usage percentage
  
  // Bio-singularity integration
  processed: boolean('processed').default(false), // Has bio-singularity processed this event?
  learningValue: integer('learning_value'), // How valuable is this event for learning (1-100)?
  
  createdAt: timestamp('created_at').defaultNow()
});

/**
 * JARVIS NFC Ring Sessions Table
 * Tracks NFC ring authentication and proximity
 */
export const jarvisNfcRingSessions = pgTable('jarvis_nfc_ring_sessions', {
  id: uuid('id').primaryKey().defaultRandom(),
  userId: varchar('user_id', { length: 255 }).notNull(),
  ringUid: varchar('ring_uid', { length: 32 }).notNull(),
  
  // Ring authentication
  cryptoSignature: varchar('crypto_signature', { length: 128 }),
  proximityDistance: integer('proximity_distance'), // in centimeters
  
  // Session details
  sessionStart: timestamp('session_start').defaultNow(),
  sessionEnd: timestamp('session_end'),
  authenticated: boolean('authenticated').default(false),
  
  // Security context
  securityLevel: integer('security_level'), // Which security level was granted
  usedAsBackup: boolean('used_as_backup').default(false), // Was this used when iPhone failed?
  
  createdAt: timestamp('created_at').defaultNow()
});

/**
 * JARVIS Recovery Events Table
 * Tracks system recovery attempts and watchdog events
 */
export const jarvisRecoveryEvents = pgTable('jarvis_recovery_events', {
  id: uuid('id').primaryKey().defaultRandom(),
  userId: varchar('user_id', { length: 255 }),
  recoveryType: varchar('recovery_type', { length: 100 }).notNull(), // 'watchdog_timeout', 'kernel_panic', 'manual_recovery'
  
  // Recovery context
  triggerReason: text('trigger_reason'),
  systemState: jsonb('system_state'), // System state at time of recovery
  recoveryAttempts: integer('recovery_attempts').default(1),
  
  // Recovery outcome
  recoverySuccessful: boolean('recovery_successful').default(false),
  recoveryDuration: integer('recovery_duration'), // in milliseconds
  
  // Post-recovery state
  systemHealth: integer('system_health'), // 1-100 health score after recovery
  servicesRestored: jsonb('services_restored'), // Which services were restored
  
  createdAt: timestamp('created_at').defaultNow(),
  resolvedAt: timestamp('resolved_at')
});

/**
 * JARVIS Bio-Bridge Communications Table
 * Tracks communication between kernel and bio-singularity
 */
export const jarvisBioBridgeCommunications = pgTable('jarvis_bio_bridge_communications', {
  id: uuid('id').primaryKey().defaultRandom(),
  userId: varchar('user_id', { length: 255 }).notNull(),
  communicationType: varchar('communication_type', { length: 50 }).notNull(), // 'command', 'response', 'data_stream', 'event'
  
  // Communication details
  direction: varchar('direction', { length: 10 }).notNull(), // 'kernel_to_bio', 'bio_to_kernel'
  dataSize: integer('data_size'), // in bytes
  processingTime: integer('processing_time'), // in microseconds
  
  // Command/Response tracking
  commandId: varchar('command_id', { length: 64 }),
  responseId: varchar('response_id', { length: 64 }),
  
  // Performance metrics
  queueWaitTime: integer('queue_wait_time'), // time waiting in queue
  executionTime: integer('execution_time'), // actual execution time
  
  // Bio-singularity context
  consciousnessLevel: integer('consciousness_level'), // Bio-singularity consciousness level at time
  emotionalState: varchar('emotional_state', { length: 50 }),
  
  createdAt: timestamp('created_at').defaultNow()
});

// Schema exports for validation
export const insertJarvisSecurityStateSchema = createInsertSchema(jarvisSecurityStates);
export const insertJarvisWebrtcConnectionSchema = createInsertSchema(jarvisWebrtcConnections);
export const insertJarvisKernelEventSchema = createInsertSchema(jarvisKernelEvents);
export const insertJarvisNfcRingSessionSchema = createInsertSchema(jarvisNfcRingSessions);
export const insertJarvisRecoveryEventSchema = createInsertSchema(jarvisRecoveryEvents);
export const insertJarvisBioBridgeCommunicationSchema = createInsertSchema(jarvisBioBridgeCommunications);

// Type exports
export type JarvisSecurityState = typeof jarvisSecurityStates.$inferSelect;
export type InsertJarvisSecurityState = z.infer<typeof insertJarvisSecurityStateSchema>;

export type JarvisWebrtcConnection = typeof jarvisWebrtcConnections.$inferSelect;
export type InsertJarvisWebrtcConnection = z.infer<typeof insertJarvisWebrtcConnectionSchema>;

export type JarvisKernelEvent = typeof jarvisKernelEvents.$inferSelect;
export type InsertJarvisKernelEvent = z.infer<typeof insertJarvisKernelEventSchema>;

export type JarvisNfcRingSession = typeof jarvisNfcRingSessions.$inferSelect;
export type InsertJarvisNfcRingSession = z.infer<typeof insertJarvisNfcRingSessionSchema>;

export type JarvisRecoveryEvent = typeof jarvisRecoveryEvents.$inferSelect;
export type InsertJarvisRecoveryEvent = z.infer<typeof insertJarvisRecoveryEventSchema>;

export type JarvisBioBridgeCommunication = typeof jarvisBioBridgeCommunications.$inferSelect;
export type InsertJarvisBioBridgeCommunication = z.infer<typeof insertJarvisBioBridgeCommunicationSchema>;