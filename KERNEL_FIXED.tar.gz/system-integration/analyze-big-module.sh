#!/bin/bash

# Анализатор большого JARVIS модуля - поэтапно добавляем компоненты

echo "=== АНАЛИЗ БОЛЬШОГО JARVIS МОДУЛЯ ==="

BIG_MODULE="jarvis-kernel-module.c"
if [ ! -f "$BIG_MODULE" ]; then
    echo "ОШИБКА: Файл $BIG_MODULE не найден!"
    exit 1
fi

echo "Размер оригинального модуля: $(wc -l < $BIG_MODULE) строк"
echo

# Создаем базу как в простом тесте
cat > test_module.c << 'EOF'
#include <linux/init.h>
#include <linux/module.h>
#include <linux/kernel.h>

MODULE_LICENSE("GPL");
MODULE_AUTHOR("JARVIS Bio-singularity System");
MODULE_DESCRIPTION("JARVIS Base Module Test");
MODULE_VERSION("1.0");

static int __init jarvis_init(void)
{
    printk(KERN_INFO "JARVIS: Module loaded successfully\n");
    return 0;
}

static void __exit jarvis_exit(void)
{
    printk(KERN_INFO "JARVIS: Module unloaded\n");
}

module_init(jarvis_init);
module_exit(jarvis_exit);
EOF

# Makefile
cat > Makefile << 'EOF'
obj-m := test_module.o

all:
	make -C /lib/modules/$(shell uname -r)/build M=$(PWD) modules V=0

clean:
	make -C /lib/modules/$(shell uname -r)/build M=$(PWD) clean

.PHONY: all clean
EOF

# Функция тестирования
test_compilation() {
    local step_name="$1"
    echo "ТЕСТ: $step_name"
    echo "=========================="
    
    make clean >/dev/null 2>&1
    if make all 2>/dev/null; then
        if [ -f test_module.ko ]; then
            echo "✅ SUCCESS: $step_name - модуль создан ($(ls -lh test_module.ko | awk '{print $5}'))"
            return 0
        else
            echo "❌ FAILED: $step_name - make успешен, но .ko файл не создан"
            return 1
        fi
    else
        echo "❌ FAILED: $step_name - ошибка компиляции:"
        make all
        return 1
    fi
}

# ЭТАП 1: Базовый тест
test_compilation "БАЗОВЫЙ МОДУЛЬ"
if [ $? -ne 0 ]; then
    echo "КРИТИЧЕСКАЯ ОШИБКА: Базовый модуль не работает!"
    exit 1
fi

echo
echo "ЭТАП 2: Добавление headers из большого модуля..."

# Извлекаем все includes из большого модуля
INCLUDES=$(grep "^#include" $BIG_MODULE | head -10)

# Добавляем по одному include
echo "$INCLUDES" | while read include_line; do
    if [ ! -z "$include_line" ]; then
        echo
        echo "Добавляю: $include_line"
        
        # Добавляем include после первых трех строк
        sed -i "3a\\$include_line" test_module.c
        
        test_compilation "HEADER: $include_line"
        if [ $? -ne 0 ]; then
            echo "ПРОБЛЕМНЫЙ HEADER: $include_line"
            # Удаляем проблемный header
            sed -i "/$(echo "$include_line" | sed 's/[[\.*^$()+?{|]/\\&/g')/d" test_module.c
        fi
    fi
done

echo
echo "ЭТАП 3: Добавление типов и структур..."

# Извлекаем typedef'ы
TYPEDEFS=$(grep "^typedef" $BIG_MODULE | head -5)
if [ ! -z "$TYPEDEFS" ]; then
    echo "Найдено typedef'ов: $(echo "$TYPEDEFS" | wc -l)"
    
    # Добавляем typedef'ы перед module_init
    echo "$TYPEDEFS" | while read typedef_line; do
        if [ ! -z "$typedef_line" ]; then
            echo "Добавляю typedef: $(echo "$typedef_line" | cut -c1-50)..."
            sed -i "/^static int __init/i\\$typedef_line" test_module.c
            
            test_compilation "TYPEDEF"
            if [ $? -ne 0 ]; then
                echo "ПРОБЛЕМНЫЙ TYPEDEF: $typedef_line"
                # Удаляем проблемный typedef
                sed -i "/$(echo "$typedef_line" | sed 's/[[\.*^$()+?{|]/\\&/g')/d" test_module.c
            fi
        fi
    done
fi

echo
echo "ЭТАП 4: Финальная проверка..."
test_compilation "ФИНАЛЬНЫЙ МОДУЛЬ"

echo
echo "=== РЕЗУЛЬТАТ АНАЛИЗА ==="
echo "Финальный размер модуля: $(wc -l < test_module.c) строк"
echo "Оригинальный размер: $(wc -l < $BIG_MODULE) строк"
echo

if [ -f test_module.ko ]; then
    echo "УСПЕХ: Удалось создать рабочий модуль на основе большого"
    echo "Для сравнения смотри: test_module.c"
else
    echo "НЕУДАЧА: Не удалось адаптировать большой модуль"
    echo "Последние изменения в test_module.c показывают проблемные места"
fi