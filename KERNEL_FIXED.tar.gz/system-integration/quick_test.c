#include <linux/init.h>
#include <linux/module.h>
#include <linux/kernel.h>

MODULE_LICENSE("GPL");
MODULE_AUTHOR("Test");
MODULE_DESCRIPTION("Quick Test");
MODULE_VERSION("1.0");

// Проверяем конкретно проблемный тип
typedef enum {
    SECURITY_SLEEPING = 0,
    SECURITY_AWAKENED = 1,
    SECURITY_AUTHORIZED = 2,
    SECURITY_EMPOWERED = 3
} jarvis_security_state_t;

// Используем его в функции
static int test_function(jarvis_security_state_t state)
{
    return (int)state;
}

static int __init test_init(void)
{
    jarvis_security_state_t test_state = SECURITY_AWAKENED;
    printk(KERN_INFO "Test: State = %d\n", test_function(test_state));
    return 0;
}

static void __exit test_exit(void)
{
    printk(KERN_INFO "Test: Exit\n");
}

module_init(test_init);
module_exit(test_exit);
