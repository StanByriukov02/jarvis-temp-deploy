#include <linux/init.h>
#include <linux/module.h>
#include <linux/kernel.h>

MODULE_LICENSE("GPL");
MODULE_AUTHOR("JARVIS Test");
MODULE_DESCRIPTION("Simple JARVIS Test Module");
MODULE_VERSION("1.0");

static int __init jarvis_test_init(void)
{
    printk(KERN_INFO "JARVIS: Simple test module loaded successfully!\n");
    return 0;
}

static void __exit jarvis_test_exit(void)
{
    printk(KERN_INFO "JARVIS: Simple test module unloaded\n");
}

module_init(jarvis_test_init);
module_exit(jarvis_test_exit);