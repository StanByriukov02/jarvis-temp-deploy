#!/bin/bash

# Детектор ошибок - показывает ТОЧНЫЕ проблемы без удаления кода

echo "=== ДЕТЕКТОР ОШИБОК JARVIS МОДУЛЯ ==="

# Проверяем какой файл использовать - сначала исправленный, потом оригинальный
if [ -f "jarvis-kernel-fixed.c" ]; then
    BIG_MODULE="jarvis-kernel-fixed.c"
    echo "ИСПОЛЬЗУЕТСЯ ИСПРАВЛЕННАЯ ВЕРСИЯ: jarvis-kernel-fixed.c"
elif [ -f "jarvis-kernel-module.c" ]; then
    BIG_MODULE="jarvis-kernel-module.c" 
    echo "ИСПОЛЬЗУЕТСЯ ОРИГИНАЛЬНАЯ ВЕРСИЯ: jarvis-kernel-module.c"
else
    echo "ОШИБКА: Ни jarvis-kernel-fixed.c ни jarvis-kernel-module.c не найдены!"
    exit 1
fi

echo "Анализ модуля: $BIG_MODULE ($(wc -l < $BIG_MODULE) строк)"
echo

# Makefile для тестов
cat > Makefile << 'EOF'
obj-m := test_module.o

all:
        make -C /lib/modules/$(shell uname -r)/build M=$(PWD) modules

clean:
        make -C /lib/modules/$(shell uname -r)/build M=$(PWD) clean

.PHONY: all clean
EOF

# Функция тестирования с детальными ошибками
test_code() {
    local test_name="$1"
    local code_file="$2"
    
    echo "ТЕСТ: $test_name"
    echo "========================================"
    
    cp "$code_file" test_module.c
    make clean >/dev/null 2>&1
    
    if make all >compilation_output.log 2>&1; then
        if [ -f test_module.ko ]; then
            echo "✅ SUCCESS: $test_name компилируется успешно"
            return 0
        else
            echo "❌ СТРАННО: make успешен, но .ko не создан"
            return 1
        fi
    else
        echo "❌ FAILED: $test_name имеет ошибки компиляции:"
        echo "----------------------------------------"
        cat compilation_output.log | grep -E "(error:|Error|ERROR)" | head -10
        echo "----------------------------------------"
        echo "Полный лог ошибок сохранен в: compilation_output.log"
        return 1
    fi
}

echo "ЭТАП 1: Тест базового модуля..."
cat > base_test.c << 'EOF'
#include <linux/init.h>
#include <linux/module.h>
#include <linux/kernel.h>

MODULE_LICENSE("GPL");
MODULE_AUTHOR("JARVIS Bio-singularity System");
MODULE_DESCRIPTION("JARVIS Test");
MODULE_VERSION("1.0");

static int __init jarvis_init(void)
{
    printk(KERN_INFO "JARVIS: Base test loaded\n");
    return 0;
}

static void __exit jarvis_exit(void)
{
    printk(KERN_INFO "JARVIS: Base test unloaded\n");
}

module_init(jarvis_init);
module_exit(jarvis_exit);
EOF

test_code "БАЗОВЫЙ МОДУЛЬ" "base_test.c"
if [ $? -ne 0 ]; then
    echo "КРИТИЧЕСКАЯ ОШИБКА: Базовый модуль не работает!"
    exit 1
fi

echo
echo "ЭТАП 2: Тест оригинального JARVIS модуля..."
test_code "ОРИГИНАЛЬНЫЙ JARVIS" "$BIG_MODULE"
if [ $? -eq 0 ]; then
    echo "ОТЛИЧНО: Оригинальный модуль компилируется без проблем!"
    exit 0
fi

echo
echo "ЭТАП 3: Поиск проблемных секций..."

# Извлекаем и тестируем только headers
echo "Тест headers..."
grep "^#include" "$BIG_MODULE" > headers_only.c
cat >> headers_only.c << 'EOF'

MODULE_LICENSE("GPL");
MODULE_AUTHOR("JARVIS");
MODULE_DESCRIPTION("Headers Test");
MODULE_VERSION("1.0");

static int __init test_init(void) { return 0; }
static void __exit test_exit(void) { }
module_init(test_init);
module_exit(test_exit);
EOF

test_code "ТОЛЬКО HEADERS" "headers_only.c"

# Извлекаем и тестируем только структуры
echo
echo "Тест структур..."
grep "^#include" "$BIG_MODULE" > structures_test.c
sed -n '/^struct/,/^};/p' "$BIG_MODULE" >> structures_test.c
sed -n '/^typedef/,/;$/p' "$BIG_MODULE" >> structures_test.c
cat >> structures_test.c << 'EOF'

MODULE_LICENSE("GPL");
MODULE_AUTHOR("JARVIS");
MODULE_DESCRIPTION("Structures Test");
MODULE_VERSION("1.0");

static int __init test_init(void) { return 0; }
static void __exit test_exit(void) { }
module_init(test_init);
module_exit(test_exit);
EOF

test_code "СТРУКТУРЫ И TYPEDEF" "structures_test.c"

# Тестируем только forward declarations
echo
echo "Тест forward declarations..."
grep "^#include" "$BIG_MODULE" > forward_test.c
grep "^static.*;" "$BIG_MODULE" | head -20 >> forward_test.c
cat >> forward_test.c << 'EOF'

MODULE_LICENSE("GPL");
MODULE_AUTHOR("JARVIS");
MODULE_DESCRIPTION("Forward Declarations Test");
MODULE_VERSION("1.0");

static int __init test_init(void) { return 0; }
static void __exit test_exit(void) { }
module_init(test_init);
module_exit(test_exit);
EOF

test_code "FORWARD DECLARATIONS" "forward_test.c"

echo
echo "=== АНАЛИЗ ЗАВЕРШЕН ==="
echo "Проблемные места задокументированы в файлах compilation_output.log"
echo "Для детального анализа ошибок:"
echo "  cat compilation_output.log | grep -C 3 error"
echo
echo "Созданные тестовые файлы для отладки:"
ls -la *_test.c headers_only.c 2>/dev/null || echo "Файлы не созданы"