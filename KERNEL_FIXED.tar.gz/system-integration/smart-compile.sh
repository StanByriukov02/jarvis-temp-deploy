#!/bin/bash

# JARVIS Smart Compiler - поэтапная компиляция с детальной диагностикой
# Анализирует большой модуль и компилирует по частям для выявления конкретных проблем

set -e
trap 'echo "ОШИБКА в строке $LINENO. Выход."; exit 1' ERR

ORIGINAL_MODULE="jarvis-kernel-module.c"
WORK_DIR="smart-compile-test"
LOG_FILE="compilation_analysis.log"

echo "=== JARVIS Smart Compiler ==="
echo "Анализ и поэтапная компиляция модуля: $ORIGINAL_MODULE"

# Создаем рабочую директорию
rm -rf $WORK_DIR
mkdir -p $WORK_DIR
cd $WORK_DIR

# Копируем оригинальный модуль
cp ../$ORIGINAL_MODULE ./
echo > $LOG_FILE

echo
echo "ЭТАП 1: Анализ структуры модуля..."

# Извлекаем основные секции
echo "Извлечение headers..." | tee -a $LOG_FILE
sed -n '1,/^$/p' $ORIGINAL_MODULE > headers.c
echo "Headers извлечены: $(wc -l < headers.c) строк" | tee -a $LOG_FILE

echo "Извлечение MODULE_* макросов..." | tee -a $LOG_FILE
grep "^MODULE_" $ORIGINAL_MODULE > module_info.c || echo "// Нет MODULE макросов" > module_info.c
echo "Module info извлечен: $(wc -l < module_info.c) строк" | tee -a $LOG_FILE

echo "Извлечение typedef и struct..." | tee -a $LOG_FILE
sed -n '/typedef/,/;/p; /^struct/,/};/p' $ORIGINAL_MODULE > structures.c
echo "Structures извлечены: $(wc -l < structures.c) строк" | tee -a $LOG_FILE

echo "Извлечение forward declarations..." | tee -a $LOG_FILE
grep "^static.*;" $ORIGINAL_MODULE > forward_decl.c || echo "// Нет forward declarations" > forward_decl.c
echo "Forward declarations извлечены: $(wc -l < forward_decl.c) строк" | tee -a $LOG_FILE

echo
echo "ЭТАП 2: Создание базового модуля (только инициализация)..."

cat > base_module.c << 'EOF'
#include <linux/init.h>
#include <linux/module.h>
#include <linux/kernel.h>

MODULE_LICENSE("GPL");
MODULE_AUTHOR("JARVIS Bio-singularity System");
MODULE_DESCRIPTION("JARVIS Base Module Test");
MODULE_VERSION("1.0");

static int __init jarvis_base_init(void)
{
    printk(KERN_INFO "JARVIS Base: Module loaded successfully\n");
    return 0;
}

static void __exit jarvis_base_exit(void)
{
    printk(KERN_INFO "JARVIS Base: Module unloaded\n");
}

module_init(jarvis_base_init);
module_exit(jarvis_base_exit);
EOF

# Makefile для тестов
cat > Makefile << 'EOF'
obj-m := test_module.o

test:
	make -C /lib/modules/$(shell uname -r)/build M=$(PWD) test_module.ko V=1

clean:
	make -C /lib/modules/$(shell uname -r)/build M=$(PWD) clean

.PHONY: test clean
EOF

echo "Компиляция базового модуля..." | tee -a $LOG_FILE
cp base_module.c test_module.c
if make test 2>&1 | tee -a $LOG_FILE; then
    echo "✅ БАЗОВЫЙ МОДУЛЬ: OK" | tee -a $LOG_FILE
else
    echo "❌ БАЗОВЫЙ МОДУЛЬ: ОШИБКА" | tee -a $LOG_FILE
    echo "КРИТИЧЕСКАЯ ОШИБКА: Базовый модуль не компилируется!"
    exit 1
fi

echo
echo "ЭТАП 3: Добавление headers поэтапно..."

# Тест 1: Только основные headers
cat base_module.c > test_module.c
sed -i '3i#include <linux/syscalls.h>' test_module.c
sed -i '4i#include <linux/kallsyms.h>' test_module.c

echo "Компиляция с основными headers..." | tee -a $LOG_FILE
if make clean && make test 2>&1 | tee -a $LOG_FILE; then
    echo "✅ ОСНОВНЫЕ HEADERS: OK" | tee -a $LOG_FILE
else
    echo "❌ ОСНОВНЫЕ HEADERS: ОШИБКА" | tee -a $LOG_FILE
    echo "ПРОБЛЕМА: Основные kernel headers недоступны"
    tail -20 $LOG_FILE
    exit 1
fi

# Тест 2: Добавление proc_fs и seq_file
sed -i '5i#include <linux/proc_fs.h>' test_module.c
sed -i '6i#include <linux/seq_file.h>' test_module.c
sed -i '7i#include <linux/uaccess.h>' test_module.c

echo "Компиляция с proc headers..." | tee -a $LOG_FILE
if make clean && make test 2>&1 | tee -a $LOG_FILE; then
    echo "✅ PROC HEADERS: OK" | tee -a $LOG_FILE
else
    echo "❌ PROC HEADERS: ОШИБКА" | tee -a $LOG_FILE
    echo "ПРОБЛЕМА: Proc filesystem headers"
    tail -20 $LOG_FILE
fi

# Тест 3: Добавление threading headers
sed -i '8i#include <linux/slab.h>' test_module.c
sed -i '9i#include <linux/mutex.h>' test_module.c
sed -i '10i#include <linux/kthread.h>' test_module.c
sed -i '11i#include <linux/delay.h>' test_module.c

echo "Компиляция с threading headers..." | tee -a $LOG_FILE
if make clean && make test 2>&1 | tee -a $LOG_FILE; then
    echo "✅ THREADING HEADERS: OK" | tee -a $LOG_FILE
else
    echo "❌ THREADING HEADERS: ОШИБКА" | tee -a $LOG_FILE
    echo "ПРОБЛЕМА: Threading/memory headers"
    tail -20 $LOG_FILE
fi

echo
echo "ЭТАП 4: Добавление structures поэтапно..."

# Простейшая структура
cat >> test_module.c << 'EOF'

struct jarvis_simple {
    u32 test_value;
    atomic_t state;
};

static struct jarvis_simple *jarvis_test = NULL;
EOF

# Модифицируем init функцию
sed -i '/jarvis_base_init/,/return 0/c\
static int __init jarvis_base_init(void)\
{\
    jarvis_test = kzalloc(sizeof(*jarvis_test), GFP_KERNEL);\
    if (!jarvis_test) {\
        printk(KERN_ERR "JARVIS: Failed to allocate memory\\n");\
        return -ENOMEM;\
    }\
    jarvis_test->test_value = 12345;\
    atomic_set(&jarvis_test->state, 1);\
    printk(KERN_INFO "JARVIS Base: Module loaded successfully\\n");\
    return 0;\
}' test_module.c

sed -i '/jarvis_base_exit/,/}/c\
static void __exit jarvis_base_exit(void)\
{\
    if (jarvis_test) {\
        kfree(jarvis_test);\
        jarvis_test = NULL;\
    }\
    printk(KERN_INFO "JARVIS Base: Module unloaded\\n");\
}' test_module.c

echo "Компиляция с простой структурой..." | tee -a $LOG_FILE
if make clean && make test 2>&1 | tee -a $LOG_FILE; then
    echo "✅ ПРОСТАЯ СТРУКТУРА: OK" | tee -a $LOG_FILE
else
    echo "❌ ПРОСТАЯ СТРУКТУРА: ОШИБКА" | tee -a $LOG_FILE
    echo "ПРОБЛЕМА: Работа с памятью или atomic операции"
    tail -20 $LOG_FILE
fi

echo
echo "ЭТАП 5: Добавление сложных структур из оригинального модуля..."

# Берем первую сложную структуру из оригинала
FIRST_STRUCT=$(sed -n '/struct jarvis_/,/};/p' ../$ORIGINAL_MODULE | head -20)
if [ ! -z "$FIRST_STRUCT" ]; then
    echo "Добавление первой сложной структуры..." | tee -a $LOG_FILE
    echo "$FIRST_STRUCT" >> test_module.c
    
    if make clean && make test 2>&1 | tee -a $LOG_FILE; then
        echo "✅ ПЕРВАЯ СЛОЖНАЯ СТРУКТУРА: OK" | tee -a $LOG_FILE
    else
        echo "❌ ПЕРВАЯ СЛОЖНАЯ СТРУКТУРА: ОШИБКА" | tee -a $LOG_FILE
        echo "ПРОБЛЕМА в сложной структуре:"
        echo "$FIRST_STRUCT"
        tail -20 $LOG_FILE
    fi
fi

echo
echo "=== РЕЗУЛЬТАТЫ SMART COMPILATION ==="
echo "Подробный лог: $(pwd)/$LOG_FILE"
echo
echo "УСПЕШНЫЕ ЭТАПЫ:"
grep "✅" $LOG_FILE || echo "Нет успешных этапов"
echo
echo "ПРОБЛЕМНЫЕ ЭТАПЫ:"  
grep "❌" $LOG_FILE || echo "Все этапы успешны"
echo
echo "Для продолжения анализа добавлю следующие компоненты поэтапно..."

cd ..
EOF