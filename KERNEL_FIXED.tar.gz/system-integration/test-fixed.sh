#!/bin/bash

echo "=== ТЕСТ ИСПРАВЛЕННОГО JARVIS МОДУЛЯ ==="

FIXED_MODULE="jarvis-kernel-fixed.c"

if [ ! -f "$FIXED_MODULE" ]; then
    echo "ОШИБКА: Файл $FIXED_MODULE не найден!"
    exit 1
fi

echo "Компиляция исправленного модуля: $FIXED_MODULE ($(wc -l < $FIXED_MODULE) строк)"

# Makefile
cat > Makefile << 'EOF'
obj-m := jarvis-kernel-fixed.o

all:
	make -C /lib/modules/$(shell uname -r)/build M=$(PWD) modules V=1

clean:
	make -C /lib/modules/$(shell uname -r)/build M=$(PWD) clean

.PHONY: all clean
EOF

make clean >/dev/null 2>&1

echo "Компиляция..."
if make all 2>error.log; then
    if [ -f jarvis-kernel-fixed.ko ]; then
        echo "✅ SUCCESS: ИСПРАВЛЕННЫЙ JARVIS МОДУЛЬ СКОМПИЛИРОВАН!"
        echo "Размер модуля: $(ls -lh jarvis-kernel-fixed.ko | awk '{print $5}')"
        echo "Строк кода: $(wc -l < $FIXED_MODULE)"
        echo
        echo "ВОЗМОЖНОСТИ МОДУЛЯ:"
        echo "- 2М квантовых нейронов"
        echo "- Bio-Singularity состояния"
        echo "- WebRTC соединения"
        echo "- Kernel-level мониторинг"
        echo "- Proc интерфейс (/proc/jarvis_core)"
        echo
        echo "Для загрузки модуля: sudo insmod jarvis-kernel-fixed.ko"
        echo "Для просмотра статуса: cat /proc/jarvis_core"
    else
        echo "❌ СТРАННО: make успешен, но .ko файл не создан"
        exit 1
    fi
else
    echo "❌ ОШИБКИ КОМПИЛЯЦИИ:"
    cat error.log
    exit 1
fi