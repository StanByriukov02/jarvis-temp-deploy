#!/bin/bash

# Простой тест компиляции - БЕЗ неправильной интерпретации результатов

echo "=== ПРОСТОЙ ТЕСТ КОМПИЛЯЦИИ ==="

# Создаем минимальный модуль
cat > test_simple.c << 'EOF'
#include <linux/init.h>
#include <linux/module.h>
#include <linux/kernel.h>

MODULE_LICENSE("GPL");
MODULE_AUTHOR("JARVIS Test");
MODULE_DESCRIPTION("Simple Test Module");
MODULE_VERSION("1.0");

static int __init test_init(void)
{
    printk(KERN_INFO "Test module loaded\n");
    return 0;
}

static void __exit test_exit(void)
{
    printk(KERN_INFO "Test module unloaded\n");
}

module_init(test_init);
module_exit(test_exit);
EOF

# Makefile
cat > Makefile << 'EOF'
obj-m := test_simple.o

all:
	make -C /lib/modules/$(shell uname -r)/build M=$(PWD) modules V=1

clean:
	make -C /lib/modules/$(shell uname -r)/build M=$(PWD) clean

.PHONY: all clean
EOF

echo "Компиляция простого модуля..."
echo "=========================="

# Реальная компиляция БЕЗ неправильной интерпретации
make clean >/dev/null 2>&1
make all

# Проверяем результат
if [ -f test_simple.ko ]; then
    echo
    echo "SUCCESS: Модуль test_simple.ko создан успешно!"
    ls -la test_simple.ko
else
    echo
    echo "FAILED: Модуль НЕ создан - есть ошибки компиляции"
fi

echo
echo "=== КОНЕЦ ТЕСТА ==="