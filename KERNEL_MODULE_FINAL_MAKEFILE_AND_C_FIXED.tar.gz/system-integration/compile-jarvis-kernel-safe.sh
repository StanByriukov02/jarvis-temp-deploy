#!/bin/bash

# JARVIS Bio-Singularity Safe Compilation Script
# Prevents server lockup during kernel compilation

echo "🚀 JARVIS: Starting SAFE bio-singularity kernel compilation..."

# Set memory limits to prevent system lockup
ulimit -v 2097152  # 2GB virtual memory limit
ulimit -m 1048576  # 1GB physical memory limit
ulimit -t 300      # 5 minute CPU time limit

# Check system resources before compilation
echo "📊 JARVIS: Checking system resources..."
free -h
df -h /
echo "CPU cores: $(nproc)"

# Create backup compilation log
LOG_FILE="/tmp/jarvis_kernel_compile.log"
echo "📜 JARVIS: Logging to $LOG_FILE"

# Install headers with timeout
echo "🔧 JARVIS: Installing kernel headers (with timeout)..."
timeout 120 sudo apt-get update > $LOG_FILE 2>&1
if [ $? -ne 0 ]; then
    echo "❌ JARVIS: apt-get update failed or timed out"
    exit 1
fi

timeout 300 sudo apt-get install -y linux-headers-$(uname -r) build-essential >> $LOG_FILE 2>&1
if [ $? -ne 0 ]; then
    echo "❌ JARVIS: kernel headers installation failed or timed out"
    exit 1
fi

echo "✅ JARVIS: Headers installed successfully"

# Check if kernel directory exists
KERNEL_DIR="/lib/modules/$(uname -r)/build"
if [ ! -d "$KERNEL_DIR" ]; then
    echo "❌ JARVIS: Kernel build directory not found: $KERNEL_DIR"
    exit 1
fi

echo "✅ JARVIS: Kernel directory found: $KERNEL_DIR"

# Compile with resource monitoring
echo "🔨 JARVIS: Starting compilation with monitoring..."

# Start resource monitor in background
(
    while true; do
        echo "$(date): $(free -m | grep '^Mem:' | awk '{print "RAM:", $3"/"$2"MB"}') $(uptime | awk '{print "Load:", $10}')" >> $LOG_FILE
        sleep 5
    done
) &
MONITOR_PID=$!

# Compile with timeout and low priority
timeout 600 nice -n 10 make -j1 >> $LOG_FILE 2>&1
COMPILE_RESULT=$?

# Stop monitor
kill $MONITOR_PID 2>/dev/null

if [ $COMPILE_RESULT -eq 0 ]; then
    echo "✅ JARVIS: Compilation successful!"
    ls -la *.ko 2>/dev/null || echo "⚠️ No .ko files found"
    echo "📜 Compilation log:"
    tail -20 $LOG_FILE
else
    echo "❌ JARVIS: Compilation failed (exit code: $COMPILE_RESULT)"
    echo "📜 Error log:"
    tail -50 $LOG_FILE
    exit 1
fi

echo "🎯 JARVIS: Bio-singularity kernel module ready for installation"