#!/bin/bash

# JARVIS Kernel Module Compilation and Integration Script
# Автоматическая сборка и интеграция с биосингулярностью

set -e  # Exit on any error

echo "🚀 JARVIS: Starting comprehensive kernel compilation and integration..."
echo "📋 System: $(uname -a)"
echo "⏰ Time: $(date)"

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# Function to print colored output
print_status() {
    echo -e "${BLUE}🔵 JARVIS:${NC} $1"
}

print_success() {
    echo -e "${GREEN}✅ JARVIS:${NC} $1"
}

print_warning() {
    echo -e "${YELLOW}⚠️ JARVIS:${NC} $1"
}

print_error() {
    echo -e "${RED}❌ JARVIS:${NC} $1"
}

# Check if running as root for kernel operations
check_permissions() {
    if [[ $EUID -ne 0 ]]; then
        print_warning "Kernel operations require root privileges"
        print_status "Run with: sudo $0"
        exit 1
    fi
}

# Install required dependencies
install_dependencies() {
    print_status "Installing kernel development dependencies..."
    
    # Detect distribution
    if command -v apt-get >/dev/null 2>&1; then
        # Debian/Ubuntu
        apt-get update
        apt-get install -y \
            linux-headers-$(uname -r) \
            build-essential \
            gcc \
            make \
            dkms \
            git
        print_success "Dependencies installed (Debian/Ubuntu)"
    elif command -v yum >/dev/null 2>&1; then
        # RedHat/CentOS
        yum groupinstall -y "Development Tools"
        yum install -y kernel-devel-$(uname -r) kernel-headers-$(uname -r)
        print_success "Dependencies installed (RedHat/CentOS)"
    elif command -v pacman >/dev/null 2>&1; then
        # Arch Linux
        pacman -S --noconfirm linux-headers base-devel
        print_success "Dependencies installed (Arch Linux)"
    else
        print_warning "Unknown distribution. Please install kernel headers manually."
    fi
}

# Check system compatibility
check_compatibility() {
    print_status "Checking system compatibility..."
    
    KERNEL_VERSION=$(uname -r)
    ARCH=$(uname -m)
    
    print_status "Kernel version: $KERNEL_VERSION"
    print_status "Architecture: $ARCH"
    
    # Check if kernel headers exist
    KERNEL_DIR="/lib/modules/$KERNEL_VERSION/build"
    if [[ ! -d "$KERNEL_DIR" ]]; then
        print_error "Kernel headers not found at $KERNEL_DIR"
        print_status "Installing kernel headers..."
        install_dependencies
    else
        print_success "Kernel headers found"
    fi
    
    # Check compiler
    if command -v gcc >/dev/null 2>&1; then
        GCC_VERSION=$(gcc --version | head -1)
        print_success "Compiler found: $GCC_VERSION"
    else
        print_error "GCC compiler not found"
        exit 1
    fi
}

# Compile kernel module
compile_module() {
    print_status "Compiling JARVIS kernel module..."
    
    cd "$(dirname "$0")"
    
    # Clean previous builds
    make clean >/dev/null 2>&1 || true
    
    # Compile module
    if make all; then
        print_success "Kernel module compiled successfully"
        
        # Check if .ko file exists
        if [[ -f "jarvis_kernel.ko" ]]; then
            print_success "Module file created: jarvis_kernel.ko"
            print_status "Module size: $(ls -lh jarvis_kernel.ko | awk '{print $5}')"
        else
            print_error "Module file not found after compilation"
            exit 1
        fi
    else
        print_error "Kernel module compilation failed"
        exit 1
    fi
}

# Load kernel module
load_module() {
    print_status "Loading JARVIS kernel module..."
    
    # Unload if already loaded
    if lsmod | grep -q "jarvis_kernel"; then
        print_warning "Module already loaded, unloading first..."
        rmmod jarvis_kernel || true
    fi
    
    # Load module
    if insmod jarvis_kernel.ko; then
        print_success "Kernel module loaded successfully"
        
        # Verify module is loaded
        if lsmod | grep -q "jarvis_kernel"; then
            print_success "Module verified in kernel"
        else
            print_error "Module not found in kernel after loading"
            exit 1
        fi
    else
        print_error "Failed to load kernel module"
        exit 1
    fi
}

# Check module status and interfaces
check_module_status() {
    print_status "Checking JARVIS module status..."
    
    # Show module info
    if lsmod | grep jarvis_kernel; then
        print_success "Module loaded successfully"
    else
        print_error "Module not loaded"
        return 1
    fi
    
    # Check /proc interface
    if [[ -f "/proc/jarvis_bio_singularity" ]]; then
        print_success "Bio-singularity interface available"
        print_status "Interface contents:"
        cat "/proc/jarvis_bio_singularity" | head -5
    else
        print_warning "Bio-singularity interface not found"
    fi
    
    # Check /sys interface
    if [[ -d "/sys/module/jarvis_kernel" ]]; then
        print_success "Sysfs interface available"
    else
        print_warning "Sysfs interface not found"
    fi
    
    # Show recent kernel messages
    print_status "Recent kernel messages:"
    dmesg | grep -i jarvis | tail -10 || print_warning "No JARVIS messages in dmesg"
}

# Test bio-singularity integration
test_integration() {
    print_status "Testing bio-singularity integration..."
    
    # Test proc interface
    if [[ -f "/proc/jarvis_bio_singularity" ]]; then
        echo "test_command:bio_singularity_ping" > /proc/jarvis_bio_singularity
        sleep 1
        RESPONSE=$(cat /proc/jarvis_bio_singularity | head -1)
        print_status "Bio-singularity response: $RESPONSE"
        
        if [[ "$RESPONSE" == *"pong"* ]]; then
            print_success "Bio-singularity integration working"
        else
            print_warning "Bio-singularity integration needs attention"
        fi
    else
        print_warning "Cannot test integration - interface not available"
    fi
}

# Create systemd service for auto-loading
create_service() {
    print_status "Creating systemd service for auto-loading..."
    
    cat > /etc/systemd/system/jarvis-kernel.service << EOF
[Unit]
Description=JARVIS Kernel Module
After=multi-user.target

[Service]
Type=oneshot
ExecStart=/sbin/insmod $(pwd)/jarvis_kernel.ko
ExecStop=/sbin/rmmod jarvis_kernel
RemainAfterExit=yes

[Install]
WantedBy=multi-user.target
EOF

    systemctl daemon-reload
    systemctl enable jarvis-kernel.service
    print_success "Systemd service created and enabled"
}

# Main execution
main() {
    print_status "JARVIS Kernel Module Compilation Starting..."
    
    # Check if we need root
    if [[ "$1" != "--no-root-check" ]]; then
        check_permissions
    fi
    
    # Run compilation steps
    check_compatibility
    compile_module
    
    # Only load if not in CI/testing environment
    if [[ "$1" != "--compile-only" ]]; then
        load_module
        check_module_status
        test_integration
        
        # Ask about systemd service
        if [[ "$1" != "--no-service" ]]; then
            read -p "Create systemd service for auto-loading? (y/N): " -n 1 -r
            echo
            if [[ $REPLY =~ ^[Yy]$ ]]; then
                create_service
            fi
        fi
    fi
    
    print_success "JARVIS kernel compilation and integration completed!"
    print_status "Module status: $(lsmod | grep jarvis_kernel | awk '{print $1 " (" $2 " bytes)"}')"
    print_status "Next steps:"
    print_status "  1. Test voice integration: node test-voice-integration.js"
    print_status "  2. Test bio-singularity: curl localhost:3000/api/jarvis/kernel-status"
    print_status "  3. Check logs: sudo dmesg | grep -i jarvis"
}

# Handle script arguments
case "$1" in
    --help|-h)
        echo "JARVIS Kernel Module Compilation Script"
        echo "Usage: $0 [options]"
        echo "Options:"
        echo "  --compile-only    Compile but don't load module"
        echo "  --no-service      Don't create systemd service"
        echo "  --no-root-check   Skip root permission check"
        echo "  --help           Show this help"
        exit 0
        ;;
    *)
        main "$@"
        ;;
esac